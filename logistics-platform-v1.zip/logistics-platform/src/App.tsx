import { useEffect } from 'react'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { useAppStore } from '@/store'
import { AppLayout } from '@/components/layout/AppLayout'

// Pages (lazy-loaded in production — direct for clarity here)
import { DashboardPage } from '@/pages/DashboardPage'
import { OrdersPage } from '@/pages/OrdersPage'
import { TripsPage } from '@/pages/TripsPage'
import { WeeklyPlannerPage } from '@/pages/WeeklyPlannerPage'
import { TrucksPage } from '@/pages/TrucksPage'
import { LoadingSimulatorPage } from '@/pages/LoadingSimulatorPage'
import { OvertimePage } from '@/pages/OvertimePage'
import { EmployeesPage } from '@/pages/EmployeesPage'
import { MaintenancePage } from '@/pages/MaintenancePage'
import { ReportsPage } from '@/pages/ReportsPage'
import { ImportPage } from '@/pages/ImportPage'
import { SettingsPage } from '@/pages/SettingsPage'
import { KpiPage } from '@/pages/KpiPage'

export default function App() {
  const { settings } = useAppStore()

  // Apply theme
  useEffect(() => {
    const root = document.documentElement
    const theme = settings.theme

    if (theme === 'dark') {
      root.classList.add('dark')
    } else if (theme === 'light') {
      root.classList.remove('dark')
    } else {
      // system
      const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches
      prefersDark ? root.classList.add('dark') : root.classList.remove('dark')
    }

    // Apply direction
    root.setAttribute('dir', settings.language === 'ar' ? 'rtl' : 'ltr')
    root.setAttribute('lang', settings.language)
  }, [settings.theme, settings.language])

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<AppLayout />}>
          <Route index element={<Navigate to="/dashboard" replace />} />
          <Route path="dashboard" element={<DashboardPage />} />
          <Route path="orders" element={<OrdersPage />} />
          <Route path="trips" element={<TripsPage />} />
          <Route path="planner" element={<WeeklyPlannerPage />} />
          <Route path="trucks" element={<TrucksPage />} />
          <Route path="simulator" element={<LoadingSimulatorPage />} />
          <Route path="overtime" element={<OvertimePage />} />
          <Route path="employees" element={<EmployeesPage />} />
          <Route path="maintenance" element={<MaintenancePage />} />
          <Route path="kpi" element={<KpiPage />} />
          <Route path="reports" element={<ReportsPage />} />
          <Route path="import" element={<ImportPage />} />
          <Route path="settings" element={<SettingsPage />} />
        </Route>
      </Routes>
    </BrowserRouter>
  )
}
