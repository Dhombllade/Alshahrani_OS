// ============================================================
// GLOBAL STATE STORE — ZUSTAND
// All application state in one place, fully typed
// ============================================================

import { create } from 'zustand'
import { persist, createJSONStorage } from 'zustand/middleware'
import type {
  Order, Trip, Truck, Employee, Product, Customer,
  MaintenanceRecord, OvertimeRecord, WeeklyPlan,
  LoadingSimulation, ImportResult, AppNotification,
  AppSettings, DailyKPI
} from '@/types'

// ─── DEFAULT SETTINGS ────────────────────────────────────────

const defaultSettings: AppSettings = {
  companyName: 'Logistics Platform',
  companyNameAr: 'منصة اللوجستيات',
  companyLogo: null,
  region: 'المنطقة الجنوبية',
  workingHoursStart: '07:00',
  workingHoursEnd: '17:00',
  workingDays: [0, 1, 2, 3, 4],
  averageTruckSpeedKmh: 60,
  loadingTimeMinutes: 30,
  unloadingTimeMinutes: 20,
  breakTimeMinutes: 30,
  overtimeThresholdMinutes: 10,
  maxTripsPerDriverPerDay: 2,
  maxOrdersPerTrip: 15,
  nearbyDeliveryRadiusKm: 15,
  utilizationWarningThreshold: 0.6,
  theme: 'system',
  language: 'ar',
  currency: 'SAR',
  distanceUnit: 'km',
  weightUnit: 'kg',
  volumeUnit: 'm3',
  googleMapsApiKey: '',
  warehouseLocation: null,
  whatsappEnabled: false,
  emailEnabled: false,
}

// ─── STORE INTERFACE ─────────────────────────────────────────

interface AppState {
  // Data
  orders: Order[]
  trips: Trip[]
  trucks: Truck[]
  employees: Employee[]
  products: Product[]
  customers: Customer[]
  maintenanceRecords: MaintenanceRecord[]
  overtimeRecords: OvertimeRecord[]
  weeklyPlans: WeeklyPlan[]
  loadingSimulations: LoadingSimulation[]
  importHistory: ImportResult[]
  notifications: AppNotification[]
  kpiHistory: DailyKPI[]

  // Settings
  settings: AppSettings

  // UI State
  sidebarOpen: boolean
  currentPage: string
  globalSearchOpen: boolean
  commandPaletteOpen: boolean

  // ─── SETTERS ─────────────────────────────────────────────

  // Orders
  setOrders: (orders: Order[]) => void
  addOrder: (order: Order) => void
  updateOrder: (id: string, updates: Partial<Order>) => void
  deleteOrder: (id: string) => void
  bulkUpdateOrders: (ids: string[], updates: Partial<Order>) => void

  // Trips
  setTrips: (trips: Trip[]) => void
  addTrip: (trip: Trip) => void
  updateTrip: (id: string, updates: Partial<Trip>) => void
  deleteTrip: (id: string) => void

  // Trucks
  setTrucks: (trucks: Truck[]) => void
  addTruck: (truck: Truck) => void
  updateTruck: (id: string, updates: Partial<Truck>) => void
  deleteTruck: (id: string) => void

  // Employees
  setEmployees: (employees: Employee[]) => void
  addEmployee: (employee: Employee) => void
  updateEmployee: (id: string, updates: Partial<Employee>) => void
  deleteEmployee: (id: string) => void

  // Products
  setProducts: (products: Product[]) => void
  addProduct: (product: Product) => void
  updateProduct: (id: string, updates: Partial<Product>) => void

  // Customers
  setCustomers: (customers: Customer[]) => void

  // Maintenance
  addMaintenanceRecord: (record: MaintenanceRecord) => void
  updateMaintenanceRecord: (id: string, updates: Partial<MaintenanceRecord>) => void
  deleteMaintenanceRecord: (id: string) => void

  // Overtime
  addOvertimeRecord: (record: OvertimeRecord) => void
  updateOvertimeRecord: (id: string, updates: Partial<OvertimeRecord>) => void

  // Weekly Plans
  setWeeklyPlan: (plan: WeeklyPlan) => void
  updateWeeklyPlan: (id: string, updates: Partial<WeeklyPlan>) => void

  // Loading Simulations
  addLoadingSimulation: (sim: LoadingSimulation) => void

  // Import
  addImportResult: (result: ImportResult) => void

  // Notifications
  addNotification: (n: AppNotification) => void
  markNotificationRead: (id: string) => void
  clearNotifications: () => void

  // KPI
  addKpiRecord: (kpi: DailyKPI) => void

  // Settings
  updateSettings: (updates: Partial<AppSettings>) => void

  // UI
  setSidebarOpen: (open: boolean) => void
  setCurrentPage: (page: string) => void
  setGlobalSearchOpen: (open: boolean) => void
  setCommandPaletteOpen: (open: boolean) => void
}

// ─── STORE IMPLEMENTATION ────────────────────────────────────

export const useAppStore = create<AppState>()(
  persist(
    (set) => ({
      // Initial data
      orders: [],
      trips: [],
      trucks: [],
      employees: [],
      products: [],
      customers: [],
      maintenanceRecords: [],
      overtimeRecords: [],
      weeklyPlans: [],
      loadingSimulations: [],
      importHistory: [],
      notifications: [],
      kpiHistory: [],

      settings: defaultSettings,

      // UI
      sidebarOpen: true,
      currentPage: 'dashboard',
      globalSearchOpen: false,
      commandPaletteOpen: false,

      // ─── Order actions ──────────────────────────────────
      setOrders: (orders) => set({ orders }),
      addOrder: (order) => set((s) => ({ orders: [...s.orders, order] })),
      updateOrder: (id, updates) =>
        set((s) => ({
          orders: s.orders.map((o) => (o.id === id ? { ...o, ...updates } : o)),
        })),
      deleteOrder: (id) =>
        set((s) => ({ orders: s.orders.filter((o) => o.id !== id) })),
      bulkUpdateOrders: (ids, updates) =>
        set((s) => ({
          orders: s.orders.map((o) =>
            ids.includes(o.id) ? { ...o, ...updates } : o
          ),
        })),

      // ─── Trip actions ───────────────────────────────────
      setTrips: (trips) => set({ trips }),
      addTrip: (trip) => set((s) => ({ trips: [...s.trips, trip] })),
      updateTrip: (id, updates) =>
        set((s) => ({
          trips: s.trips.map((t) => (t.id === id ? { ...t, ...updates } : t)),
        })),
      deleteTrip: (id) =>
        set((s) => ({ trips: s.trips.filter((t) => t.id !== id) })),

      // ─── Truck actions ──────────────────────────────────
      setTrucks: (trucks) => set({ trucks }),
      addTruck: (truck) => set((s) => ({ trucks: [...s.trucks, truck] })),
      updateTruck: (id, updates) =>
        set((s) => ({
          trucks: s.trucks.map((t) => (t.id === id ? { ...t, ...updates } : t)),
        })),
      deleteTruck: (id) =>
        set((s) => ({ trucks: s.trucks.filter((t) => t.id !== id) })),

      // ─── Employee actions ───────────────────────────────
      setEmployees: (employees) => set({ employees }),
      addEmployee: (employee) =>
        set((s) => ({ employees: [...s.employees, employee] })),
      updateEmployee: (id, updates) =>
        set((s) => ({
          employees: s.employees.map((e) =>
            e.id === id ? { ...e, ...updates } : e
          ),
        })),
      deleteEmployee: (id) =>
        set((s) => ({ employees: s.employees.filter((e) => e.id !== id) })),

      // ─── Product actions ────────────────────────────────
      setProducts: (products) => set({ products }),
      addProduct: (product) =>
        set((s) => ({ products: [...s.products, product] })),
      updateProduct: (id, updates) =>
        set((s) => ({
          products: s.products.map((p) =>
            p.id === id ? { ...p, ...updates } : p
          ),
        })),

      // ─── Customer actions ───────────────────────────────
      setCustomers: (customers) => set({ customers }),

      // ─── Maintenance actions ────────────────────────────
      addMaintenanceRecord: (record) =>
        set((s) => ({
          maintenanceRecords: [...s.maintenanceRecords, record],
        })),
      updateMaintenanceRecord: (id, updates) =>
        set((s) => ({
          maintenanceRecords: s.maintenanceRecords.map((r) =>
            r.id === id ? { ...r, ...updates } : r
          ),
        })),
      deleteMaintenanceRecord: (id) =>
        set((s) => ({
          maintenanceRecords: s.maintenanceRecords.filter((r) => r.id !== id),
        })),

      // ─── Overtime actions ───────────────────────────────
      addOvertimeRecord: (record) =>
        set((s) => ({
          overtimeRecords: [...s.overtimeRecords, record],
        })),
      updateOvertimeRecord: (id, updates) =>
        set((s) => ({
          overtimeRecords: s.overtimeRecords.map((r) =>
            r.id === id ? { ...r, ...updates } : r
          ),
        })),

      // ─── Weekly plan actions ────────────────────────────
      setWeeklyPlan: (plan) =>
        set((s) => {
          const exists = s.weeklyPlans.find((p) => p.id === plan.id)
          return {
            weeklyPlans: exists
              ? s.weeklyPlans.map((p) => (p.id === plan.id ? plan : p))
              : [...s.weeklyPlans, plan],
          }
        }),
      updateWeeklyPlan: (id, updates) =>
        set((s) => ({
          weeklyPlans: s.weeklyPlans.map((p) =>
            p.id === id ? { ...p, ...updates } : p
          ),
        })),

      // ─── Loading simulation actions ─────────────────────
      addLoadingSimulation: (sim) =>
        set((s) => ({
          loadingSimulations: [sim, ...s.loadingSimulations].slice(0, 50),
        })),

      // ─── Import actions ─────────────────────────────────
      addImportResult: (result) =>
        set((s) => ({
          importHistory: [result, ...s.importHistory].slice(0, 100),
        })),

      // ─── Notification actions ────────────────────────────
      addNotification: (n) =>
        set((s) => ({
          notifications: [n, ...s.notifications].slice(0, 50),
        })),
      markNotificationRead: (id) =>
        set((s) => ({
          notifications: s.notifications.map((n) =>
            n.id === id ? { ...n, read: true } : n
          ),
        })),
      clearNotifications: () => set({ notifications: [] }),

      // ─── KPI actions ────────────────────────────────────
      addKpiRecord: (kpi) =>
        set((s) => ({
          kpiHistory: [...s.kpiHistory, kpi].slice(-365),
        })),

      // ─── Settings actions ────────────────────────────────
      updateSettings: (updates) =>
        set((s) => ({ settings: { ...s.settings, ...updates } })),

      // ─── UI actions ──────────────────────────────────────
      setSidebarOpen: (open) => set({ sidebarOpen: open }),
      setCurrentPage: (page) => set({ currentPage: page }),
      setGlobalSearchOpen: (open) => set({ globalSearchOpen: open }),
      setCommandPaletteOpen: (open) => set({ commandPaletteOpen: open }),
    }),
    {
      name: 'logistics-platform-storage',
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({
        orders: state.orders,
        trips: state.trips,
        trucks: state.trucks,
        employees: state.employees,
        products: state.products,
        customers: state.customers,
        maintenanceRecords: state.maintenanceRecords,
        overtimeRecords: state.overtimeRecords,
        weeklyPlans: state.weeklyPlans,
        importHistory: state.importHistory,
        kpiHistory: state.kpiHistory,
        settings: state.settings,
      }),
    }
  )
)
