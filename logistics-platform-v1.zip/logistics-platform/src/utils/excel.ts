// ============================================================
// EXCEL / CSV IMPORT ENGINE
// Handles Dynamics 365 exports and generic formats
// ============================================================

import * as XLSX from 'xlsx'
import { generateId, calcVolumeM3, DYNAMICS_ORDER_COLUMN_MAP } from '@/utils'
import type { Order, ImportResult, ImportError, ImportColumn, ImportType } from '@/types'

// ─── PARSE EXCEL FILE ────────────────────────────────────────

export interface ParsedSheet {
  headers: string[]
  rows: Record<string, unknown>[]
  sheetName: string
}

export function parseExcelFile(file: File): Promise<ParsedSheet[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()

    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer)
        const workbook = XLSX.read(data, { type: 'array', cellDates: true })

        const sheets: ParsedSheet[] = workbook.SheetNames.map((name) => {
          const ws = workbook.Sheets[name]
          const json = XLSX.utils.sheet_to_json<Record<string, unknown>>(ws, {
            defval: '',
            raw: false,
            dateNF: 'YYYY-MM-DD',
          })
          const headers = json.length > 0 ? Object.keys(json[0]) : []
          return { headers, rows: json, sheetName: name }
        })

        resolve(sheets)
      } catch (err) {
        reject(new Error(`فشل قراءة الملف: ${(err as Error).message}`))
      }
    }

    reader.onerror = () => reject(new Error('فشل قراءة الملف'))
    reader.readAsArrayBuffer(file)
  })
}

// ─── AUTO-DETECT COLUMN MAPPING ──────────────────────────────

export function autoDetectColumns(
  headers: string[],
  columnMap: Record<string, string>
): ImportColumn[] {
  return headers.map((header) => {
    const normalizedHeader = header.trim()
    const targetField = columnMap[normalizedHeader] || ''

    return {
      sourceColumn: header,
      targetField,
      required: ['orderNumber', 'customerName', 'requestedDeliveryDate'].includes(targetField),
    }
  })
}

// ─── PARSE DATE ──────────────────────────────────────────────

function parseDate(value: unknown): string {
  if (!value) return new Date().toISOString().slice(0, 10)

  if (value instanceof Date) {
    return value.toISOString().slice(0, 10)
  }

  const str = String(value).trim()

  // Try ISO format
  if (/^\d{4}-\d{2}-\d{2}/.test(str)) return str.slice(0, 10)

  // Try DD/MM/YYYY
  const ddmmyyyy = str.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/)
  if (ddmmyyyy) {
    const [, d, m, y] = ddmmyyyy
    return `${y}-${m.padStart(2, '0')}-${d.padStart(2, '0')}`
  }

  // Try Excel serial number
  const serial = parseFloat(str)
  if (!isNaN(serial) && serial > 40000) {
    const date = XLSX.SSF.parse_date_code(serial)
    if (date) {
      return `${date.y}-${String(date.m).padStart(2, '0')}-${String(date.d).padStart(2, '0')}`
    }
  }

  return new Date().toISOString().slice(0, 10)
}

// ─── PARSE NUMBER ────────────────────────────────────────────

function parseNumber(value: unknown): number {
  if (typeof value === 'number') return value
  const str = String(value).replace(/[,،\s]/g, '')
  const num = parseFloat(str)
  return isNaN(num) ? 0 : num
}

// ─── IMPORT ORDERS ───────────────────────────────────────────

export interface ImportOrdersOptions {
  sheet: ParsedSheet
  columnMapping: ImportColumn[]
  mode: 'replace' | 'merge'
  existingOrders: Order[]
}

export function importOrders(options: ImportOrdersOptions): {
  orders: Order[]
  result: ImportResult
} {
  const { sheet, columnMapping, mode, existingOrders } = options
  const errors: ImportError[] = []
  const warnings: string[] = []
  const importedOrders: Order[] = []
  const now = new Date().toISOString()

  // Build field-to-column map
  const fieldMap: Record<string, string> = {}
  for (const col of columnMapping) {
    if (col.targetField) fieldMap[col.targetField] = col.sourceColumn
  }

  const existingNumbers = new Set(existingOrders.map((o) => o.orderNumber))

  for (let rowIndex = 0; rowIndex < sheet.rows.length; rowIndex++) {
    const row = sheet.rows[rowIndex]
    const rowNum = rowIndex + 2 // +2 for header row + 1-indexing

    const get = (field: string): unknown => row[fieldMap[field] ?? field] ?? ''

    // Required fields validation
    const orderNumber = String(get('orderNumber') || get('رقم الأمر') || '').trim()
    const customerName = String(get('customerName') || get('اسم العميل') || '').trim()

    if (!orderNumber) {
      errors.push({ row: rowNum, field: 'orderNumber', value: '', message: 'رقم الأمر مطلوب' })
      continue
    }

    if (!customerName) {
      errors.push({ row: rowNum, field: 'customerName', value: '', message: 'اسم العميل مطلوب' })
      continue
    }

    // Skip duplicates in merge mode
    if (mode === 'merge' && existingNumbers.has(orderNumber)) {
      warnings.push(`الصف ${rowNum}: الأمر ${orderNumber} موجود مسبقاً، تم تخطيه`)
      continue
    }

    const deliveryDateRaw = get('requestedDeliveryDate') || get('تاريخ التسليم') || get('Delivery Date')
    const deliveryDate = parseDate(deliveryDateRaw)

    const weightKg = parseNumber(get('totalWeightKg') || get('الوزن') || get('Weight'))
    const volumeM3 = parseNumber(get('totalVolumeM3') || get('الحجم') || get('Volume'))

    // Map status
    const rawStatus = String(get('status') || get('الحالة') || 'pending').toLowerCase()
    const statusMap: Record<string, Order['status']> = {
      'pending': 'pending', 'قيد الانتظار': 'pending',
      'confirmed': 'confirmed', 'مؤكد': 'confirmed',
      'assigned': 'assigned', 'تم التعيين': 'assigned',
      'in_transit': 'in_transit', 'في الطريق': 'in_transit',
      'delivered': 'delivered', 'تم التسليم': 'delivered',
      'cancelled': 'cancelled', 'ملغي': 'cancelled',
    }
    const status = statusMap[rawStatus] ?? 'pending'

    const priorityRaw = String(get('priority') || get('الأولوية') || 'medium').toLowerCase()
    const priorityMap: Record<string, Order['priority']> = {
      'low': 'low', 'منخفض': 'low',
      'medium': 'medium', 'متوسط': 'medium',
      'high': 'high', 'عالي': 'high',
      'urgent': 'urgent', 'عاجل': 'urgent',
    }
    const priority = priorityMap[priorityRaw] ?? 'medium'

    const order: Order = {
      id: generateId(),
      orderNumber,
      externalRef: String(get('externalRef') || get('المرجع الخارجي') || ''),
      customerId: String(get('customerId') || ''),
      customerName,
      customerCity: String(get('customerCity') || get('المدينة') || get('City') || ''),
      customerAddress: String(get('customerAddress') || get('العنوان') || get('Address') || ''),
      coordinates: null,
      zone: String(get('zone') || get('المنطقة') || get('Zone') || ''),
      region: String(get('region') || get('المنطقة الإدارية') || ''),
      status,
      priority,
      items: [],
      totalWeightKg: weightKg,
      totalVolumeM3: volumeM3,
      totalItems: parseNumber(get('totalItems') || get('عدد القطع') || 1),
      requestedDeliveryDate: deliveryDate,
      confirmedDeliveryDate: null,
      actualDeliveryDate: null,
      assignedTripId: null,
      assignedDriverId: null,
      notes: String(get('notes') || get('ملاحظات') || get('Notes') || ''),
      internalNotes: '',
      createdAt: now,
      updatedAt: now,
      importedAt: now,
      importSource: 'dynamics_excel',
    }

    importedOrders.push(order)
    existingNumbers.add(orderNumber)
  }

  const result: ImportResult = {
    id: generateId(),
    type: 'orders',
    fileName: '',
    totalRows: sheet.rows.length,
    importedRows: importedOrders.length,
    skippedRows: sheet.rows.length - importedOrders.length - errors.length,
    errors,
    warnings,
    importedAt: now,
    mode,
  }

  return { orders: importedOrders, result }
}

// ─── EXPORT TO EXCEL ─────────────────────────────────────────

export function exportToExcel<T extends Record<string, unknown>>(
  data: T[],
  filename: string,
  sheetName = 'Sheet1'
): void {
  const ws = XLSX.utils.json_to_sheet(data)
  const wb = XLSX.utils.book_new()
  XLSX.utils.book_append_sheet(wb, ws, sheetName)
  XLSX.writeFile(wb, `${filename}.xlsx`)
}
