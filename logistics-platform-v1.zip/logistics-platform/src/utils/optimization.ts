// ============================================================
// SMART OPTIMIZATION ENGINE
// Weekly planner, route grouping, truck recommender
// All logic configurable from settings — zero hardcoded values
// ============================================================

import { generateId, calcTruckUtilization, suggestTripGroups, calcTripOvertime } from '@/utils'
import type {
  Order, Truck, Trip, WeeklyPlan, WeeklyPlanDay,
  PlanRecommendation, AppSettings
} from '@/types'
import { addDays, format, parseISO, startOfWeek, endOfWeek } from 'date-fns'

// ─── DISTANCE ESTIMATION ─────────────────────────────────────
// Haversine formula — accurate great-circle distance

export function haversineKm(
  lat1: number, lng1: number,
  lat2: number, lng2: number
): number {
  const R = 6371
  const dLat = ((lat2 - lat1) * Math.PI) / 180
  const dLng = ((lng2 - lng1) * Math.PI) / 180
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos((lat1 * Math.PI) / 180) *
    Math.cos((lat2 * Math.PI) / 180) *
    Math.sin(dLng / 2) ** 2
  return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
}

// Estimate distance from city name (fallback when no GPS coords)
const CITY_DISTANCES_FROM_WAREHOUSE: Record<string, number> = {
  'أبها': 0,
  'خميس مشيط': 25,
  'بيشة': 180,
  'نجران': 220,
  'جازان': 190,
  'ظهران الجنوب': 35,
  'محايل عسير': 120,
  'الباحة': 280,
  'القنفذة': 310,
}

export function estimateDistanceKm(
  order: Order,
  warehouseLat: number,
  warehouseLng: number
): number {
  if (order.coordinates) {
    return haversineKm(
      warehouseLat, warehouseLng,
      order.coordinates.lat, order.coordinates.lng
    )
  }
  return CITY_DISTANCES_FROM_WAREHOUSE[order.customerCity] ?? 50
}

// ─── ROUTE OPTIMIZATION ──────────────────────────────────────
// Nearest-neighbour TSP heuristic for stop sequencing

export function optimizeStopSequence(
  orders: Order[],
  warehouseLat: number,
  warehouseLng: number
): Order[] {
  if (orders.length <= 1) return orders

  const withCoords = orders.filter((o) => o.coordinates)
  const withoutCoords = orders.filter((o) => !o.coordinates)

  if (withCoords.length === 0) return orders

  const visited = new Set<string>()
  const result: Order[] = []
  let currentLat = warehouseLat
  let currentLng = warehouseLng

  while (result.length < withCoords.length) {
    let nearest: Order | null = null
    let nearestDist = Infinity

    for (const order of withCoords) {
      if (visited.has(order.id)) continue
      const d = haversineKm(
        currentLat, currentLng,
        order.coordinates!.lat, order.coordinates!.lng
      )
      if (d < nearestDist) {
        nearestDist = d
        nearest = order
      }
    }

    if (!nearest) break
    visited.add(nearest.id)
    result.push(nearest)
    currentLat = nearest.coordinates!.lat
    currentLng = nearest.coordinates!.lng
  }

  return [...result, ...withoutCoords]
}

// ─── TRIP BUILDER ────────────────────────────────────────────

export function buildTripsForDay(
  orders: Order[],
  trucks: Truck[],
  settings: AppSettings,
  date: string
): Partial<Trip>[] {
  if (!orders.length || !trucks.length) return []

  const groups = suggestTripGroups(orders, settings.maxOrdersPerTrip)
  const trips: Partial<Trip>[] = []

  for (const group of groups) {
    const totalWeight = group.reduce((s, o) => s + o.totalWeightKg, 0)
    const totalVolume = group.reduce((s, o) => s + o.totalVolumeM3, 0)

    // Find best truck
    const eligible = trucks
      .filter((t) => t.isActive && t.maxWeightKg >= totalWeight && t.cargoVolumeM3 >= totalVolume)
      .map((t) => ({ truck: t, util: calcTruckUtilization(t, totalWeight, totalVolume) }))
      .sort((a, b) => b.util.overallUtilizationPct - a.util.overallUtilizationPct)

    const bestTruck = eligible[0]?.truck ?? null

    const warehouseLat = settings.warehouseLocation?.lat ?? 18.2
    const warehouseLng = settings.warehouseLocation?.lng ?? 42.5
    const optimized = optimizeStopSequence(group, warehouseLat, warehouseLng)

    const totalDistance = optimized.reduce((sum, o, i) => {
      const from = i === 0
        ? { lat: warehouseLat, lng: warehouseLng }
        : optimized[i - 1].coordinates ?? { lat: warehouseLat, lng: warehouseLng }
      const to = o.coordinates ?? { lat: warehouseLat, lng: warehouseLng }
      return sum + haversineKm(from.lat, from.lng, to.lat, to.lng)
    }, 0)

    const returnDistance = estimateDistanceKm(optimized[optimized.length - 1] ?? group[0], warehouseLat, warehouseLng)

    const overtimeCalc = calcTripOvertime(settings, {
      distanceOutboundKm: totalDistance,
      distanceReturnKm: returnDistance,
      stopCount: group.length,
    })

    trips.push({
      id: generateId(),
      date,
      orderIds: group.map((o) => o.id),
      truckId: bestTruck?.id ?? null,
      truckPlate: bestTruck?.plateNumber ?? '',
      driverName: '',
      totalWeightKg: totalWeight,
      totalVolumeM3: totalVolume,
      weightUtilizationPct: bestTruck
        ? calcTruckUtilization(bestTruck, totalWeight, totalVolume).weightUtilizationPct
        : 0,
      volumeUtilizationPct: bestTruck
        ? calcTruckUtilization(bestTruck, totalWeight, totalVolume).volumeUtilizationPct
        : 0,
      totalDistanceKm: totalDistance + returnDistance,
      estimatedDurationMinutes: Math.round(overtimeCalc.totalTripMinutes),
      overtimeMinutes: Math.round(overtimeCalc.overtimeMinutes),
      status: 'planned',
    })
  }

  return trips
}

// ─── WEEKLY PLAN GENERATOR ───────────────────────────────────

export function generateWeeklyPlan(
  orders: Order[],
  trucks: Truck[],
  settings: AppSettings,
  weekStartDate: string
): WeeklyPlan {
  const start = parseISO(weekStartDate)
  const end = addDays(start, 6)

  const days: WeeklyPlanDay[] = []
  const recommendations: PlanRecommendation[] = []

  for (let i = 0; i < 7; i++) {
    const date = format(addDays(start, i), 'yyyy-MM-dd')
    const dayOfWeek = (start.getDay() + i) % 7
    const isWorkingDay = settings.workingDays.includes(dayOfWeek)

    const dayOrders = orders.filter(
      (o) =>
        o.requestedDeliveryDate.slice(0, 10) === date &&
        o.status !== 'cancelled' &&
        o.status !== 'delivered'
    )

    const dayTrips = isWorkingDay
      ? buildTripsForDay(dayOrders, trucks, settings, date)
      : []

    const totalWeight = dayOrders.reduce((s, o) => s + o.totalWeightKg, 0)
    const totalVolume = dayOrders.reduce((s, o) => s + o.totalVolumeM3, 0)
    const estimatedOvertime = dayTrips.reduce(
      (s, t) => s + (t.overtimeMinutes ?? 0),
      0
    )

    const avgUtil =
      dayTrips.length > 0
        ? dayTrips.reduce(
            (s, t) =>
              s + Math.max(t.weightUtilizationPct ?? 0, t.volumeUtilizationPct ?? 0),
            0
          ) / dayTrips.length
        : 0

    const warnings: string[] = []

    if (!isWorkingDay) {
      warnings.push('يوم إجازة — لا رحلات مجدولة')
    }

    if (dayOrders.length > settings.maxOrdersPerTrip * settings.maxTripsPerDriverPerDay * trucks.filter((t) => t.isActive).length) {
      warnings.push('تحذير: عدد الطلبات يتجاوز الطاقة الاستيعابية للأسطول')
    }

    if (estimatedOvertime > 60) {
      warnings.push(`تحذير: وقت إضافي متوقع ${Math.round(estimatedOvertime / 60)} ساعة`)
    }

    if (avgUtil < settings.utilizationWarningThreshold && dayTrips.length > 0) {
      warnings.push(`تحذير: متوسط استغلال الشاحنة منخفض (${Math.round(avgUtil * 100)}%)`)

      // Generate recommendation to merge trips
      recommendations.push({
        id: generateId(),
        type: 'merge_trips',
        priority: 'medium',
        titleAr: `دمج رحلات ${date}`,
        titleEn: `Merge trips for ${date}`,
        descriptionAr: `استغلال الشاحنات في ${date} منخفض (${Math.round(avgUtil * 100)}%). يُنصح بدمج الرحلات لتحسين الاستغلال.`,
        descriptionEn: `Truck utilization on ${date} is low (${Math.round(avgUtil * 100)}%). Consider merging trips.`,
        affectedTripIds: [],
        affectedOrderIds: dayOrders.map((o) => o.id),
        estimatedSavingMinutes: 30,
        estimatedSavingKm: 20,
        applied: false,
      })
    }

    days.push({
      date,
      dayOfWeek,
      orders: dayOrders,
      trips: dayTrips as Trip[],
      totalOrders: dayOrders.length,
      totalTrips: dayTrips.length,
      totalWeightKg: totalWeight,
      totalVolumeM3: totalVolume,
      estimatedOvertimeMinutes: estimatedOvertime,
      isOverloaded: warnings.some((w) => w.startsWith('تحذير: عدد')),
      availableTrucks: trucks.filter((t) => t.isActive).map((t) => t.id),
      utilizationPct: avgUtil,
      warnings,
    })
  }

  const totalOrders = days.reduce((s, d) => s + d.totalOrders, 0)
  const totalTrips = days.reduce((s, d) => s + d.totalTrips, 0)
  const predictedOvertime = days.reduce(
    (s, d) => s + d.estimatedOvertimeMinutes,
    0
  )
  const avgUtilization =
    days.filter((d) => d.totalTrips > 0).reduce(
      (s, d) => s + d.utilizationPct,
      0
    ) / Math.max(1, days.filter((d) => d.totalTrips > 0).length)

  // High overtime recommendation
  if (predictedOvertime > 120) {
    recommendations.push({
      id: generateId(),
      type: 'add_truck',
      priority: 'high',
      titleAr: 'إضافة شاحنة إضافية للأسبوع',
      titleEn: 'Add extra truck for the week',
      descriptionAr: `الوقت الإضافي المتوقع للأسبوع هو ${Math.round(predictedOvertime / 60)} ساعة. إضافة شاحنة ستقلل الضغط وتخفض التكاليف.`,
      descriptionEn: `Predicted overtime is ${Math.round(predictedOvertime / 60)} hours. Adding a truck reduces pressure.`,
      affectedTripIds: [],
      affectedOrderIds: [],
      estimatedSavingMinutes: predictedOvertime * 0.4,
      estimatedSavingKm: 0,
      applied: false,
    })
  }

  return {
    id: generateId(),
    weekStartDate: format(start, 'yyyy-MM-dd'),
    weekEndDate: format(end, 'yyyy-MM-dd'),
    status: 'draft',
    days,
    totalOrders,
    totalTrips,
    totalDistanceKm: days.reduce(
      (s, d) => s + d.trips.reduce((ts, t) => ts + (t.totalDistanceKm ?? 0), 0),
      0
    ),
    avgUtilizationPct: avgUtilization,
    predictedOvertimeHours: predictedOvertime / 60,
    recommendations,
    createdBy: 'system',
    createdAt: new Date().toISOString(),
    approvedAt: null,
  }
}

// ─── 2D BIN PACKING ──────────────────────────────────────────
// Guillotine algorithm for truck loading simulation

export interface Rect { w: number; h: number }
export interface PlacedRect extends Rect { x: number; y: number; id: string; rotation: 0 | 90 }

interface FreeRect { x: number; y: number; w: number; h: number }

export function guillotinePack(
  binW: number,
  binH: number,
  items: Array<{ id: string; w: number; h: number }>
): { placed: PlacedRect[]; unplaced: Array<{ id: string; w: number; h: number }> } {
  const freeRects: FreeRect[] = [{ x: 0, y: 0, w: binW, h: binH }]
  const placed: PlacedRect[] = []
  const unplaced: typeof items = []

  for (const item of items) {
    let best: { freeIdx: number; rotation: 0 | 90; score: number } | null = null

    for (let fi = 0; fi < freeRects.length; fi++) {
      const free = freeRects[fi]

      const fits0 = item.w <= free.w && item.h <= free.h
      const fits90 = item.h <= free.w && item.w <= free.h

      for (const rotation of ([0, 90] as const)) {
        const w = rotation === 0 ? item.w : item.h
        const h = rotation === 0 ? item.h : item.w
        if (w > free.w || h > free.h) continue

        // Score: minimize wasted space (best-short-side fit)
        const score = Math.min(free.w - w, free.h - h)

        if (!best || score < best.score) {
          best = { freeIdx: fi, rotation, score }
        }
      }
    }

    if (!best) {
      unplaced.push(item)
      continue
    }

    const free = freeRects[best.freeIdx]
    const w = best.rotation === 0 ? item.w : item.h
    const h = best.rotation === 0 ? item.h : item.w

    placed.push({ id: item.id, x: free.x, y: free.y, w, h, rotation: best.rotation })

    // Split free rectangle (guillotine split)
    const rightRect: FreeRect = {
      x: free.x + w,
      y: free.y,
      w: free.w - w,
      h: h,
    }
    const topRect: FreeRect = {
      x: free.x,
      y: free.y + h,
      w: free.w,
      h: free.h - h,
    }

    freeRects.splice(best.freeIdx, 1)
    if (rightRect.w > 0 && rightRect.h > 0) freeRects.push(rightRect)
    if (topRect.w > 0 && topRect.h > 0) freeRects.push(topRect)
  }

  return { placed, unplaced }
}
