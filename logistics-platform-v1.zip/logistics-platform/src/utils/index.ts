// ============================================================
// UTILITY FUNCTIONS
// Pure functions — no side effects, fully typed
// ============================================================

import { format, parseISO, differenceInMinutes, addMinutes } from 'date-fns'
import { ar } from 'date-fns/locale'
import type { Order, Trip, Truck, AppSettings, OvertimeRecord } from '@/types'

// ─── ID GENERATION ───────────────────────────────────────────

export function generateId(): string {
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 9)}`
}

export function generateOrderNumber(existing: string[]): string {
  const year = new Date().getFullYear()
  const max = existing
    .filter((n) => n.startsWith(`ORD-${year}`))
    .map((n) => parseInt(n.split('-')[2] || '0'))
    .reduce((a, b) => Math.max(a, b), 0)
  return `ORD-${year}-${String(max + 1).padStart(5, '0')}`
}

export function generateTripNumber(existing: string[]): string {
  const year = new Date().getFullYear()
  const max = existing
    .filter((n) => n.startsWith(`TRIP-${year}`))
    .map((n) => parseInt(n.split('-')[2] || '0'))
    .reduce((a, b) => Math.max(a, b), 0)
  return `TRIP-${year}-${String(max + 1).padStart(4, '0')}`
}

// ─── VOLUME CALCULATION ──────────────────────────────────────

export function calcVolumeM3(
  lengthCm: number,
  widthCm: number,
  heightCm: number
): number {
  return parseFloat(((lengthCm * widthCm * heightCm) / 1_000_000).toFixed(4))
}

// ─── TRUCK UTILIZATION ───────────────────────────────────────

export interface UtilizationResult {
  weightUtilizationPct: number
  volumeUtilizationPct: number
  overallUtilizationPct: number
  weightExceeded: boolean
  volumeExceeded: boolean
  remainingWeightKg: number
  remainingVolumeM3: number
}

export function calcTruckUtilization(
  truck: Truck,
  totalWeightKg: number,
  totalVolumeM3: number
): UtilizationResult {
  const weightPct = totalWeightKg / truck.maxWeightKg
  const volumePct = totalVolumeM3 / truck.cargoVolumeM3

  return {
    weightUtilizationPct: Math.min(weightPct, 1),
    volumeUtilizationPct: Math.min(volumePct, 1),
    overallUtilizationPct: Math.max(weightPct, volumePct),
    weightExceeded: weightPct > 1,
    volumeExceeded: volumePct > 1,
    remainingWeightKg: Math.max(0, truck.maxWeightKg - totalWeightKg),
    remainingVolumeM3: Math.max(0, truck.cargoVolumeM3 - totalVolumeM3),
  }
}

// ─── OVERTIME CALCULATION ─────────────────────────────────────

export interface OvertimeCalculationInput {
  distanceOutboundKm: number
  distanceReturnKm: number
  avgSpeedKmh: number
  loadingTimeMinutes: number
  unloadingTimeMinutes: number
  breakTimeMinutes: number
  workingMinutesPerDay: number
  stopCount: number
}

export interface OvertimeCalculationResult {
  totalTripMinutes: number
  drivingMinutes: number
  loadingTotalMinutes: number
  overtimeMinutes: number
  estimatedReturnTime: Date
  departureTime: Date
}

export function calcTripOvertime(
  settings: AppSettings,
  input: Omit<OvertimeCalculationInput, 'avgSpeedKmh' | 'loadingTimeMinutes' | 'unloadingTimeMinutes' | 'breakTimeMinutes' | 'workingMinutesPerDay'>
): OvertimeCalculationResult {
  const avgSpeed = settings.averageTruckSpeedKmh
  const loading = settings.loadingTimeMinutes
  const unloading = settings.unloadingTimeMinutes * input.stopCount
  const breakTime = settings.breakTimeMinutes

  // Parse working hours
  const [startH, startM] = settings.workingHoursStart.split(':').map(Number)
  const [endH, endM] = settings.workingHoursEnd.split(':').map(Number)
  const workingMinutes = (endH * 60 + endM) - (startH * 60 + startM)

  const drivingMinutes = ((input.distanceOutboundKm + input.distanceReturnKm) / avgSpeed) * 60
  const loadingTotalMinutes = loading + unloading + breakTime
  const totalTripMinutes = drivingMinutes + loadingTotalMinutes

  const today = new Date()
  const departure = new Date(today)
  departure.setHours(startH, startM, 0, 0)

  const estimatedReturn = addMinutes(departure, totalTripMinutes)
  const overtimeMinutes = Math.max(0, totalTripMinutes - workingMinutes)

  return {
    totalTripMinutes,
    drivingMinutes,
    loadingTotalMinutes,
    overtimeMinutes,
    estimatedReturnTime: estimatedReturn,
    departureTime: departure,
  }
}

// ─── ORDER AGGREGATIONS ──────────────────────────────────────

export function aggregateOrderTotals(orders: Order[]) {
  return orders.reduce(
    (acc, o) => ({
      totalWeight: acc.totalWeight + o.totalWeightKg,
      totalVolume: acc.totalVolume + o.totalVolumeM3,
      totalItems: acc.totalItems + o.totalItems,
    }),
    { totalWeight: 0, totalVolume: 0, totalItems: 0 }
  )
}

export function groupOrdersByDate(orders: Order[]): Record<string, Order[]> {
  return orders.reduce((acc, order) => {
    const date = order.requestedDeliveryDate.slice(0, 10)
    if (!acc[date]) acc[date] = []
    acc[date].push(order)
    return acc
  }, {} as Record<string, Order[]>)
}

export function groupOrdersByZone(orders: Order[]): Record<string, Order[]> {
  return orders.reduce((acc, order) => {
    const zone = order.zone || order.customerCity || 'غير محدد'
    if (!acc[zone]) acc[zone] = []
    acc[zone].push(order)
    return acc
  }, {} as Record<string, Order[]>)
}

// ─── TRIP GROUPING SUGGESTION ────────────────────────────────
// Simple greedy nearest-neighbour for same-day grouping

export function suggestTripGroups(
  orders: Order[],
  maxPerTrip: number
): Order[][] {
  if (!orders.length) return []

  // Group by zone first (simplest optimization)
  const byZone = groupOrdersByZone(orders)
  const groups: Order[][] = []

  for (const zone of Object.keys(byZone)) {
    const zoneOrders = byZone[zone]
    for (let i = 0; i < zoneOrders.length; i += maxPerTrip) {
      groups.push(zoneOrders.slice(i, i + maxPerTrip))
    }
  }

  return groups
}

// ─── BEST TRUCK RECOMMENDER ──────────────────────────────────

export function recommendBestTruck(
  trucks: Truck[],
  totalWeightKg: number,
  totalVolumeM3: number
): { truck: Truck; utilization: UtilizationResult } | null {
  const eligible = trucks
    .filter(
      (t) =>
        t.isActive &&
        t.maxWeightKg >= totalWeightKg &&
        t.cargoVolumeM3 >= totalVolumeM3
    )
    .map((t) => ({
      truck: t,
      utilization: calcTruckUtilization(t, totalWeightKg, totalVolumeM3),
    }))
    .sort(
      (a, b) =>
        b.utilization.overallUtilizationPct -
        a.utilization.overallUtilizationPct
    )

  return eligible[0] || null
}

// ─── DATE / TIME FORMATTING ──────────────────────────────────

export function formatDate(dateStr: string, lang: 'ar' | 'en' = 'ar'): string {
  try {
    const date = parseISO(dateStr)
    return format(date, 'd MMMM yyyy', { locale: lang === 'ar' ? ar : undefined })
  } catch {
    return dateStr
  }
}

export function formatDateTime(
  dateStr: string,
  lang: 'ar' | 'en' = 'ar'
): string {
  try {
    const date = parseISO(dateStr)
    return format(date, 'd MMM yyyy، hh:mm a', {
      locale: lang === 'ar' ? ar : undefined,
    })
  } catch {
    return dateStr
  }
}

export function formatDuration(minutes: number): string {
  const h = Math.floor(minutes / 60)
  const m = minutes % 60
  if (h === 0) return `${m} د`
  if (m === 0) return `${h} س`
  return `${h} س ${m} د`
}

export function formatOvertimeMinutes(minutes: number): string {
  if (minutes <= 0) return '—'
  return formatDuration(minutes)
}

// ─── NUMBER FORMATTING ───────────────────────────────────────

export function formatNumber(
  value: number,
  decimals = 0,
  lang: 'ar' | 'en' = 'ar'
): string {
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals,
  }).format(value)
}

export function formatSAR(amount: number, lang: 'ar' | 'en' = 'ar'): string {
  return new Intl.NumberFormat(lang === 'ar' ? 'ar-SA' : 'en-US', {
    style: 'currency',
    currency: 'SAR',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount)
}

export function formatPercent(value: number, decimals = 1): string {
  return `${(value * 100).toFixed(decimals)}%`
}

export function formatWeight(kg: number, unit: 'kg' | 'ton' = 'kg'): string {
  if (unit === 'ton') return `${(kg / 1000).toFixed(2)} طن`
  if (kg >= 1000) return `${(kg / 1000).toFixed(1)} طن`
  return `${kg.toFixed(0)} كجم`
}

export function formatVolume(m3: number): string {
  return `${m3.toFixed(3)} م³`
}

export function formatDistance(km: number): string {
  return `${km.toFixed(1)} كم`
}

// ─── STATUS HELPERS ───────────────────────────────────────────

export const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: 'قيد الانتظار',
  confirmed: 'مؤكد',
  assigned: 'تم التعيين',
  in_transit: 'في الطريق',
  delivered: 'تم التسليم',
  cancelled: 'ملغي',
  delayed: 'متأخر',
  returned: 'مُعاد',
}

export const TRIP_STATUS_LABELS: Record<string, string> = {
  planned: 'مخطط',
  loading: 'جاري التحميل',
  in_transit: 'في الطريق',
  completed: 'مكتمل',
  cancelled: 'ملغي',
  delayed: 'متأخر',
}

export const ORDER_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  confirmed: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  assigned: 'bg-purple-100 text-purple-800 dark:bg-purple-900/30 dark:text-purple-400',
  in_transit: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  delivered: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  cancelled: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400',
  delayed: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
  returned: 'bg-slate-100 text-slate-800 dark:bg-slate-800 dark:text-slate-400',
}

export const TRIP_STATUS_COLORS: Record<string, string> = {
  planned: 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400',
  loading: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-400',
  in_transit: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-400',
  completed: 'bg-green-100 text-green-800 dark:bg-green-900/30 dark:text-green-400',
  cancelled: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400',
  delayed: 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400',
}

// ─── VALIDATION ───────────────────────────────────────────────

export function isValidCoordinates(
  lat: number,
  lng: number
): boolean {
  return lat >= -90 && lat <= 90 && lng >= -180 && lng <= 180
}

export function isOverdue(deliveryDate: string): boolean {
  const today = new Date()
  today.setHours(0, 0, 0, 0)
  return parseISO(deliveryDate) < today
}

export function isDueToday(deliveryDate: string): boolean {
  const today = new Date().toISOString().slice(0, 10)
  return deliveryDate.slice(0, 10) === today
}

// ─── EXCEL COLUMN MAPPING ────────────────────────────────────

export const DYNAMICS_ORDER_COLUMN_MAP: Record<string, string> = {
  'رقم الأمر': 'orderNumber',
  'Order Number': 'orderNumber',
  'اسم العميل': 'customerName',
  'Customer Name': 'customerName',
  'المدينة': 'customerCity',
  'City': 'customerCity',
  'العنوان': 'customerAddress',
  'Address': 'customerAddress',
  'تاريخ التسليم': 'requestedDeliveryDate',
  'Delivery Date': 'requestedDeliveryDate',
  'الوزن': 'totalWeightKg',
  'Weight': 'totalWeightKg',
  'الحجم': 'totalVolumeM3',
  'Volume': 'totalVolumeM3',
  'الحالة': 'status',
  'Status': 'status',
  'المنطقة': 'zone',
  'Zone': 'zone',
  'الأولوية': 'priority',
  'Priority': 'priority',
  'ملاحظات': 'notes',
  'Notes': 'notes',
}
