import { Outlet, useLocation, Link } from 'react-router-dom'
import { motion, AnimatePresence } from 'framer-motion'
import { useAppStore } from '@/store'
import { cn } from '@/lib/utils'
import {
  LayoutDashboard, Package, Truck, Route, Calendar,
  BoxSelect, Clock, Users, Wrench, BarChart3,
  Upload, Settings, ChevronLeft, ChevronRight,
  Bell, Search, Menu, TrendingUp, LogOut
} from 'lucide-react'

const NAV_ITEMS = [
  { path: '/dashboard',   labelAr: 'لوحة التحكم',       icon: LayoutDashboard,  group: 'main' },
  { path: '/orders',      labelAr: 'إدارة الطلبات',     icon: Package,          group: 'main' },
  { path: '/trips',       labelAr: 'إدارة الرحلات',     icon: Route,            group: 'main' },
  { path: '/planner',     labelAr: 'التخطيط الأسبوعي',  icon: Calendar,         group: 'planning' },
  { path: '/trucks',      labelAr: 'إدارة الأسطول',     icon: Truck,            group: 'fleet' },
  { path: '/simulator',   labelAr: 'محاكاة التحميل',    icon: BoxSelect,        group: 'fleet' },
  { path: '/overtime',    labelAr: 'الوقت الإضافي',     icon: Clock,            group: 'hr' },
  { path: '/employees',   labelAr: 'الموظفون',          icon: Users,            group: 'hr' },
  { path: '/maintenance', labelAr: 'الصيانة',           icon: Wrench,           group: 'fleet' },
  { path: '/kpi',         labelAr: 'مؤشرات الأداء',    icon: TrendingUp,       group: 'reports' },
  { path: '/reports',     labelAr: 'التقارير',          icon: BarChart3,        group: 'reports' },
  { path: '/import',      labelAr: 'استيراد البيانات',  icon: Upload,           group: 'system' },
  { path: '/settings',    labelAr: 'الإعدادات',         icon: Settings,         group: 'system' },
]

const GROUP_LABELS: Record<string, string> = {
  main: 'الرئيسية',
  planning: 'التخطيط',
  fleet: 'الأسطول',
  hr: 'الموارد البشرية',
  reports: 'التقارير والأداء',
  system: 'النظام',
}

export function AppLayout() {
  const { sidebarOpen, setSidebarOpen, settings, notifications } = useAppStore()
  const location = useLocation()
  const unread = notifications.filter((n) => !n.read).length

  const grouped = NAV_ITEMS.reduce((acc, item) => {
    if (!acc[item.group]) acc[item.group] = []
    acc[item.group].push(item)
    return acc
  }, {} as Record<string, typeof NAV_ITEMS>)

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {/* ── Sidebar ── */}
      <motion.aside
        animate={{ width: sidebarOpen ? 256 : 72 }}
        transition={{ duration: 0.25, ease: 'easeInOut' }}
        className="relative flex-shrink-0 bg-sidebar flex flex-col border-e border-sidebar-border overflow-hidden"
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-sidebar-border flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-sidebar-primary flex items-center justify-center flex-shrink-0">
            <Truck className="w-4 h-4 text-sidebar-primary-foreground" />
          </div>
          <AnimatePresence>
            {sidebarOpen && (
              <motion.div
                initial={{ opacity: 0, x: -8 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -8 }}
                transition={{ duration: 0.15 }}
                className="ms-3 overflow-hidden"
              >
                <p className="text-sidebar-foreground font-semibold text-sm leading-tight whitespace-nowrap">
                  {settings.companyNameAr}
                </p>
                <p className="text-sidebar-foreground/50 text-xs whitespace-nowrap">
                  {settings.region}
                </p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto overflow-x-hidden py-4 scrollbar-thin">
          {Object.entries(grouped).map(([group, items]) => (
            <div key={group} className="mb-2">
              {sidebarOpen && (
                <p className="px-4 py-1 text-[10px] font-semibold uppercase tracking-widest text-sidebar-foreground/40 whitespace-nowrap">
                  {GROUP_LABELS[group]}
                </p>
              )}
              {items.map((item) => {
                const Icon = item.icon
                const active = location.pathname === item.path
                return (
                  <Link
                    key={item.path}
                    to={item.path}
                    title={!sidebarOpen ? item.labelAr : undefined}
                    className={cn(
                      'flex items-center gap-3 mx-2 px-3 py-2.5 rounded-lg text-sm transition-all duration-150',
                      active
                        ? 'bg-sidebar-primary text-sidebar-primary-foreground font-medium'
                        : 'text-sidebar-foreground/70 hover:text-sidebar-foreground hover:bg-sidebar-accent'
                    )}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <AnimatePresence>
                      {sidebarOpen && (
                        <motion.span
                          initial={{ opacity: 0 }}
                          animate={{ opacity: 1 }}
                          exit={{ opacity: 0 }}
                          transition={{ duration: 0.1 }}
                          className="whitespace-nowrap overflow-hidden"
                        >
                          {item.labelAr}
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </Link>
                )
              })}
            </div>
          ))}
        </nav>

        {/* Toggle button */}
        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute -end-3 top-20 w-6 h-6 rounded-full bg-sidebar-primary text-sidebar-primary-foreground flex items-center justify-center shadow-md hover:scale-110 transition-transform z-10"
        >
          {sidebarOpen
            ? <ChevronRight className="w-3 h-3" />
            : <ChevronLeft className="w-3 h-3" />}
        </button>
      </motion.aside>

      {/* ── Main ── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Topbar */}
        <header className="h-16 border-b border-border flex items-center px-6 gap-4 bg-background/95 backdrop-blur-sm flex-shrink-0 z-10">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground hover:text-foreground md:hidden"
          >
            <Menu className="w-4 h-4" />
          </button>

          {/* Search */}
          <button className="flex-1 max-w-md flex items-center gap-2 px-3 py-2 rounded-lg border border-border bg-muted/40 text-muted-foreground text-sm hover:bg-muted transition-colors">
            <Search className="w-4 h-4" />
            <span>بحث... </span>
            <kbd className="ms-auto text-xs bg-background border border-border rounded px-1.5 py-0.5">⌘K</kbd>
          </button>

          <div className="flex items-center gap-2 ms-auto">
            {/* Notifications */}
            <button className="relative p-2 rounded-lg hover:bg-accent transition-colors text-muted-foreground hover:text-foreground">
              <Bell className="w-4 h-4" />
              {unread > 0 && (
                <span className="absolute top-1 end-1 w-4 h-4 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center">
                  {unread > 9 ? '9+' : unread}
                </span>
              )}
            </button>

            {/* Avatar */}
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <span className="text-primary-foreground text-xs font-semibold">م</span>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto overflow-x-hidden scrollbar-thin">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 6 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -6 }}
              transition={{ duration: 0.2 }}
              className="h-full"
            >
              <Outlet />
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  )
}
