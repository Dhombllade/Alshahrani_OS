// ============================================================
// LOGISTICS PLATFORM — CORE TYPE DEFINITIONS
// Single source of truth for all data shapes
// ============================================================

// ─── ENUMS ───────────────────────────────────────────────────

export type OrderStatus =
  | 'pending'
  | 'confirmed'
  | 'assigned'
  | 'in_transit'
  | 'delivered'
  | 'cancelled'
  | 'delayed'
  | 'returned'

export type TripStatus =
  | 'planned'
  | 'loading'
  | 'in_transit'
  | 'completed'
  | 'cancelled'
  | 'delayed'

export type EmployeeRole =
  | 'driver'
  | 'coordinator'
  | 'warehouse'
  | 'manager'
  | 'admin'

export type MaintenanceType =
  | 'oil_change'
  | 'tire_change'
  | 'brake_service'
  | 'engine_repair'
  | 'body_repair'
  | 'electrical'
  | 'scheduled_service'
  | 'breakdown'
  | 'other'

export type OvertimeType = 'trip' | 'internal'

export type Priority = 'low' | 'medium' | 'high' | 'urgent'

export type FuelType = 'diesel' | 'petrol' | 'electric' | 'hybrid' | 'gas'

export type WeeklyPlanStatus = 'draft' | 'approved' | 'active' | 'completed'

// ─── SETTINGS ────────────────────────────────────────────────

export interface AppSettings {
  // Company
  companyName: string
  companyNameAr: string
  companyLogo: string | null
  region: string

  // Operations
  workingHoursStart: string       // "07:00"
  workingHoursEnd: string         // "17:00"
  workingDays: number[]           // [0,1,2,3,4] = Sun-Thu
  averageTruckSpeedKmh: number
  loadingTimeMinutes: number
  unloadingTimeMinutes: number
  breakTimeMinutes: number
  overtimeThresholdMinutes: number

  // Planning
  maxTripsPerDriverPerDay: number
  maxOrdersPerTrip: number
  nearbyDeliveryRadiusKm: number
  utilizationWarningThreshold: number  // e.g. 0.6 = warn if below 60%

  // Display
  theme: 'light' | 'dark' | 'system'
  language: 'ar' | 'en'
  currency: string
  distanceUnit: 'km' | 'mi'
  weightUnit: 'kg' | 'ton'
  volumeUnit: 'm3' | 'ft3'

  // Integrations (future-ready)
  googleMapsApiKey: string
  warehouseLocation: { lat: number; lng: number; address: string } | null

  // Notifications (future-ready)
  whatsappEnabled: boolean
  emailEnabled: boolean
}

// ─── PRODUCT ─────────────────────────────────────────────────

export interface Product {
  id: string
  sku: string
  nameAr: string
  nameEn: string
  category: string
  lengthCm: number
  widthCm: number
  heightCm: number
  weightKg: number
  volumeM3: number        // auto-calculated
  isStackable: boolean
  maxStackHeight: number
  fragile: boolean
  notes: string
  createdAt: string
  updatedAt: string
}

// ─── CUSTOMER ────────────────────────────────────────────────

export interface Customer {
  id: string
  code: string
  nameAr: string
  nameEn: string
  phone: string
  email: string
  city: string
  region: string
  address: string
  coordinates: { lat: number; lng: number } | null
  zone: string
  notes: string
  createdAt: string
}

// ─── ORDER ───────────────────────────────────────────────────

export interface OrderItem {
  productId: string
  productSku: string
  productName: string
  quantity: number
  lengthCm: number
  widthCm: number
  heightCm: number
  weightKg: number
  volumeM3: number
  isStackable: boolean
  fragile: boolean
}

export interface Order {
  id: string
  orderNumber: string
  externalRef: string           // Dynamics / ERP reference
  customerId: string
  customerName: string
  customerCity: string
  customerAddress: string
  coordinates: { lat: number; lng: number } | null
  zone: string
  region: string

  status: OrderStatus
  priority: Priority

  items: OrderItem[]
  totalWeightKg: number         // auto-calculated
  totalVolumeM3: number         // auto-calculated
  totalItems: number

  requestedDeliveryDate: string // ISO date
  confirmedDeliveryDate: string | null
  actualDeliveryDate: string | null

  assignedTripId: string | null
  assignedDriverId: string | null

  notes: string
  internalNotes: string

  createdAt: string
  updatedAt: string
  importedAt: string
  importSource: string          // "dynamics_excel" | "manual" | "csv"
}

// ─── TRUCK ───────────────────────────────────────────────────

export interface Truck {
  id: string
  plateNumber: string
  name: string
  type: string                  // e.g. "مديوم", "كبير", "بيك آب"

  // Dimensions (cargo area)
  cargoLengthCm: number
  cargoWidthCm: number
  cargoHeightCm: number
  cargoVolumeM3: number         // auto-calculated

  maxWeightKg: number
  fuelType: FuelType

  driverId: string | null       // default assigned driver
  isActive: boolean
  isAvailable: boolean

  // Maintenance tracking
  lastMaintenanceDate: string | null
  nextMaintenanceDate: string | null
  nextMaintenanceKm: number | null
  currentOdometerKm: number

  notes: string
  createdAt: string
  updatedAt: string
}

// ─── DRIVER / EMPLOYEE ───────────────────────────────────────

export interface Employee {
  id: string
  employeeNumber: string
  nameAr: string
  nameEn: string
  role: EmployeeRole
  department: string
  phone: string
  email: string
  licenseNumber: string | null  // drivers only
  licenseExpiry: string | null
  isActive: boolean
  hireDate: string
  notes: string
  createdAt: string
  updatedAt: string
}

// ─── TRIP ────────────────────────────────────────────────────

export interface TripStop {
  id: string
  orderId: string
  orderNumber: string
  customerName: string
  address: string
  coordinates: { lat: number; lng: number } | null
  sequence: number
  estimatedArrival: string | null
  actualArrival: string | null
  status: 'pending' | 'arrived' | 'delivered' | 'failed'
  notes: string
}

export interface Trip {
  id: string
  tripNumber: string

  driverId: string | null
  driverName: string
  truckId: string | null
  truckPlate: string

  status: TripStatus
  date: string                  // ISO date

  stops: TripStop[]
  orderIds: string[]

  // Cargo summary
  totalWeightKg: number
  totalVolumeM3: number
  weightUtilizationPct: number
  volumeUtilizationPct: number

  // Route
  warehouseLocation: { lat: number; lng: number } | null
  totalDistanceKm: number
  estimatedDurationMinutes: number
  estimatedReturnTime: string | null

  // Overtime calculation
  departureTime: string | null
  actualReturnTime: string | null
  scheduledEndTime: string      // from settings working hours
  overtimeMinutes: number       // auto-calculated
  overtimeReason: string

  notes: string
  createdAt: string
  updatedAt: string
}

// ─── OVERTIME ────────────────────────────────────────────────

export interface OvertimeRecord {
  id: string
  type: OvertimeType
  employeeId: string
  employeeName: string
  date: string

  // Trip overtime (auto-calculated)
  tripId: string | null
  tripNumber: string | null
  distanceOutboundKm: number
  distanceReturnKm: number
  avgSpeedKmh: number
  loadingMinutes: number
  unloadingMinutes: number
  totalTripMinutes: number
  workingMinutes: number
  overtimeMinutes: number

  // Internal overtime (manual)
  manualOvertimeHours: number
  reason: string

  approvedBy: string | null
  approvedAt: string | null
  notes: string
  createdAt: string
}

// ─── MAINTENANCE ─────────────────────────────────────────────

export interface MaintenanceRecord {
  id: string
  truckId: string
  truckPlate: string
  type: MaintenanceType
  date: string
  odometerKm: number
  description: string
  repairShop: string
  costSAR: number
  nextServiceDate: string | null
  nextServiceKm: number | null
  isBreakdown: boolean
  downtimeHours: number
  notes: string
  createdAt: string
}

// ─── WEEKLY PLAN ─────────────────────────────────────────────

export interface WeeklyPlanDay {
  date: string
  dayOfWeek: number
  orders: Order[]
  trips: Trip[]
  totalOrders: number
  totalTrips: number
  totalWeightKg: number
  totalVolumeM3: number
  estimatedOvertimeMinutes: number
  isOverloaded: boolean
  availableTrucks: string[]
  utilizationPct: number
  warnings: string[]
}

export interface WeeklyPlan {
  id: string
  weekStartDate: string
  weekEndDate: string
  status: WeeklyPlanStatus
  days: WeeklyPlanDay[]

  // Summary
  totalOrders: number
  totalTrips: number
  totalDistanceKm: number
  avgUtilizationPct: number
  predictedOvertimeHours: number
  recommendations: PlanRecommendation[]

  createdBy: string
  createdAt: string
  approvedAt: string | null
}

export interface PlanRecommendation {
  id: string
  type: 'merge_trips' | 'rebalance_day' | 'add_truck' | 'reroute' | 'reschedule'
  priority: Priority
  titleAr: string
  titleEn: string
  descriptionAr: string
  descriptionEn: string
  affectedTripIds: string[]
  affectedOrderIds: string[]
  estimatedSavingMinutes: number
  estimatedSavingKm: number
  applied: boolean
}

// ─── LOADING SIMULATION ──────────────────────────────────────

export interface LoadItem {
  id: string
  productId: string
  productName: string
  quantity: number
  lengthCm: number
  widthCm: number
  heightCm: number
  weightKg: number
  volumeM3: number
  isStackable: boolean
  fragile: boolean
  color?: string               // for visualization
}

export interface PackedItem extends LoadItem {
  x: number                    // position in truck (cm from front)
  y: number                    // position (cm from left)
  z: number                    // height from floor (cm)
  rotation: 0 | 90             // 2D rotation
}

export interface LoadingSimulation {
  id: string
  truckId: string
  truck: Truck
  items: LoadItem[]
  packedItems: PackedItem[]
  unpackedItems: LoadItem[]

  // Results
  totalWeightKg: number
  totalVolumeM3: number
  weightUtilizationPct: number
  volumeUtilizationPct: number
  isFeasible: boolean
  trucksNeeded: number
  recommendedTruckId: string | null

  // Warnings
  weightExceeded: boolean
  volumeExceeded: boolean
  warnings: string[]
  suggestions: string[]

  createdAt: string
}

// ─── KPI ─────────────────────────────────────────────────────

export interface DailyKPI {
  date: string
  ordersTotal: number
  ordersDelivered: number
  ordersCancelled: number
  ordersDelayed: number
  tripsTotal: number
  tripsCompleted: number
  avgTruckUtilizationPct: number
  totalDistanceKm: number
  totalOvertimeMinutes: number
  activeDrivers: number
  activeTrucks: number
}

export interface DriverKPI {
  driverId: string
  driverName: string
  period: string
  tripsCompleted: number
  ordersDelivered: number
  totalDistanceKm: number
  totalOvertimeMinutes: number
  onTimeDeliveryPct: number
  avgUtilizationPct: number
}

// ─── IMPORT ──────────────────────────────────────────────────

export type ImportType =
  | 'orders'
  | 'trips'
  | 'products'
  | 'employees'
  | 'trucks'
  | 'customers'

export interface ImportColumn {
  sourceColumn: string
  targetField: string
  required: boolean
  transform?: string
}

export interface ImportError {
  row: number
  field: string
  value: string
  message: string
}

export interface ImportResult {
  id: string
  type: ImportType
  fileName: string
  totalRows: number
  importedRows: number
  skippedRows: number
  errors: ImportError[]
  warnings: string[]
  importedAt: string
  mode: 'replace' | 'merge'
}

// ─── GLOBAL SEARCH ───────────────────────────────────────────

export interface SearchResult {
  id: string
  type: 'order' | 'trip' | 'driver' | 'truck' | 'customer' | 'product'
  title: string
  subtitle: string
  status?: string
  href: string
}

// ─── NOTIFICATION ────────────────────────────────────────────

export interface AppNotification {
  id: string
  type: 'info' | 'warning' | 'error' | 'success'
  titleAr: string
  titleEn: string
  messageAr: string
  messageEn: string
  read: boolean
  href: string | null
  createdAt: string
}
