import { useState, useMemo } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, EmptyState, Badge, ProgressBar, StatCard } from '@/components/ui'
import { TRIP_STATUS_LABELS, TRIP_STATUS_COLORS, formatDate, formatDuration, formatWeight, formatVolume, formatDistance, generateId, generateTripNumber } from '@/utils'
import { Route, Plus, Search, Trash2, Edit2, ChevronDown, ChevronUp, MapPin, Truck, Clock, Package } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import type { Trip, TripStatus } from '@/types'

const STATUS_OPTIONS = [
  { value: '', label: 'كل الحالات' },
  ...Object.entries(TRIP_STATUS_LABELS).map(([v, l]) => ({ value: v, label: l }))
]

export function TripsPage() {
  const { trips, trucks, employees, orders, addTrip, updateTrip, deleteTrip, settings } = useAppStore()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState('')
  const [dateFilter, setDateFilter] = useState('')
  const [expandedId, setExpandedId] = useState<string | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [newTrip, setNewTrip] = useState({
    date: new Date().toISOString().slice(0, 10),
    driverId: '',
    truckId: '',
    notes: '',
  })

  const drivers = employees.filter((e) => e.role === 'driver' && e.isActive)
  const activeTrucks = trucks.filter((t) => t.isActive)

  const filtered = useMemo(() => {
    let result = [...trips]
    if (search) {
      const q = search.toLowerCase()
      result = result.filter((t) =>
        t.tripNumber?.toLowerCase().includes(q) ||
        t.driverName.toLowerCase().includes(q) ||
        t.truckPlate.toLowerCase().includes(q)
      )
    }
    if (statusFilter) result = result.filter((t) => t.status === statusFilter)
    if (dateFilter) result = result.filter((t) => t.date === dateFilter)
    return result.sort((a, b) => b.date.localeCompare(a.date))
  }, [trips, search, statusFilter, dateFilter])

  const stats = useMemo(() => ({
    total: trips.length,
    active: trips.filter((t) => t.status === 'in_transit').length,
    completed: trips.filter((t) => t.status === 'completed').length,
    delayed: trips.filter((t) => t.status === 'delayed').length,
  }), [trips])

  const handleAddTrip = () => {
    const driver = employees.find((e) => e.id === newTrip.driverId)
    const truck = trucks.find((t) => t.id === newTrip.truckId)
    const trip: Trip = {
      id: generateId(),
      tripNumber: generateTripNumber(trips.map((t) => t.tripNumber || '')),
      driverId: newTrip.driverId || null,
      driverName: driver ? driver.nameAr : '',
      truckId: newTrip.truckId || null,
      truckPlate: truck ? truck.plateNumber : '',
      status: 'planned',
      date: newTrip.date,
      stops: [],
      orderIds: [],
      totalWeightKg: 0,
      totalVolumeM3: 0,
      weightUtilizationPct: 0,
      volumeUtilizationPct: 0,
      warehouseLocation: settings.warehouseLocation,
      totalDistanceKm: 0,
      estimatedDurationMinutes: 0,
      estimatedReturnTime: null,
      departureTime: null,
      actualReturnTime: null,
      scheduledEndTime: settings.workingHoursEnd,
      overtimeMinutes: 0,
      overtimeReason: '',
      notes: newTrip.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    addTrip(trip)
    setShowForm(false)
    setNewTrip({ date: new Date().toISOString().slice(0, 10), driverId: '', truckId: '', notes: '' })
  }

  const statusActions: Record<TripStatus, TripStatus | null> = {
    planned: 'loading',
    loading: 'in_transit',
    in_transit: 'completed',
    completed: null,
    cancelled: null,
    delayed: 'in_transit',
  }

  const statusActionLabel: Record<TripStatus, string> = {
    planned: 'بدء التحميل',
    loading: 'انطلاق',
    in_transit: 'إتمام',
    completed: '',
    cancelled: '',
    delayed: 'استئناف',
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="إدارة الرحلات"
        subtitle={`${trips.length} رحلة · ${stats.active} نشطة الآن`}
        actions={
          <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowForm(true)}>
            رحلة جديدة
          </Button>
        }
      />

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="إجمالي الرحلات" value={stats.total} icon={<Route className="w-5 h-5" />} color="blue" />
        <StatCard title="نشطة الآن" value={stats.active} icon={<Truck className="w-5 h-5" />} color="orange" />
        <StatCard title="مكتملة" value={stats.completed} icon={<Route className="w-5 h-5" />} color="green" />
        <StatCard title="متأخرة" value={stats.delayed} icon={<Clock className="w-5 h-5" />} color={stats.delayed > 0 ? 'red' : 'green'} />
      </div>

      {/* New trip form */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">رحلة جديدة</h3>
                <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}>إلغاء</Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                  <Input
                    label="تاريخ الرحلة"
                    type="date"
                    value={newTrip.date}
                    onChange={(e) => setNewTrip((p) => ({ ...p, date: e.target.value }))}
                  />
                  <Select
                    label="السائق"
                    options={drivers.map((d) => ({ value: d.id, label: d.nameAr }))}
                    value={newTrip.driverId}
                    onChange={(e) => setNewTrip((p) => ({ ...p, driverId: e.target.value }))}
                    placeholder="اختر سائقاً..."
                  />
                  <Select
                    label="الشاحنة"
                    options={activeTrucks.map((t) => ({ value: t.id, label: `${t.name} — ${t.plateNumber}` }))}
                    value={newTrip.truckId}
                    onChange={(e) => setNewTrip((p) => ({ ...p, truckId: e.target.value }))}
                    placeholder="اختر شاحنة..."
                  />
                  <Input
                    label="ملاحظات"
                    value={newTrip.notes}
                    onChange={(e) => setNewTrip((p) => ({ ...p, notes: e.target.value }))}
                    placeholder="اختياري..."
                  />
                </div>
                <div className="flex justify-end mt-4 gap-2">
                  <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
                  <Button onClick={handleAddTrip} icon={<Plus className="w-4 h-4" />}>إنشاء الرحلة</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filters */}
      <Card>
        <CardContent className="py-3">
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-48">
              <Input
                placeholder="بحث برقم الرحلة، السائق، الشاحنة..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                icon={<Search className="w-3.5 h-3.5" />}
              />
            </div>
            <Select options={STATUS_OPTIONS} value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} placeholder="الحالة" className="w-36" />
            <Input type="date" value={dateFilter} onChange={(e) => setDateFilter(e.target.value)} className="w-40" />
          </div>
        </CardContent>
      </Card>

      {/* Trips list */}
      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Route className="w-6 h-6" />}
            title="لا توجد رحلات"
            description="أنشئ رحلة جديدة أو عدّل فلاتر البحث"
            action={<Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowForm(true)}>رحلة جديدة</Button>}
          />
        </Card>
      ) : (
        <div className="space-y-3">
          {filtered.map((trip) => {
            const expanded = expandedId === trip.id
            const nextStatus = statusActions[trip.status]
            const truck = trucks.find((t) => t.id === trip.truckId)

            return (
              <Card key={trip.id}>
                <button
                  onClick={() => setExpandedId(expanded ? null : trip.id)}
                  className="w-full px-6 py-4 flex items-center gap-4 hover:bg-muted/20 transition-colors text-start"
                >
                  {/* Trip number */}
                  <div className="w-28 flex-shrink-0">
                    <p className="text-sm font-semibold">{trip.tripNumber || '—'}</p>
                    <p className="text-xs text-muted-foreground">{formatDate(trip.date)}</p>
                  </div>

                  {/* Driver & Truck */}
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">السائق</p>
                      <p className="font-medium">{trip.driverName || '—'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">الشاحنة</p>
                      <p className="font-medium font-mono">{trip.truckPlate || '—'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">الطلبات / المسافة</p>
                      <p className="font-medium">{trip.orderIds.length} طلب · {trip.totalDistanceKm > 0 ? formatDistance(trip.totalDistanceKm) : '—'}</p>
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground mb-0.5">الاستغلال</p>
                      <ProgressBar value={Math.max(trip.weightUtilizationPct, trip.volumeUtilizationPct)} size="sm" showPercent />
                    </div>
                  </div>

                  {/* Status + actions */}
                  <div className="flex items-center gap-2 flex-shrink-0">
                    {trip.overtimeMinutes > 0 && (
                      <span className="text-xs text-orange-600 dark:text-orange-400 font-medium">
                        +{formatDuration(trip.overtimeMinutes)}
                      </span>
                    )}
                    <span className={`text-xs px-2.5 py-1 rounded-full font-medium ${TRIP_STATUS_COLORS[trip.status]}`}>
                      {TRIP_STATUS_LABELS[trip.status]}
                    </span>
                    {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
                  </div>
                </button>

                <AnimatePresence>
                  {expanded && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden border-t border-border"
                    >
                      <div className="px-6 py-4 grid grid-cols-1 md:grid-cols-3 gap-6">
                        {/* Details */}
                        <div className="space-y-3">
                          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide">تفاصيل الرحلة</h4>
                          <div className="space-y-2 text-sm">
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">الوزن الكلي</span>
                              <span className="font-medium">{formatWeight(trip.totalWeightKg)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">الحجم الكلي</span>
                              <span className="font-medium">{formatVolume(trip.totalVolumeM3)}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">المسافة الكلية</span>
                              <span className="font-medium">{trip.totalDistanceKm > 0 ? formatDistance(trip.totalDistanceKm) : '—'}</span>
                            </div>
                            <div className="flex justify-between">
                              <span className="text-muted-foreground">المدة المقدرة</span>
                              <span className="font-medium">{trip.estimatedDurationMinutes > 0 ? formatDuration(trip.estimatedDurationMinutes) : '—'}</span>
                            </div>
                            {trip.overtimeMinutes > 0 && (
                              <div className="flex justify-between text-orange-600 dark:text-orange-400">
                                <span>الوقت الإضافي</span>
                                <span className="font-medium">{formatDuration(trip.overtimeMinutes)}</span>
                              </div>
                            )}
                          </div>
                          {trip.notes && (
                            <p className="text-xs text-muted-foreground bg-muted/40 rounded-lg px-3 py-2">{trip.notes}</p>
                          )}
                        </div>

                        {/* Stops */}
                        <div className="md:col-span-2">
                          <h4 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-3">محطات التوصيل</h4>
                          {trip.stops.length === 0 ? (
                            <p className="text-sm text-muted-foreground">لا توجد محطات مضافة</p>
                          ) : (
                            <div className="space-y-2">
                              {trip.stops.map((stop, i) => (
                                <div key={stop.id} className="flex items-start gap-3 text-sm">
                                  <div className="w-5 h-5 rounded-full bg-primary/10 text-primary flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                                    {i + 1}
                                  </div>
                                  <div className="flex-1">
                                    <p className="font-medium">{stop.customerName}</p>
                                    <p className="text-xs text-muted-foreground">{stop.address}</p>
                                  </div>
                                  <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${
                                    stop.status === 'delivered' ? 'bg-green-100 text-green-700' :
                                    stop.status === 'arrived' ? 'bg-blue-100 text-blue-700' :
                                    stop.status === 'failed' ? 'bg-red-100 text-red-700' :
                                    'bg-muted text-muted-foreground'
                                  }`}>
                                    {stop.status === 'delivered' ? 'تم' : stop.status === 'arrived' ? 'وصل' : stop.status === 'failed' ? 'فشل' : 'انتظار'}
                                  </span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="px-6 py-3 border-t border-border flex items-center justify-between bg-muted/10">
                        <div className="flex gap-2">
                          {nextStatus && (
                            <Button
                              size="sm"
                              onClick={() => updateTrip(trip.id, { status: nextStatus, updatedAt: new Date().toISOString() })}
                            >
                              {statusActionLabel[trip.status]}
                            </Button>
                          )}
                          {trip.status !== 'completed' && trip.status !== 'cancelled' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateTrip(trip.id, { status: 'delayed' })}
                            >
                              تأخير
                            </Button>
                          )}
                          {trip.status === 'planned' && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => updateTrip(trip.id, { status: 'cancelled' })}
                            >
                              إلغاء
                            </Button>
                          )}
                        </div>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={() => deleteTrip(trip.id)}
                          icon={<Trash2 className="w-3.5 h-3.5" />}
                          className="text-destructive hover:text-destructive hover:bg-destructive/10"
                        >
                          حذف
                        </Button>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </Card>
            )
          })}
        </div>
      )}
    </div>
  )
}
