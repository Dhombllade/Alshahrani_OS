import { useState, useMemo } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, EmptyState, StatCard } from '@/components/ui'
import { calcTripOvertime, formatDuration, formatDate, formatSAR, generateId } from '@/utils'
import { Clock, Plus, Calculator, Download, Users, TrendingUp } from 'lucide-react'
import { motion } from 'framer-motion'
import type { OvertimeRecord } from '@/types'
import { exportToExcel } from '@/utils/excel'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, parseISO } from 'date-fns'
import { ar } from 'date-fns/locale'

export function OvertimePage() {
  const { overtimeRecords, addOvertimeRecord, employees, trips, settings } = useAppStore()
  const [activeTab, setActiveTab] = useState<'trip' | 'internal' | 'reports'>('trip')
  const [selectedMonth, setSelectedMonth] = useState(new Date().toISOString().slice(0, 7))

  // Trip overtime calculator form
  const [tripCalc, setTripCalc] = useState({
    employeeId: '',
    tripId: '',
    date: new Date().toISOString().slice(0, 10),
    distanceOutKm: 0,
    distanceReturnKm: 0,
    stopCount: 1,
  })

  // Internal overtime form
  const [internalForm, setInternalForm] = useState({
    employeeId: '',
    date: new Date().toISOString().slice(0, 10),
    hours: 0,
    minutes: 0,
    reason: '',
  })

  const drivers = employees.filter((e) => e.role === 'driver' && e.isActive)
  const driverOptions = drivers.map((d) => ({ value: d.id, label: d.nameAr }))

  // Calculated trip overtime preview
  const tripCalcResult = useMemo(() => {
    if (!tripCalc.distanceOutKm && !tripCalc.distanceReturnKm) return null
    return calcTripOvertime(settings, {
      distanceOutboundKm: tripCalc.distanceOutKm,
      distanceReturnKm: tripCalc.distanceReturnKm,
      stopCount: tripCalc.stopCount,
    })
  }, [tripCalc, settings])

  const handleAddTripOvertime = () => {
    if (!tripCalcResult || !tripCalc.employeeId) return
    const emp = employees.find((e) => e.id === tripCalc.employeeId)
    const record: OvertimeRecord = {
      id: generateId(),
      type: 'trip',
      employeeId: tripCalc.employeeId,
      employeeName: emp?.nameAr ?? '',
      date: tripCalc.date,
      tripId: tripCalc.tripId || null,
      tripNumber: trips.find((t) => t.id === tripCalc.tripId)?.tripNumber ?? null,
      distanceOutboundKm: tripCalc.distanceOutKm,
      distanceReturnKm: tripCalc.distanceReturnKm,
      avgSpeedKmh: settings.averageTruckSpeedKmh,
      loadingMinutes: settings.loadingTimeMinutes,
      unloadingMinutes: settings.unloadingTimeMinutes * tripCalc.stopCount,
      totalTripMinutes: tripCalcResult.totalTripMinutes,
      workingMinutes: 0,
      overtimeMinutes: tripCalcResult.overtimeMinutes,
      manualOvertimeHours: 0,
      reason: 'رحلة توصيل',
      approvedBy: null,
      approvedAt: null,
      notes: '',
      createdAt: new Date().toISOString(),
    }
    addOvertimeRecord(record)
    setTripCalc((p) => ({ ...p, distanceOutKm: 0, distanceReturnKm: 0, stopCount: 1 }))
  }

  const handleAddInternalOvertime = () => {
    if (!internalForm.employeeId || (!internalForm.hours && !internalForm.minutes)) return
    const emp = employees.find((e) => e.id === internalForm.employeeId)
    const totalMinutes = internalForm.hours * 60 + internalForm.minutes
    const record: OvertimeRecord = {
      id: generateId(),
      type: 'internal',
      employeeId: internalForm.employeeId,
      employeeName: emp?.nameAr ?? '',
      date: internalForm.date,
      tripId: null,
      tripNumber: null,
      distanceOutboundKm: 0,
      distanceReturnKm: 0,
      avgSpeedKmh: 0,
      loadingMinutes: 0,
      unloadingMinutes: 0,
      totalTripMinutes: 0,
      workingMinutes: 0,
      overtimeMinutes: totalMinutes,
      manualOvertimeHours: internalForm.hours + internalForm.minutes / 60,
      reason: internalForm.reason,
      approvedBy: null,
      approvedAt: null,
      notes: '',
      createdAt: new Date().toISOString(),
    }
    addOvertimeRecord(record)
    setInternalForm((p) => ({ ...p, hours: 0, minutes: 0, reason: '' }))
  }

  // Monthly stats
  const monthRecords = useMemo(() => {
    return overtimeRecords.filter((r) => r.date.startsWith(selectedMonth))
  }, [overtimeRecords, selectedMonth])

  const monthStats = useMemo(() => {
    const total = monthRecords.reduce((s, r) => s + r.overtimeMinutes, 0)
    const byEmployee: Record<string, { name: string; minutes: number; count: number }> = {}
    for (const r of monthRecords) {
      if (!byEmployee[r.employeeId]) byEmployee[r.employeeId] = { name: r.employeeName, minutes: 0, count: 0 }
      byEmployee[r.employeeId].minutes += r.overtimeMinutes
      byEmployee[r.employeeId].count += 1
    }
    return {
      totalMinutes: total,
      totalHours: total / 60,
      recordCount: monthRecords.length,
      byEmployee: Object.entries(byEmployee)
        .map(([id, v]) => ({ id, ...v }))
        .sort((a, b) => b.minutes - a.minutes),
    }
  }, [monthRecords])

  // Chart: daily overtime this month
  const dailyChart = useMemo(() => {
    const [year, month] = selectedMonth.split('-').map(Number)
    const start = new Date(year, month - 1, 1)
    const end = new Date(year, month, 0)
    return Array.from({ length: end.getDate() }, (_, i) => {
      const date = `${selectedMonth}-${String(i + 1).padStart(2, '0')}`
      const mins = monthRecords.filter((r) => r.date === date).reduce((s, r) => s + r.overtimeMinutes, 0)
      return { day: String(i + 1), minutes: mins, hours: +(mins / 60).toFixed(1) }
    }).filter((d) => d.minutes > 0)
  }, [monthRecords, selectedMonth])

  const handleExport = () => {
    const data = monthRecords.map((r) => ({
      'التاريخ': r.date,
      'الموظف': r.employeeName,
      'النوع': r.type === 'trip' ? 'رحلة' : 'داخلي',
      'رقم الرحلة': r.tripNumber ?? '',
      'المسافة ذهاب (كم)': r.distanceOutboundKm,
      'المسافة عودة (كم)': r.distanceReturnKm,
      'الوقت الإضافي (دقيقة)': r.overtimeMinutes,
      'الوقت الإضافي (ساعة)': (r.overtimeMinutes / 60).toFixed(2),
      'السبب': r.reason,
    }))
    exportToExcel(data, `overtime-${selectedMonth}`, 'الوقت الإضافي')
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="محرك الوقت الإضافي"
        subtitle="حساب ومتابعة الوقت الإضافي للسائقين — رحلات وداخلي"
        actions={
          <Button variant="outline" size="sm" icon={<Download className="w-3.5 h-3.5" />} onClick={handleExport}>
            تصدير الشهر
          </Button>
        }
      />

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-muted rounded-xl w-fit">
        {[
          { id: 'trip', label: 'وقت إضافي رحلة', icon: Calculator },
          { id: 'internal', label: 'وقت إضافي داخلي', icon: Clock },
          { id: 'reports', label: 'التقارير الشهرية', icon: TrendingUp },
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 text-sm font-medium rounded-lg transition-all ${
              activeTab === id
                ? 'bg-background text-foreground shadow-sm'
                : 'text-muted-foreground hover:text-foreground'
            }`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* ── Tab: Trip Overtime ── */}
      {activeTab === 'trip' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">حساب الوقت الإضافي للرحلة</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted/30 rounded-xl p-4 text-sm space-y-1 text-muted-foreground">
                <p className="font-semibold text-foreground mb-2">الصيغة المستخدمة:</p>
                <p>إجمالي الرحلة = (ذهاب + عودة) ÷ {settings.averageTruckSpeedKmh} كم/س + تحميل {settings.loadingTimeMinutes}د + تفريغ {settings.unloadingTimeMinutes}د × نقاط + راحة {settings.breakTimeMinutes}د</p>
                <p>الوقت الإضافي = إجمالي الرحلة − ساعات العمل ({settings.workingHoursStart}–{settings.workingHoursEnd})</p>
              </div>

              <Select
                label="السائق *"
                options={driverOptions}
                value={tripCalc.employeeId}
                onChange={(e) => setTripCalc((p) => ({ ...p, employeeId: e.target.value }))}
                placeholder="اختر سائقاً..."
              />

              <div className="grid grid-cols-2 gap-3">
                <Input label="تاريخ الرحلة" type="date" value={tripCalc.date} onChange={(e) => setTripCalc((p) => ({ ...p, date: e.target.value }))} />
                <Input label="عدد نقاط التوصيل" type="number" min={1} value={tripCalc.stopCount} onChange={(e) => setTripCalc((p) => ({ ...p, stopCount: +e.target.value }))} />
                <Input label="مسافة الذهاب (كم)" type="number" value={tripCalc.distanceOutKm} onChange={(e) => setTripCalc((p) => ({ ...p, distanceOutKm: +e.target.value }))} />
                <Input label="مسافة العودة (كم)" type="number" value={tripCalc.distanceReturnKm} onChange={(e) => setTripCalc((p) => ({ ...p, distanceReturnKm: +e.target.value }))} />
              </div>

              {/* Live calculation result */}
              {tripCalcResult && (
                <motion.div
                  initial={{ opacity: 0, y: 4 }}
                  animate={{ opacity: 1, y: 0 }}
                  className={`rounded-xl p-4 border ${tripCalcResult.overtimeMinutes > 0 ? 'border-orange-200 bg-orange-50 dark:bg-orange-950/20' : 'border-green-200 bg-green-50 dark:bg-green-950/20'}`}
                >
                  <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">النتيجة المحسوبة</p>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-muted-foreground">إجمالي وقت الرحلة</p>
                      <p className="font-bold text-lg">{formatDuration(Math.round(tripCalcResult.totalTripMinutes))}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">الوقت الإضافي</p>
                      <p className={`font-bold text-lg ${tripCalcResult.overtimeMinutes > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                        {tripCalcResult.overtimeMinutes > 0 ? formatDuration(Math.round(tripCalcResult.overtimeMinutes)) : 'لا يوجد'}
                      </p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">وقت القيادة</p>
                      <p className="font-medium">{formatDuration(Math.round(tripCalcResult.drivingMinutes))}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">التحميل والتفريغ</p>
                      <p className="font-medium">{formatDuration(Math.round(tripCalcResult.loadingTotalMinutes))}</p>
                    </div>
                  </div>
                </motion.div>
              )}

              <Button
                className="w-full"
                onClick={handleAddTripOvertime}
                disabled={!tripCalcResult || !tripCalc.employeeId || tripCalcResult.overtimeMinutes <= 0}
                icon={<Plus className="w-4 h-4" />}
              >
                تسجيل الوقت الإضافي
              </Button>
            </CardContent>
          </Card>

          {/* Recent trip overtime records */}
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">آخر سجلات الوقت الإضافي</h3>
            </CardHeader>
            <div className="divide-y divide-border max-h-96 overflow-y-auto scrollbar-thin">
              {overtimeRecords.filter((r) => r.type === 'trip').length === 0 ? (
                <div className="px-6 py-8 text-center text-sm text-muted-foreground">لا توجد سجلات</div>
              ) : (
                overtimeRecords
                  .filter((r) => r.type === 'trip')
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .slice(0, 15)
                  .map((record) => (
                    <div key={record.id} className="px-6 py-3 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-orange-100 dark:bg-orange-900/30 flex items-center justify-center flex-shrink-0">
                        <Clock className="w-4 h-4 text-orange-600 dark:text-orange-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{record.employeeName}</p>
                        <p className="text-xs text-muted-foreground">
                          {formatDate(record.date)} · {record.distanceOutboundKm + record.distanceReturnKm} كم
                        </p>
                      </div>
                      <div className="text-end">
                        <p className="text-sm font-semibold text-orange-600 dark:text-orange-400">
                          {formatDuration(record.overtimeMinutes)}
                        </p>
                        <p className="text-xs text-muted-foreground">وقت إضافي</p>
                      </div>
                    </div>
                  ))
              )}
            </div>
          </Card>
        </div>
      )}

      {/* ── Tab: Internal Overtime ── */}
      {activeTab === 'internal' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">إدخال وقت إضافي داخلي</h3>
            </CardHeader>
            <CardContent className="space-y-4">
              <Select
                label="الموظف *"
                options={employees.filter((e) => e.isActive).map((e) => ({ value: e.id, label: `${e.nameAr} — ${e.role === 'driver' ? 'سائق' : e.role}` }))}
                value={internalForm.employeeId}
                onChange={(e) => setInternalForm((p) => ({ ...p, employeeId: e.target.value }))}
                placeholder="اختر موظفاً..."
              />
              <Input label="التاريخ" type="date" value={internalForm.date} onChange={(e) => setInternalForm((p) => ({ ...p, date: e.target.value }))} />
              <div className="grid grid-cols-2 gap-3">
                <Input label="الساعات" type="number" min={0} value={internalForm.hours} onChange={(e) => setInternalForm((p) => ({ ...p, hours: +e.target.value }))} />
                <Input label="الدقائق" type="number" min={0} max={59} value={internalForm.minutes} onChange={(e) => setInternalForm((p) => ({ ...p, minutes: +e.target.value }))} />
              </div>
              <Input
                label="السبب / الوصف *"
                value={internalForm.reason}
                onChange={(e) => setInternalForm((p) => ({ ...p, reason: e.target.value }))}
                placeholder="مثال: استلام بضاعة طارئة، صيانة..."
              />
              {(internalForm.hours > 0 || internalForm.minutes > 0) && (
                <div className="bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/30 rounded-xl p-4">
                  <p className="text-sm text-blue-700 dark:text-blue-300 font-medium">
                    الوقت الإضافي: {formatDuration(internalForm.hours * 60 + internalForm.minutes)}
                  </p>
                </div>
              )}
              <Button
                className="w-full"
                onClick={handleAddInternalOvertime}
                disabled={!internalForm.employeeId || (!internalForm.hours && !internalForm.minutes) || !internalForm.reason}
                icon={<Plus className="w-4 h-4" />}
              >
                تسجيل الوقت الإضافي
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">آخر سجلات الوقت الداخلي</h3>
            </CardHeader>
            <div className="divide-y divide-border max-h-96 overflow-y-auto scrollbar-thin">
              {overtimeRecords.filter((r) => r.type === 'internal').length === 0 ? (
                <div className="px-6 py-8 text-center text-sm text-muted-foreground">لا توجد سجلات</div>
              ) : (
                overtimeRecords
                  .filter((r) => r.type === 'internal')
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .slice(0, 15)
                  .map((record) => (
                    <div key={record.id} className="px-6 py-3 flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900/30 flex items-center justify-center flex-shrink-0">
                        <Users className="w-4 h-4 text-blue-600 dark:text-blue-400" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium">{record.employeeName}</p>
                        <p className="text-xs text-muted-foreground truncate">{formatDate(record.date)} · {record.reason}</p>
                      </div>
                      <p className="text-sm font-semibold text-blue-600 dark:text-blue-400">
                        {formatDuration(record.overtimeMinutes)}
                      </p>
                    </div>
                  ))
              )}
            </div>
          </Card>
        </div>
      )}

      {/* ── Tab: Monthly Reports ── */}
      {activeTab === 'reports' && (
        <div className="space-y-6">
          <div className="flex items-center gap-4">
            <Input type="month" value={selectedMonth} onChange={(e) => setSelectedMonth(e.target.value)} className="w-44" />
            <p className="text-sm text-muted-foreground">
              {monthRecords.length} سجل في {format(parseISO(selectedMonth + '-01'), 'MMMM yyyy', { locale: ar })}
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <StatCard title="إجمالي الوقت الإضافي" value={`${monthStats.totalHours.toFixed(1)} س`} icon={<Clock className="w-5 h-5" />} color="orange" />
            <StatCard title="عدد السجلات" value={monthStats.recordCount} icon={<TrendingUp className="w-5 h-5" />} color="blue" />
            <StatCard
              title="أعلى موظف"
              value={monthStats.byEmployee[0] ? formatDuration(monthStats.byEmployee[0].minutes) : '—'}
              subtitle={monthStats.byEmployee[0]?.name}
              icon={<Users className="w-5 h-5" />}
              color="purple"
            />
            <StatCard
              title="متوسط لكل موظف"
              value={monthStats.byEmployee.length > 0 ? formatDuration(Math.round(monthStats.totalMinutes / monthStats.byEmployee.length)) : '—'}
              icon={<Calculator className="w-5 h-5" />}
            />
          </div>

          {dailyChart.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">الوقت الإضافي اليومي (ساعات)</h3>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={200}>
                  <BarChart data={dailyChart}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                    <XAxis dataKey="day" tick={{ fontSize: 11 }} />
                    <YAxis tick={{ fontSize: 11 }} />
                    <Tooltip
                      formatter={(v: number) => [`${v} ساعة`, 'الوقت الإضافي']}
                      contentStyle={{ background: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }}
                    />
                    <Bar dataKey="hours" name="ساعات" fill="#f59e0b" radius={[3, 3, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          )}

          {/* Per-employee breakdown */}
          {monthStats.byEmployee.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">تفصيل الوقت الإضافي بالموظف</h3>
              </CardHeader>
              <div className="divide-y divide-border">
                {monthStats.byEmployee.map((emp, i) => (
                  <div key={emp.id} className="px-6 py-3 flex items-center gap-4">
                    <span className="text-muted-foreground text-sm w-5">{i + 1}</span>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{emp.name}</p>
                      <p className="text-xs text-muted-foreground">{emp.count} سجل</p>
                    </div>
                    <div className="text-end">
                      <p className="text-sm font-semibold">{formatDuration(emp.minutes)}</p>
                      <p className="text-xs text-muted-foreground">{(emp.minutes / 60).toFixed(1)} ساعة</p>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
