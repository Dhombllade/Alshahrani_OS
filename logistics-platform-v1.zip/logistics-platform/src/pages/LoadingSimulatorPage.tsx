import { useState, useMemo } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, ProgressBar, EmptyState } from '@/components/ui'
import { guillotinePack } from '@/utils/optimization'
import { calcTruckUtilization, recommendBestTruck, formatWeight, formatVolume, calcVolumeM3, generateId } from '@/utils'
import { BoxSelect, Plus, Trash2, Zap, AlertTriangle, CheckCircle2 } from 'lucide-react'
import { motion } from 'framer-motion'
import type { LoadItem, Truck } from '@/types'

const ITEM_COLORS = [
  '#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#84cc16', '#f97316', '#ec4899', '#6366f1',
]

export function LoadingSimulatorPage() {
  const { trucks } = useAppStore()
  const [selectedTruckId, setSelectedTruckId] = useState<string>('')
  const [items, setItems] = useState<LoadItem[]>([])
  const [newItem, setNewItem] = useState({
    productName: '',
    quantity: 1,
    lengthCm: 100,
    widthCm: 80,
    heightCm: 60,
    weightKg: 50,
    isStackable: true,
    fragile: false,
  })

  const selectedTruck = trucks.find((t) => t.id === selectedTruckId)

  const simulation = useMemo(() => {
    if (!selectedTruck || items.length === 0) return null

    const totalWeightKg = items.reduce((s, i) => s + i.weightKg * i.quantity, 0)
    const totalVolumeM3 = items.reduce((s, i) => s + i.volumeM3 * i.quantity, 0)
    const util = calcTruckUtilization(selectedTruck, totalWeightKg, totalVolumeM3)

    // Expand items by quantity for packing
    const expandedItems: Array<{ id: string; w: number; h: number; item: LoadItem }> = []
    for (const item of items) {
      for (let q = 0; q < item.quantity; q++) {
        expandedItems.push({
          id: `${item.id}-${q}`,
          w: item.lengthCm,
          h: item.widthCm,
          item,
        })
      }
    }

    // Sort by area descending for better packing
    expandedItems.sort((a, b) => (b.w * b.h) - (a.w * a.h))

    const { placed, unplaced } = guillotinePack(
      selectedTruck.cargoLengthCm,
      selectedTruck.cargoWidthCm,
      expandedItems
    )

    const recommendation = recommendBestTruck(trucks, totalWeightKg, totalVolumeM3)

    return {
      totalWeightKg,
      totalVolumeM3,
      util,
      placed,
      unplacedCount: unplaced.length,
      totalItems: expandedItems.length,
      isFeasible: !util.weightExceeded && !util.volumeExceeded && unplaced.length === 0,
      recommendation,
    }
  }, [selectedTruck, items, trucks])

  const addItem = () => {
    if (!newItem.productName) return
    const volumeM3 = calcVolumeM3(newItem.lengthCm, newItem.widthCm, newItem.heightCm)
    const item: LoadItem = {
      id: generateId(),
      productId: '',
      productName: newItem.productName,
      quantity: newItem.quantity,
      lengthCm: newItem.lengthCm,
      widthCm: newItem.widthCm,
      heightCm: newItem.heightCm,
      weightKg: newItem.weightKg,
      volumeM3,
      isStackable: newItem.isStackable,
      fragile: newItem.fragile,
      color: ITEM_COLORS[items.length % ITEM_COLORS.length],
    }
    setItems([...items, item])
    setNewItem((prev) => ({ ...prev, productName: '', quantity: 1 }))
  }

  const truckOptions = trucks
    .filter((t) => t.isActive)
    .map((t) => ({ value: t.id, label: `${t.name} — ${t.plateNumber} (${t.maxWeightKg}كجم / ${t.cargoVolumeM3}م³)` }))

  // Scale for visualization (pixels per cm)
  const VIZ_SCALE = selectedTruck
    ? Math.min(500 / selectedTruck.cargoLengthCm, 300 / selectedTruck.cargoWidthCm)
    : 1

  const vizW = selectedTruck ? selectedTruck.cargoLengthCm * VIZ_SCALE : 0
  const vizH = selectedTruck ? selectedTruck.cargoWidthCm * VIZ_SCALE : 0

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="محاكاة التحميل"
        subtitle="خوارزمية تعبئة ثنائية الأبعاد — تحسين استغلال الشاحنة"
      />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* ── Controls ── */}
        <div className="space-y-4">
          {/* Truck selector */}
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">اختيار الشاحنة</h3>
            </CardHeader>
            <CardContent>
              {trucks.length === 0 ? (
                <p className="text-sm text-muted-foreground">لا توجد شاحنات. أضف شاحنات أولاً.</p>
              ) : (
                <Select
                  options={truckOptions}
                  value={selectedTruckId}
                  onChange={(e) => setSelectedTruckId(e.target.value)}
                  placeholder="اختر شاحنة..."
                />
              )}
              {selectedTruck && (
                <div className="mt-3 grid grid-cols-2 gap-2 text-xs">
                  <div className="bg-muted/40 rounded-lg p-2">
                    <p className="text-muted-foreground">الطول</p>
                    <p className="font-semibold">{selectedTruck.cargoLengthCm} سم</p>
                  </div>
                  <div className="bg-muted/40 rounded-lg p-2">
                    <p className="text-muted-foreground">العرض</p>
                    <p className="font-semibold">{selectedTruck.cargoWidthCm} سم</p>
                  </div>
                  <div className="bg-muted/40 rounded-lg p-2">
                    <p className="text-muted-foreground">الارتفاع</p>
                    <p className="font-semibold">{selectedTruck.cargoHeightCm} سم</p>
                  </div>
                  <div className="bg-muted/40 rounded-lg p-2">
                    <p className="text-muted-foreground">الحمولة</p>
                    <p className="font-semibold">{formatWeight(selectedTruck.maxWeightKg)}</p>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Add item */}
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">إضافة منتج</h3>
            </CardHeader>
            <CardContent className="space-y-3">
              <Input
                label="اسم المنتج"
                value={newItem.productName}
                onChange={(e) => setNewItem((p) => ({ ...p, productName: e.target.value }))}
                placeholder="مثال: خزانة ثلاثية"
              />
              <div className="grid grid-cols-2 gap-2">
                <Input
                  label="الكمية"
                  type="number"
                  min={1}
                  value={newItem.quantity}
                  onChange={(e) => setNewItem((p) => ({ ...p, quantity: parseInt(e.target.value) || 1 }))}
                />
                <Input
                  label="الوزن (كجم)"
                  type="number"
                  value={newItem.weightKg}
                  onChange={(e) => setNewItem((p) => ({ ...p, weightKg: parseFloat(e.target.value) || 0 }))}
                />
              </div>
              <div className="grid grid-cols-3 gap-2">
                <Input
                  label="طول (سم)"
                  type="number"
                  value={newItem.lengthCm}
                  onChange={(e) => setNewItem((p) => ({ ...p, lengthCm: parseFloat(e.target.value) || 0 }))}
                />
                <Input
                  label="عرض (سم)"
                  type="number"
                  value={newItem.widthCm}
                  onChange={(e) => setNewItem((p) => ({ ...p, widthCm: parseFloat(e.target.value) || 0 }))}
                />
                <Input
                  label="ارتفاع (سم)"
                  type="number"
                  value={newItem.heightCm}
                  onChange={(e) => setNewItem((p) => ({ ...p, heightCm: parseFloat(e.target.value) || 0 }))}
                />
              </div>
              <div className="flex gap-4 text-sm">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newItem.isStackable}
                    onChange={(e) => setNewItem((p) => ({ ...p, isStackable: e.target.checked }))}
                    className="rounded"
                  />
                  قابل للتكديس
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={newItem.fragile}
                    onChange={(e) => setNewItem((p) => ({ ...p, fragile: e.target.checked }))}
                    className="rounded"
                  />
                  هش
                </label>
              </div>
              <Button className="w-full" onClick={addItem} icon={<Plus className="w-4 h-4" />}>
                إضافة المنتج
              </Button>
            </CardContent>
          </Card>

          {/* Items list */}
          {items.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">المنتجات ({items.length})</h3>
                <Button size="sm" variant="ghost" onClick={() => setItems([])}>مسح الكل</Button>
              </CardHeader>
              <div className="divide-y divide-border">
                {items.map((item, i) => (
                  <div key={item.id} className="px-4 py-2.5 flex items-center gap-3">
                    <div className="w-3 h-3 rounded flex-shrink-0" style={{ background: item.color }} />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{item.productName}</p>
                      <p className="text-xs text-muted-foreground">
                        ×{item.quantity} · {item.lengthCm}×{item.widthCm}×{item.heightCm}سم · {formatWeight(item.weightKg * item.quantity)}
                      </p>
                    </div>
                    <button
                      onClick={() => setItems(items.filter((_, j) => j !== i))}
                      className="p-1 rounded hover:bg-destructive/10 hover:text-destructive transition-colors text-muted-foreground"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>

        {/* ── Visualization ── */}
        <div className="lg:col-span-2 space-y-4">
          {/* Results */}
          {simulation && selectedTruck && (
            <>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                <div className={`rounded-xl border p-4 ${simulation.util.weightExceeded ? 'border-red-200 bg-red-50 dark:bg-red-950/20' : 'border-border bg-card'}`}>
                  <p className="text-xs text-muted-foreground mb-1">استغلال الوزن</p>
                  <p className="text-xl font-bold">{(simulation.util.weightUtilizationPct * 100).toFixed(0)}%</p>
                  <ProgressBar value={simulation.util.weightUtilizationPct} size="sm" />
                  {simulation.util.weightExceeded && (
                    <p className="text-xs text-red-600 mt-1">تجاوز الحد!</p>
                  )}
                </div>
                <div className={`rounded-xl border p-4 ${simulation.util.volumeExceeded ? 'border-red-200 bg-red-50 dark:bg-red-950/20' : 'border-border bg-card'}`}>
                  <p className="text-xs text-muted-foreground mb-1">استغلال الحجم</p>
                  <p className="text-xl font-bold">{(simulation.util.volumeUtilizationPct * 100).toFixed(0)}%</p>
                  <ProgressBar value={simulation.util.volumeUtilizationPct} size="sm" />
                  {simulation.util.volumeExceeded && (
                    <p className="text-xs text-red-600 mt-1">تجاوز الحد!</p>
                  )}
                </div>
                <div className="rounded-xl border border-border bg-card p-4">
                  <p className="text-xs text-muted-foreground mb-1">الوزن الإجمالي</p>
                  <p className="text-xl font-bold">{formatWeight(simulation.totalWeightKg)}</p>
                  <p className="text-xs text-muted-foreground">من {formatWeight(selectedTruck.maxWeightKg)}</p>
                </div>
                <div className={`rounded-xl border p-4 ${simulation.isFeasible ? 'border-green-200 bg-green-50 dark:bg-green-950/20' : 'border-red-200 bg-red-50 dark:bg-red-950/20'}`}>
                  <p className="text-xs text-muted-foreground mb-1">النتيجة</p>
                  <div className="flex items-center gap-1.5">
                    {simulation.isFeasible
                      ? <CheckCircle2 className="w-5 h-5 text-green-600" />
                      : <AlertTriangle className="w-5 h-5 text-red-600" />}
                    <p className="text-sm font-semibold">
                      {simulation.isFeasible ? 'ممكن' : 'غير ممكن'}
                    </p>
                  </div>
                  {simulation.unplacedCount > 0 && (
                    <p className="text-xs text-red-600 mt-1">{simulation.unplacedCount} قطعة لا تتسع</p>
                  )}
                </div>
              </div>

              {/* Best truck recommendation */}
              {simulation.recommendation && simulation.recommendation.truck.id !== selectedTruckId && (
                <div className="flex items-center gap-3 px-4 py-3 bg-blue-50 dark:bg-blue-950/20 border border-blue-200 dark:border-blue-900/40 rounded-xl">
                  <Zap className="w-4 h-4 text-blue-600 flex-shrink-0" />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                      توصية: {simulation.recommendation.truck.name} ({simulation.recommendation.truck.plateNumber})
                    </p>
                    <p className="text-xs text-blue-600 dark:text-blue-400">
                      استغلال أفضل: {(simulation.recommendation.utilization.overallUtilizationPct * 100).toFixed(0)}%
                    </p>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSelectedTruckId(simulation.recommendation!.truck.id)}
                  >
                    استخدم هذه
                  </Button>
                </div>
              )}
            </>
          )}

          {/* 2D Visualization */}
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">مخطط التحميل (نظرة علوية)</h3>
              {selectedTruck && (
                <span className="text-xs text-muted-foreground">
                  {selectedTruck.cargoLengthCm} × {selectedTruck.cargoWidthCm} سم
                </span>
              )}
            </CardHeader>
            <CardContent>
              {!selectedTruck ? (
                <EmptyState
                  icon={<BoxSelect className="w-6 h-6" />}
                  title="اختر شاحنة أولاً"
                  description="اختر شاحنة من القائمة لبدء المحاكاة"
                />
              ) : items.length === 0 ? (
                <EmptyState
                  icon={<BoxSelect className="w-6 h-6" />}
                  title="أضف منتجات لبدء المحاكاة"
                  description="أضف المنتجات وأبعادها من القائمة على اليسار"
                />
              ) : (
                <div className="overflow-auto">
                  <div
                    className="relative border-2 border-primary/40 rounded-lg bg-muted/20 mx-auto"
                    style={{ width: vizW, height: vizH, minHeight: 120 }}
                  >
                    {simulation?.placed.map((placed, i) => {
                      // Find item to get color
                      const baseId = placed.id.split('-').slice(0, -1).join('-')
                      const item = items.find((it) => placed.id.startsWith(it.id))
                      const color = item?.color ?? ITEM_COLORS[i % ITEM_COLORS.length]

                      return (
                        <motion.div
                          key={placed.id}
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          transition={{ delay: i * 0.02 }}
                          className="absolute border border-white/50 rounded flex items-center justify-center overflow-hidden"
                          style={{
                            left: placed.x * VIZ_SCALE,
                            top: placed.y * VIZ_SCALE,
                            width: placed.w * VIZ_SCALE,
                            height: placed.h * VIZ_SCALE,
                            background: color + '80',
                            borderColor: color,
                          }}
                          title={`${item?.productName ?? ''} — ${placed.w}×${placed.h}سم`}
                        >
                          {placed.w * VIZ_SCALE > 30 && placed.h * VIZ_SCALE > 20 && (
                            <span className="text-[9px] font-medium text-white text-center px-0.5 leading-tight truncate">
                              {item?.productName?.slice(0, 8)}
                            </span>
                          )}
                        </motion.div>
                      )
                    })}

                    {/* Scale indicator */}
                    <div className="absolute bottom-1 end-1 text-[9px] text-muted-foreground bg-background/80 px-1 rounded">
                      مقياس: 1سم = {VIZ_SCALE.toFixed(1)}px
                    </div>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
