import { useState, useCallback } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Badge, EmptyState } from '@/components/ui'
import { parseExcelFile, autoDetectColumns, importOrders } from '@/utils/excel'
import { DYNAMICS_ORDER_COLUMN_MAP } from '@/utils'
import { Upload, FileSpreadsheet, Check, X, AlertTriangle, ChevronRight, RefreshCw } from 'lucide-react'
import { motion } from 'framer-motion'
import type { ParsedSheet, ParsedSheet as Sheet } from '@/utils/excel'
import type { ImportColumn } from '@/types'
import { formatDateTime } from '@/utils'

type Step = 'upload' | 'map' | 'preview' | 'done'

const ORDER_FIELDS = [
  { value: 'orderNumber', label: 'رقم الأمر', required: true },
  { value: 'externalRef', label: 'المرجع الخارجي', required: false },
  { value: 'customerName', label: 'اسم العميل', required: true },
  { value: 'customerCity', label: 'المدينة', required: false },
  { value: 'customerAddress', label: 'العنوان', required: false },
  { value: 'zone', label: 'المنطقة', required: false },
  { value: 'requestedDeliveryDate', label: 'تاريخ التسليم', required: true },
  { value: 'totalWeightKg', label: 'الوزن (كجم)', required: false },
  { value: 'totalVolumeM3', label: 'الحجم (م³)', required: false },
  { value: 'totalItems', label: 'عدد القطع', required: false },
  { value: 'status', label: 'الحالة', required: false },
  { value: 'priority', label: 'الأولوية', required: false },
  { value: 'notes', label: 'ملاحظات', required: false },
]

export function ImportPage() {
  const { orders, setOrders, addImportResult, importHistory } = useAppStore()
  const [step, setStep] = useState<Step>('upload')
  const [sheets, setSheets] = useState<Sheet[]>([])
  const [selectedSheet, setSelectedSheet] = useState(0)
  const [columns, setColumns] = useState<ImportColumn[]>([])
  const [importMode, setImportMode] = useState<'merge' | 'replace'>('merge')
  const [isDragging, setIsDragging] = useState(false)
  const [fileName, setFileName] = useState('')
  const [isProcessing, setIsProcessing] = useState(false)
  const [lastResult, setLastResult] = useState<ReturnType<typeof importOrders>['result'] | null>(null)
  const [previewData, setPreviewData] = useState<ReturnType<typeof importOrders>['orders']>([])

  const handleFile = useCallback(async (file: File) => {
    if (!file) return
    setFileName(file.name)
    setIsProcessing(true)

    try {
      const parsed = await parseExcelFile(file)
      setSheets(parsed)

      const firstSheet = parsed[0]
      if (firstSheet) {
        const cols = autoDetectColumns(firstSheet.headers, DYNAMICS_ORDER_COLUMN_MAP)
        setColumns(cols)
      }

      setStep('map')
    } catch (err) {
      alert(`خطأ في قراءة الملف: ${(err as Error).message}`)
    } finally {
      setIsProcessing(false)
    }
  }, [])

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
    const file = e.dataTransfer.files[0]
    if (file) handleFile(file)
  }, [handleFile])

  const handlePreview = () => {
    const sheet = sheets[selectedSheet]
    if (!sheet) return

    const { orders: previewOrders } = importOrders({
      sheet,
      columnMapping: columns,
      mode: importMode,
      existingOrders: orders,
    })
    setPreviewData(previewOrders)
    setStep('preview')
  }

  const handleImport = async () => {
    const sheet = sheets[selectedSheet]
    if (!sheet) return

    setIsProcessing(true)
    await new Promise((r) => setTimeout(r, 400))

    const { orders: newOrders, result } = importOrders({
      sheet,
      columnMapping: columns,
      mode: importMode,
      existingOrders: orders,
    })

    const finalResult = { ...result, fileName }

    if (importMode === 'replace') {
      setOrders(newOrders)
    } else {
      setOrders([...orders, ...newOrders])
    }

    addImportResult(finalResult)
    setLastResult(finalResult)
    setStep('done')
    setIsProcessing(false)
  }

  const reset = () => {
    setStep('upload')
    setSheets([])
    setColumns([])
    setFileName('')
    setLastResult(null)
    setPreviewData([])
  }

  const sheet = sheets[selectedSheet]

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="مركز الاستيراد"
        subtitle="استيراد ملفات Excel من Dynamics أو أي مصدر آخر"
      />

      {/* Steps indicator */}
      <div className="flex items-center gap-2">
        {(['upload', 'map', 'preview', 'done'] as Step[]).map((s, i) => {
          const LABELS = { upload: 'رفع الملف', map: 'ربط الأعمدة', preview: 'معاينة', done: 'اكتمال' }
          const stepIdx = ['upload', 'map', 'preview', 'done'].indexOf(step)
          const sIdx = i
          return (
            <div key={s} className="flex items-center gap-2">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold transition-colors ${
                stepIdx > sIdx ? 'bg-green-500 text-white' :
                stepIdx === sIdx ? 'bg-primary text-primary-foreground' :
                'bg-muted text-muted-foreground'
              }`}>
                {stepIdx > sIdx ? <Check className="w-3.5 h-3.5" /> : i + 1}
              </div>
              <span className={`text-sm ${stepIdx === sIdx ? 'font-medium text-foreground' : 'text-muted-foreground'}`}>
                {LABELS[s]}
              </span>
              {i < 3 && <ChevronRight className="w-4 h-4 text-muted-foreground" />}
            </div>
          )
        })}
      </div>

      {/* ── Step 1: Upload ── */}
      {step === 'upload' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}>
          <Card>
            <CardContent className="py-8">
              <div
                onDragOver={(e) => { e.preventDefault(); setIsDragging(true) }}
                onDragLeave={() => setIsDragging(false)}
                onDrop={handleDrop}
                className={`border-2 border-dashed rounded-xl p-12 text-center transition-colors ${
                  isDragging
                    ? 'border-primary bg-primary/5'
                    : 'border-border hover:border-primary/50 hover:bg-muted/20'
                }`}
              >
                <FileSpreadsheet className="w-12 h-12 mx-auto mb-4 text-muted-foreground" />
                <h3 className="text-base font-semibold mb-2">اسحب ملف Excel هنا</h3>
                <p className="text-sm text-muted-foreground mb-6">
                  أو اضغط لاختيار الملف · دعم Excel (.xlsx, .xls) و CSV
                </p>
                <label className="inline-flex items-center gap-2 h-10 px-6 text-sm rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 cursor-pointer transition-colors">
                  <Upload className="w-4 h-4" />
                  اختيار ملف
                  <input
                    type="file"
                    accept=".xlsx,.xls,.csv"
                    className="hidden"
                    onChange={(e) => {
                      const f = e.target.files?.[0]
                      if (f) handleFile(f)
                    }}
                  />
                </label>
              </div>
            </CardContent>
          </Card>

          {/* Import history */}
          {importHistory.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">سجل الاستيراد</h3>
              </CardHeader>
              <div className="divide-y divide-border">
                {importHistory.slice(0, 10).map((record) => (
                  <div key={record.id} className="px-6 py-3 flex items-center gap-3">
                    <FileSpreadsheet className="w-4 h-4 text-muted-foreground flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">{record.fileName}</p>
                      <p className="text-xs text-muted-foreground">
                        {formatDateTime(record.importedAt)} · {record.importedRows} صف مُستورد
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      {record.errors.length > 0 && (
                        <Badge variant="warning" size="sm">{record.errors.length} خطأ</Badge>
                      )}
                      <Badge variant="success" size="sm">{record.importedRows} سجل</Badge>
                    </div>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </motion.div>
      )}

      {/* ── Step 2: Column Mapping ── */}
      {step === 'map' && sheet && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <Card>
            <CardHeader>
              <div>
                <h3 className="text-sm font-semibold">{fileName}</h3>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {sheet.rows.length} صف · {sheet.headers.length} عمود
                </p>
              </div>

              {sheets.length > 1 && (
                <div className="flex gap-2">
                  {sheets.map((s, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        setSelectedSheet(i)
                        const cols = autoDetectColumns(s.headers, DYNAMICS_ORDER_COLUMN_MAP)
                        setColumns(cols)
                      }}
                      className={`px-3 py-1 text-xs rounded-lg border transition-colors ${
                        selectedSheet === i ? 'border-primary bg-primary/10 text-primary' : 'border-border hover:bg-muted'
                      }`}
                    >
                      {s.sheetName}
                    </button>
                  ))}
                </div>
              )}
            </CardHeader>

            <CardContent>
              <div className="mb-4 flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    value="merge"
                    checked={importMode === 'merge'}
                    onChange={() => setImportMode('merge')}
                  />
                  <span className="text-sm">دمج مع البيانات الحالية</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="radio"
                    value="replace"
                    checked={importMode === 'replace'}
                    onChange={() => setImportMode('replace')}
                  />
                  <span className="text-sm text-destructive">استبدال البيانات الحالية</span>
                </label>
              </div>

              <table className="w-full text-sm border-collapse">
                <thead>
                  <tr className="bg-muted/30">
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground border border-border">عمود الملف</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground border border-border">حقل النظام</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground border border-border">مثال</th>
                  </tr>
                </thead>
                <tbody>
                  {columns.map((col, i) => (
                    <tr key={i} className="border-b border-border/50 hover:bg-muted/10">
                      <td className="px-4 py-2 border-e border-border font-mono text-xs text-foreground">
                        {col.sourceColumn}
                      </td>
                      <td className="px-4 py-2 border-e border-border">
                        <select
                          value={col.targetField}
                          onChange={(e) => {
                            const updated = [...columns]
                            updated[i] = { ...col, targetField: e.target.value }
                            setColumns(updated)
                          }}
                          className="w-full bg-background border border-input rounded px-2 py-1 text-xs focus:outline-none focus:ring-1 focus:ring-ring"
                        >
                          <option value="">— تجاهل —</option>
                          {ORDER_FIELDS.map((f) => (
                            <option key={f.value} value={f.value}>
                              {f.label}{f.required ? ' *' : ''}
                            </option>
                          ))}
                        </select>
                      </td>
                      <td className="px-4 py-2 text-xs text-muted-foreground font-mono">
                        {String(sheet.rows[0]?.[col.sourceColumn] ?? '—').slice(0, 30)}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </CardContent>
          </Card>

          <div className="flex justify-between">
            <Button variant="outline" onClick={reset}>رجوع</Button>
            <Button onClick={handlePreview} icon={<ChevronRight className="w-4 h-4" />}>معاينة البيانات</Button>
          </div>
        </motion.div>
      )}

      {/* ── Step 3: Preview ── */}
      {step === 'preview' && (
        <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <Card>
            <CardHeader>
              <div>
                <h3 className="text-sm font-semibold">معاينة البيانات</h3>
                <p className="text-xs text-muted-foreground">{previewData.length} سجل جاهز للاستيراد</p>
              </div>
            </CardHeader>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-muted/30 border-b border-border">
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">رقم الأمر</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">العميل</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">المدينة</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">تاريخ التسليم</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">الوزن</th>
                    <th className="text-start px-4 py-2 font-medium text-muted-foreground">الحالة</th>
                  </tr>
                </thead>
                <tbody>
                  {previewData.slice(0, 20).map((order) => (
                    <tr key={order.id} className="border-b border-border/50 hover:bg-muted/20">
                      <td className="px-4 py-2 font-medium">{order.orderNumber}</td>
                      <td className="px-4 py-2">{order.customerName}</td>
                      <td className="px-4 py-2 text-muted-foreground">{order.customerCity}</td>
                      <td className="px-4 py-2">{order.requestedDeliveryDate}</td>
                      <td className="px-4 py-2">{order.totalWeightKg} كجم</td>
                      <td className="px-4 py-2">
                        <Badge variant="neutral" size="sm">{order.status}</Badge>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
              {previewData.length > 20 && (
                <p className="px-4 py-2 text-xs text-muted-foreground text-center border-t border-border">
                  + {previewData.length - 20} سجل إضافي
                </p>
              )}
            </div>
          </Card>

          <div className="flex justify-between">
            <Button variant="outline" onClick={() => setStep('map')}>تعديل الربط</Button>
            <Button loading={isProcessing} onClick={handleImport} icon={<Upload className="w-4 h-4" />}>
              استيراد {previewData.length} سجل
            </Button>
          </div>
        </motion.div>
      )}

      {/* ── Step 4: Done ── */}
      {step === 'done' && lastResult && (
        <motion.div initial={{ opacity: 0, scale: 0.98 }} animate={{ opacity: 1, scale: 1 }}>
          <Card>
            <CardContent className="py-12">
              <div className="text-center">
                <div className="w-16 h-16 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-green-600 dark:text-green-400" />
                </div>
                <h3 className="text-xl font-semibold mb-2">تم الاستيراد بنجاح</h3>
                <div className="flex items-center justify-center gap-6 mt-4 mb-6">
                  <div className="text-center">
                    <p className="text-2xl font-bold text-green-600">{lastResult.importedRows}</p>
                    <p className="text-xs text-muted-foreground">مُستورد</p>
                  </div>
                  <div className="text-center">
                    <p className="text-2xl font-bold text-muted-foreground">{lastResult.skippedRows}</p>
                    <p className="text-xs text-muted-foreground">مُتخطى</p>
                  </div>
                  {lastResult.errors.length > 0 && (
                    <div className="text-center">
                      <p className="text-2xl font-bold text-red-600">{lastResult.errors.length}</p>
                      <p className="text-xs text-muted-foreground">أخطاء</p>
                    </div>
                  )}
                </div>

                {lastResult.errors.length > 0 && (
                  <div className="text-start max-w-md mx-auto mb-6 bg-red-50 dark:bg-red-950/20 rounded-xl p-4">
                    <p className="text-sm font-medium text-red-700 dark:text-red-400 mb-2">
                      أخطاء الاستيراد:
                    </p>
                    {lastResult.errors.slice(0, 5).map((e, i) => (
                      <p key={i} className="text-xs text-red-600 dark:text-red-400">
                        الصف {e.row}: {e.message} ({e.field})
                      </p>
                    ))}
                  </div>
                )}

                <Button icon={<RefreshCw className="w-4 h-4" />} onClick={reset}>
                  استيراد ملف آخر
                </Button>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}
    </div>
  )
}
