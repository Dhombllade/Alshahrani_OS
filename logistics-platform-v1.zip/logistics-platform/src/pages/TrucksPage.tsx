import { useState } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, EmptyState, StatCard, ProgressBar } from '@/components/ui'
import { calcVolumeM3, formatWeight, formatVolume, generateId } from '@/utils'
import { Truck, Plus, Edit2, Trash2, CheckCircle2, XCircle, Wrench } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import type { Truck as TruckType, FuelType } from '@/types'

const FUEL_OPTIONS = [
  { value: 'diesel', label: 'ديزل' },
  { value: 'petrol', label: 'بنزين' },
  { value: 'electric', label: 'كهربائي' },
  { value: 'hybrid', label: 'هجين' },
  { value: 'gas', label: 'غاز' },
]

const FUEL_LABELS: Record<FuelType, string> = {
  diesel: 'ديزل', petrol: 'بنزين', electric: 'كهربائي', hybrid: 'هجين', gas: 'غاز'
}

const defaultTruck = {
  plateNumber: '', name: '', type: '',
  cargoLengthCm: 600, cargoWidthCm: 230, cargoHeightCm: 240,
  maxWeightKg: 5000, fuelType: 'diesel' as FuelType,
  currentOdometerKm: 0, notes: '',
}

export function TrucksPage() {
  const { trucks, addTruck, updateTruck, deleteTruck } = useAppStore()
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(defaultTruck)

  const stats = {
    total: trucks.length,
    active: trucks.filter((t) => t.isActive).length,
    available: trucks.filter((t) => t.isActive && t.isAvailable).length,
    maintenance: trucks.filter((t) => t.nextMaintenanceDate && t.nextMaintenanceDate <= new Date().toISOString().slice(0, 10)).length,
  }

  const handleSubmit = () => {
    if (!form.plateNumber || !form.name) return
    const cargoVolumeM3 = calcVolumeM3(form.cargoLengthCm, form.cargoWidthCm, form.cargoHeightCm)
    const now = new Date().toISOString()

    if (editingId) {
      updateTruck(editingId, { ...form, cargoVolumeM3, updatedAt: now })
      setEditingId(null)
    } else {
      const truck: TruckType = {
        id: generateId(),
        ...form,
        cargoVolumeM3,
        driverId: null,
        isActive: true,
        isAvailable: true,
        lastMaintenanceDate: null,
        nextMaintenanceDate: null,
        nextMaintenanceKm: null,
        createdAt: now,
        updatedAt: now,
      }
      addTruck(truck)
    }
    setShowForm(false)
    setForm(defaultTruck)
  }

  const startEdit = (truck: TruckType) => {
    setForm({
      plateNumber: truck.plateNumber,
      name: truck.name,
      type: truck.type,
      cargoLengthCm: truck.cargoLengthCm,
      cargoWidthCm: truck.cargoWidthCm,
      cargoHeightCm: truck.cargoHeightCm,
      maxWeightKg: truck.maxWeightKg,
      fuelType: truck.fuelType,
      currentOdometerKm: truck.currentOdometerKm,
      notes: truck.notes,
    })
    setEditingId(truck.id)
    setShowForm(true)
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="إدارة الأسطول"
        subtitle={`${trucks.length} شاحنة · ${stats.available} متاحة`}
        actions={
          <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => { setShowForm(true); setEditingId(null); setForm(defaultTruck) }}>
            إضافة شاحنة
          </Button>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="إجمالي الشاحنات" value={stats.total} icon={<Truck className="w-5 h-5" />} color="blue" />
        <StatCard title="نشطة" value={stats.active} icon={<CheckCircle2 className="w-5 h-5" />} color="green" />
        <StatCard title="متاحة الآن" value={stats.available} icon={<Truck className="w-5 h-5" />} color="purple" />
        <StatCard title="صيانة مستحقة" value={stats.maintenance} icon={<Wrench className="w-5 h-5" />} color={stats.maintenance > 0 ? 'orange' : 'green'} />
      </div>

      {/* Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">{editingId ? 'تعديل الشاحنة' : 'إضافة شاحنة جديدة'}</h3>
                <Button size="sm" variant="ghost" onClick={() => { setShowForm(false); setEditingId(null) }}>إلغاء</Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Input label="رقم اللوحة *" value={form.plateNumber} onChange={(e) => setForm((p) => ({ ...p, plateNumber: e.target.value }))} placeholder="أ ب ج 1234" />
                  <Input label="الاسم / النوع *" value={form.name} onChange={(e) => setForm((p) => ({ ...p, name: e.target.value }))} placeholder="مثال: مديوم كبير" />
                  <Input label="الفئة" value={form.type} onChange={(e) => setForm((p) => ({ ...p, type: e.target.value }))} placeholder="كبير / متوسط / صغير" />
                  <Select label="نوع الوقود" options={FUEL_OPTIONS} value={form.fuelType} onChange={(e) => setForm((p) => ({ ...p, fuelType: e.target.value as FuelType }))} />
                </div>
                <div>
                  <p className="text-sm font-medium text-foreground mb-2">أبعاد منطقة الشحن (سم)</p>
                  <div className="grid grid-cols-3 md:grid-cols-6 gap-3">
                    <Input label="الطول" type="number" value={form.cargoLengthCm} onChange={(e) => setForm((p) => ({ ...p, cargoLengthCm: +e.target.value }))} />
                    <Input label="العرض" type="number" value={form.cargoWidthCm} onChange={(e) => setForm((p) => ({ ...p, cargoWidthCm: +e.target.value }))} />
                    <Input label="الارتفاع" type="number" value={form.cargoHeightCm} onChange={(e) => setForm((p) => ({ ...p, cargoHeightCm: +e.target.value }))} />
                    <Input label="الحمولة (كجم)" type="number" value={form.maxWeightKg} onChange={(e) => setForm((p) => ({ ...p, maxWeightKg: +e.target.value }))} />
                    <Input label="عداد الكيلومتر" type="number" value={form.currentOdometerKm} onChange={(e) => setForm((p) => ({ ...p, currentOdometerKm: +e.target.value }))} />
                    <div className="flex flex-col justify-end">
                      <div className="h-9 px-3 bg-muted/40 rounded-lg flex items-center text-sm text-muted-foreground">
                        {calcVolumeM3(form.cargoLengthCm, form.cargoWidthCm, form.cargoHeightCm).toFixed(2)} م³
                      </div>
                      <p className="text-xs text-muted-foreground mt-1">الحجم المحسوب</p>
                    </div>
                  </div>
                </div>
                <Input label="ملاحظات" value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => { setShowForm(false); setEditingId(null) }}>إلغاء</Button>
                  <Button onClick={handleSubmit}>{editingId ? 'حفظ التعديلات' : 'إضافة الشاحنة'}</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Grid */}
      {trucks.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Truck className="w-6 h-6" />}
            title="لا توجد شاحنات"
            description="أضف شاحنات الأسطول لبدء العمليات"
            action={<Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowForm(true)}>إضافة شاحنة</Button>}
          />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {trucks.map((truck, i) => {
            const volumeM3 = truck.cargoVolumeM3
            return (
              <motion.div key={truck.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.05 }}>
                <Card hover>
                  <CardContent className="pt-5">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold">{truck.name}</h3>
                          <span className={`text-xs px-1.5 py-0.5 rounded font-medium ${truck.isActive ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' : 'bg-muted text-muted-foreground'}`}>
                            {truck.isActive ? 'نشط' : 'متوقف'}
                          </span>
                          {truck.isAvailable && truck.isActive && (
                            <span className="text-xs px-1.5 py-0.5 rounded bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400 font-medium">متاح</span>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground font-mono">{truck.plateNumber}</p>
                        {truck.type && <p className="text-xs text-muted-foreground mt-0.5">{truck.type} · {FUEL_LABELS[truck.fuelType]}</p>}
                      </div>
                      <div className="flex gap-1">
                        <button onClick={() => startEdit(truck)} className="p-1.5 rounded hover:bg-accent transition-colors text-muted-foreground hover:text-foreground">
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button onClick={() => deleteTruck(truck.id)} className="p-1.5 rounded hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Specs grid */}
                    <div className="grid grid-cols-3 gap-2 mb-4">
                      <div className="bg-muted/30 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">الطول</p>
                        <p className="text-sm font-semibold">{truck.cargoLengthCm}<span className="text-xs text-muted-foreground">سم</span></p>
                      </div>
                      <div className="bg-muted/30 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">العرض</p>
                        <p className="text-sm font-semibold">{truck.cargoWidthCm}<span className="text-xs text-muted-foreground">سم</span></p>
                      </div>
                      <div className="bg-muted/30 rounded-lg p-2 text-center">
                        <p className="text-xs text-muted-foreground">الارتفاع</p>
                        <p className="text-sm font-semibold">{truck.cargoHeightCm}<span className="text-xs text-muted-foreground">سم</span></p>
                      </div>
                    </div>

                    <div className="space-y-2 text-sm border-t border-border pt-3">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">الحمولة القصوى</span>
                        <span className="font-medium">{formatWeight(truck.maxWeightKg)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">حجم الشحن</span>
                        <span className="font-medium">{formatVolume(volumeM3)}</span>
                      </div>
                      {truck.currentOdometerKm > 0 && (
                        <div className="flex justify-between">
                          <span className="text-muted-foreground">عداد الكيلومتر</span>
                          <span className="font-medium">{truck.currentOdometerKm.toLocaleString('ar-SA')} كم</span>
                        </div>
                      )}
                    </div>

                    {/* Availability toggle */}
                    <div className="flex items-center justify-between mt-4 pt-3 border-t border-border">
                      <button
                        onClick={() => updateTruck(truck.id, { isActive: !truck.isActive })}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${truck.isActive ? 'border-red-200 text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20' : 'border-green-200 text-green-600 hover:bg-green-50 dark:hover:bg-green-950/20'}`}
                      >
                        {truck.isActive ? 'تعطيل' : 'تفعيل'}
                      </button>
                      <button
                        onClick={() => updateTruck(truck.id, { isAvailable: !truck.isAvailable })}
                        className={`text-xs px-3 py-1.5 rounded-lg border transition-colors ${truck.isAvailable ? 'border-border text-muted-foreground hover:bg-muted' : 'border-blue-200 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-950/20'}`}
                      >
                        {truck.isAvailable ? 'تعيين غير متاح' : 'تعيين متاح'}
                      </button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
