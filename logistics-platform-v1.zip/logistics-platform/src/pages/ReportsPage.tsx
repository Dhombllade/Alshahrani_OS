import { useState } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input } from '@/components/ui'
import { exportToExcel } from '@/utils/excel'
import { ORDER_STATUS_LABELS, TRIP_STATUS_LABELS, formatDate, formatWeight, formatVolume, formatDuration, formatSAR } from '@/utils'
import { FileSpreadsheet, Printer, Download, BarChart3, Truck, Route, Clock, Users, Wrench } from 'lucide-react'

type ReportType = 'orders' | 'trips' | 'overtime' | 'maintenance' | 'kpi'

interface ReportConfig {
  id: ReportType
  label: string
  description: string
  icon: typeof BarChart3
}

const REPORTS: ReportConfig[] = [
  { id: 'orders', label: 'تقرير الطلبات', description: 'كل الطلبات مع الحالة والتواريخ والأوزان', icon: BarChart3 },
  { id: 'trips', label: 'تقرير الرحلات', description: 'الرحلات مع السائقين والشاحنات والمسافات', icon: Route },
  { id: 'overtime', label: 'تقرير الوقت الإضافي', description: 'سجل الوقت الإضافي بالتفصيل الشهري', icon: Clock },
  { id: 'maintenance', label: 'تقرير الصيانة', description: 'سجل صيانة الأسطول والتكاليف', icon: Wrench },
  { id: 'kpi', label: 'ملخص الأداء', description: 'مؤشرات الأداء الرئيسية للسائقين والأسطول', icon: Users },
]

export function ReportsPage() {
  const { orders, trips, overtimeRecords, maintenanceRecords, employees, trucks } = useAppStore()
  const [dateFrom, setDateFrom] = useState(new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10))
  const [dateTo, setDateTo] = useState(new Date().toISOString().slice(0, 10))
  const [generating, setGenerating] = useState<ReportType | null>(null)

  const generate = async (type: ReportType) => {
    setGenerating(type)
    await new Promise((r) => setTimeout(r, 300))

    const filename = `${type}-${dateFrom}--${dateTo}`

    if (type === 'orders') {
      const data = orders
        .filter((o) => o.requestedDeliveryDate.slice(0, 10) >= dateFrom && o.requestedDeliveryDate.slice(0, 10) <= dateTo)
        .map((o) => ({
          'رقم الأمر': o.orderNumber,
          'المرجع الخارجي': o.externalRef,
          'العميل': o.customerName,
          'المدينة': o.customerCity,
          'المنطقة': o.zone,
          'تاريخ التسليم المطلوب': o.requestedDeliveryDate,
          'تاريخ التسليم الفعلي': o.actualDeliveryDate ?? '',
          'الحالة': ORDER_STATUS_LABELS[o.status],
          'الأولوية': o.priority,
          'الوزن (كجم)': o.totalWeightKg,
          'الحجم (م³)': o.totalVolumeM3,
          'عدد القطع': o.totalItems,
          'ملاحظات': o.notes,
        }))
      exportToExcel(data, filename, 'الطلبات')
    }

    else if (type === 'trips') {
      const data = trips
        .filter((t) => t.date >= dateFrom && t.date <= dateTo)
        .map((t) => ({
          'رقم الرحلة': t.tripNumber,
          'التاريخ': t.date,
          'السائق': t.driverName,
          'الشاحنة': t.truckPlate,
          'الحالة': TRIP_STATUS_LABELS[t.status],
          'عدد الطلبات': t.orderIds.length,
          'الوزن (كجم)': t.totalWeightKg,
          'الحجم (م³)': t.totalVolumeM3,
          'استغلال الوزن %': (t.weightUtilizationPct * 100).toFixed(1),
          'استغلال الحجم %': (t.volumeUtilizationPct * 100).toFixed(1),
          'المسافة الكلية (كم)': t.totalDistanceKm,
          'المدة المقدرة': t.estimatedDurationMinutes > 0 ? formatDuration(t.estimatedDurationMinutes) : '',
          'الوقت الإضافي (دقيقة)': t.overtimeMinutes,
          'ملاحظات': t.notes,
        }))
      exportToExcel(data, filename, 'الرحلات')
    }

    else if (type === 'overtime') {
      const data = overtimeRecords
        .filter((r) => r.date >= dateFrom && r.date <= dateTo)
        .map((r) => ({
          'التاريخ': r.date,
          'الموظف': r.employeeName,
          'النوع': r.type === 'trip' ? 'رحلة' : 'داخلي',
          'رقم الرحلة': r.tripNumber ?? '',
          'مسافة ذهاب (كم)': r.distanceOutboundKm,
          'مسافة عودة (كم)': r.distanceReturnKm,
          'الوقت الإضافي (دقيقة)': r.overtimeMinutes,
          'الوقت الإضافي (ساعة)': (r.overtimeMinutes / 60).toFixed(2),
          'السبب': r.reason,
        }))
      exportToExcel(data, filename, 'الوقت الإضافي')
    }

    else if (type === 'maintenance') {
      const data = maintenanceRecords
        .filter((r) => r.date >= dateFrom && r.date <= dateTo)
        .map((r) => ({
          'التاريخ': r.date,
          'الشاحنة': r.truckPlate,
          'نوع الصيانة': r.type,
          'الوصف': r.description,
          'الورشة': r.repairShop,
          'التكلفة (ريال)': r.costSAR,
          'العداد (كم)': r.odometerKm,
          'ساعات التوقف': r.downtimeHours,
          'عطل مفاجئ': r.isBreakdown ? 'نعم' : 'لا',
          'تاريخ الصيانة القادمة': r.nextServiceDate ?? '',
        }))
      exportToExcel(data, filename, 'الصيانة')
    }

    else if (type === 'kpi') {
      const periodTrips = trips.filter((t) => t.date >= dateFrom && t.date <= dateTo)
      const data = employees
        .filter((e) => e.role === 'driver')
        .map((driver) => {
          const driverTrips = periodTrips.filter((t) => t.driverId === driver.id)
          const overtime = overtimeRecords
            .filter((r) => r.employeeId === driver.id && r.date >= dateFrom && r.date <= dateTo)
            .reduce((s, r) => s + r.overtimeMinutes, 0)
          const avgUtil = driverTrips.length > 0
            ? driverTrips.reduce((s, t) => s + Math.max(t.weightUtilizationPct, t.volumeUtilizationPct), 0) / driverTrips.length
            : 0
          return {
            'السائق': driver.nameAr,
            'رقم الموظف': driver.employeeNumber,
            'عدد الرحلات': driverTrips.length,
            'عدد الطلبات': driverTrips.reduce((s, t) => s + t.orderIds.length, 0),
            'إجمالي المسافة (كم)': driverTrips.reduce((s, t) => s + t.totalDistanceKm, 0).toFixed(1),
            'متوسط الاستغلال %': (avgUtil * 100).toFixed(1),
            'الوقت الإضافي (ساعة)': (overtime / 60).toFixed(2),
          }
        })
      exportToExcel(data, filename, 'أداء السائقين')
    }

    setGenerating(null)
  }

  const handlePrint = () => window.print()

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="مركز التقارير"
        subtitle="تصدير البيانات إلى Excel أو طباعتها"
        actions={
          <Button variant="outline" size="sm" icon={<Printer className="w-3.5 h-3.5" />} onClick={handlePrint}>
            طباعة
          </Button>
        }
      />

      {/* Date range */}
      <Card>
        <CardHeader>
          <h3 className="text-sm font-semibold">نطاق التاريخ</h3>
        </CardHeader>
        <CardContent>
          <div className="flex flex-wrap gap-4 items-end">
            <Input label="من" type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="w-44" />
            <Input label="إلى" type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="w-44" />
            <div className="flex gap-2 pb-0.5">
              {[
                { label: 'اليوم', days: 0 },
                { label: 'الأسبوع الماضي', days: 7 },
                { label: 'الشهر الماضي', days: 30 },
                { label: 'الربع الماضي', days: 90 },
              ].map(({ label, days }) => (
                <button
                  key={days}
                  onClick={() => {
                    const to = new Date().toISOString().slice(0, 10)
                    const from = new Date(Date.now() - days * 86400000).toISOString().slice(0, 10)
                    setDateFrom(from)
                    setDateTo(to)
                  }}
                  className="px-3 py-1.5 text-xs border border-border rounded-lg hover:bg-muted transition-colors"
                >
                  {label}
                </button>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Reports grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {REPORTS.map((report) => {
          const Icon = report.icon
          const isLoading = generating === report.id
          return (
            <Card key={report.id} hover>
              <CardContent className="pt-5">
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold">{report.label}</h3>
                    <p className="text-xs text-muted-foreground mt-0.5">{report.description}</p>
                  </div>
                </div>
                <Button
                  className="w-full"
                  variant="outline"
                  loading={isLoading}
                  onClick={() => generate(report.id)}
                  icon={<FileSpreadsheet className="w-4 h-4" />}
                >
                  تصدير Excel
                </Button>
              </CardContent>
            </Card>
          )
        })}

        {/* Print card */}
        <Card hover>
          <CardContent className="pt-5">
            <div className="flex items-start gap-4 mb-4">
              <div className="w-10 h-10 rounded-xl bg-muted flex items-center justify-center flex-shrink-0">
                <Printer className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <h3 className="font-semibold">طباعة</h3>
                <p className="text-xs text-muted-foreground mt-0.5">طباعة الصفحة الحالية مباشرة</p>
              </div>
            </div>
            <Button className="w-full" variant="outline" onClick={handlePrint} icon={<Printer className="w-4 h-4" />}>
              طباعة الصفحة
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Quick stats for the period */}
      <Card>
        <CardHeader>
          <h3 className="text-sm font-semibold">ملخص الفترة المختارة</h3>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {[
              { label: 'طلبات', value: orders.filter((o) => o.requestedDeliveryDate.slice(0, 10) >= dateFrom && o.requestedDeliveryDate.slice(0, 10) <= dateTo).length },
              { label: 'رحلات', value: trips.filter((t) => t.date >= dateFrom && t.date <= dateTo).length },
              { label: 'سجلات وقت إضافي', value: overtimeRecords.filter((r) => r.date >= dateFrom && r.date <= dateTo).length },
              { label: 'عمليات صيانة', value: maintenanceRecords.filter((r) => r.date >= dateFrom && r.date <= dateTo).length },
            ].map(({ label, value }) => (
              <div key={label}>
                <p className="text-3xl font-bold text-foreground">{value}</p>
                <p className="text-sm text-muted-foreground mt-1">{label}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
