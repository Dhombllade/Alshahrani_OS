import { useState, useMemo } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, StatCard, Badge, ProgressBar, EmptyState } from '@/components/ui'
import { generateWeeklyPlan } from '@/utils/optimization'
import { formatDate, formatDuration, formatWeight, formatVolume, formatPercent } from '@/utils'
import { Calendar, Zap, AlertTriangle, CheckCircle2, Truck, Package, Clock, TrendingUp, ChevronDown, ChevronUp } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import { startOfWeek, format, addDays, parseISO } from 'date-fns'
import { ar } from 'date-fns/locale'
import type { WeeklyPlan, WeeklyPlanDay } from '@/types'

const DAY_NAMES = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

export function WeeklyPlannerPage() {
  const { orders, trucks, settings, weeklyPlans, setWeeklyPlan } = useAppStore()

  const [selectedWeek, setSelectedWeek] = useState(() => {
    const monday = startOfWeek(new Date(), { weekStartsOn: 0 })
    return format(monday, 'yyyy-MM-dd')
  })
  const [expandedDay, setExpandedDay] = useState<string | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  const currentPlan = useMemo(
    () => weeklyPlans.find((p) => p.weekStartDate === selectedWeek),
    [weeklyPlans, selectedWeek]
  )

  const weekDates = useMemo(() => {
    return Array.from({ length: 7 }, (_, i) =>
      format(addDays(parseISO(selectedWeek), i), 'yyyy-MM-dd')
    )
  }, [selectedWeek])

  const weekLabel = useMemo(() => {
    const start = parseISO(selectedWeek)
    const end = addDays(start, 6)
    return `${format(start, 'd MMMM', { locale: ar })} — ${format(end, 'd MMMM yyyy', { locale: ar })}`
  }, [selectedWeek])

  const handleGenerate = async () => {
    setIsGenerating(true)
    await new Promise((r) => setTimeout(r, 600)) // simulate async

    const weekOrders = orders.filter((o) => {
      const date = o.requestedDeliveryDate.slice(0, 10)
      return weekDates.includes(date) && !['delivered', 'cancelled'].includes(o.status)
    })

    const plan = generateWeeklyPlan(weekOrders, trucks, settings, selectedWeek)
    setWeeklyPlan(plan)
    setIsGenerating(false)
  }

  const navigateWeek = (dir: -1 | 1) => {
    const current = parseISO(selectedWeek)
    const next = addDays(current, dir * 7)
    setSelectedWeek(format(next, 'yyyy-MM-dd'))
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="التخطيط الأسبوعي"
        subtitle="محرك التخطيط الذكي — توزيع تلقائي للطلبات والرحلات"
        actions={
          <div className="flex gap-2">
            <div className="flex items-center border border-border rounded-lg overflow-hidden">
              <Button variant="ghost" size="sm" onClick={() => navigateWeek(-1)}>←</Button>
              <span className="px-3 text-sm font-medium text-foreground border-x border-border">{weekLabel}</span>
              <Button variant="ghost" size="sm" onClick={() => navigateWeek(1)}>→</Button>
            </div>
            <Button
              size="sm"
              icon={<Zap className="w-3.5 h-3.5" />}
              loading={isGenerating}
              onClick={handleGenerate}
              disabled={orders.length === 0 || trucks.length === 0}
            >
              توليد الخطة
            </Button>
          </div>
        }
      />

      {!currentPlan ? (
        <Card>
          <CardContent>
            <EmptyState
              icon={<Calendar className="w-6 h-6" />}
              title="لا توجد خطة لهذا الأسبوع"
              description={
                orders.length === 0
                  ? 'استورد الطلبات أولاً ثم اضغط "توليد الخطة"'
                  : trucks.length === 0
                  ? 'أضف الشاحنات أولاً ثم اضغط "توليد الخطة"'
                  : 'اضغط "توليد الخطة" لبدء التخطيط الذكي الأسبوعي'
              }
              action={
                <Button
                  icon={<Zap className="w-4 h-4" />}
                  loading={isGenerating}
                  onClick={handleGenerate}
                  disabled={orders.length === 0 || trucks.length === 0}
                >
                  توليد الخطة الآن
                </Button>
              }
            />
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Plan Summary */}
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            <StatCard title="إجمالي الطلبات" value={currentPlan.totalOrders} icon={<Package className="w-5 h-5" />} color="blue" />
            <StatCard title="إجمالي الرحلات" value={currentPlan.totalTrips} icon={<Truck className="w-5 h-5" />} color="purple" />
            <StatCard
              title="متوسط الاستغلال"
              value={formatPercent(currentPlan.avgUtilizationPct)}
              icon={<TrendingUp className="w-5 h-5" />}
              color={currentPlan.avgUtilizationPct < 0.6 ? 'orange' : 'green'}
            />
            <StatCard
              title="وقت إضافي متوقع"
              value={currentPlan.predictedOvertimeHours > 0 ? `${currentPlan.predictedOvertimeHours.toFixed(1)} س` : 'لا يوجد'}
              icon={<Clock className="w-5 h-5" />}
              color={currentPlan.predictedOvertimeHours > 2 ? 'red' : 'green'}
            />
            <StatCard
              title="توصيات"
              value={currentPlan.recommendations.length}
              icon={<AlertTriangle className="w-5 h-5" />}
              color={currentPlan.recommendations.length > 0 ? 'orange' : 'green'}
            />
            <div className="rounded-xl border border-border p-4 bg-card flex items-center justify-between">
              <div>
                <p className="text-xs text-muted-foreground mb-1">حالة الخطة</p>
                <span className={`text-xs px-2 py-1 rounded-full font-medium ${
                  currentPlan.status === 'approved' ? 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400' :
                  currentPlan.status === 'active' ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400' :
                  'bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400'
                }`}>
                  {currentPlan.status === 'draft' ? 'مسودة' : currentPlan.status === 'approved' ? 'معتمدة' : 'نشطة'}
                </span>
              </div>
              <Button size="sm" variant="outline">اعتماد</Button>
            </div>
          </div>

          {/* Recommendations */}
          {currentPlan.recommendations.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-500" />
                  توصيات التحسين ({currentPlan.recommendations.length})
                </h3>
              </CardHeader>
              <div className="divide-y divide-border">
                {currentPlan.recommendations.map((rec) => (
                  <div key={rec.id} className="px-6 py-3 flex items-start gap-3">
                    <div className={`mt-0.5 w-2 h-2 rounded-full flex-shrink-0 ${
                      rec.priority === 'high' || rec.priority === 'urgent' ? 'bg-red-500' :
                      rec.priority === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                    }`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{rec.titleAr}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{rec.descriptionAr}</p>
                      {(rec.estimatedSavingMinutes > 0 || rec.estimatedSavingKm > 0) && (
                        <div className="flex gap-3 mt-1">
                          {rec.estimatedSavingMinutes > 0 && (
                            <span className="text-xs text-green-600 dark:text-green-400">
                              وفر {formatDuration(rec.estimatedSavingMinutes)}
                            </span>
                          )}
                          {rec.estimatedSavingKm > 0 && (
                            <span className="text-xs text-green-600 dark:text-green-400">
                              وفر {rec.estimatedSavingKm} كم
                            </span>
                          )}
                        </div>
                      )}
                    </div>
                    <Button size="sm" variant="outline" disabled={rec.applied}>
                      {rec.applied ? 'تم التطبيق' : 'تطبيق'}
                    </Button>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Daily breakdown */}
          <div className="space-y-3">
            {currentPlan.days.map((day) => (
              <DayCard
                key={day.date}
                day={day}
                expanded={expandedDay === day.date}
                onToggle={() => setExpandedDay(expandedDay === day.date ? null : day.date)}
                settings={settings}
              />
            ))}
          </div>
        </>
      )}
    </div>
  )
}

function DayCard({ day, expanded, onToggle, settings }: {
  day: WeeklyPlanDay
  expanded: boolean
  onToggle: () => void
  settings: ReturnType<typeof useAppStore>['settings']
}) {
  const isWorkingDay = settings.workingDays.includes(day.dayOfWeek)
  const hasOrders = day.totalOrders > 0

  return (
    <Card className={day.isOverloaded ? 'border-red-200 dark:border-red-900/50' : ''}>
      {/* Day header - always visible */}
      <button
        onClick={onToggle}
        className="w-full px-6 py-4 flex items-center gap-4 hover:bg-muted/20 transition-colors text-start"
      >
        {/* Day label */}
        <div className="w-20 flex-shrink-0">
          <p className="text-sm font-semibold text-foreground">
            {DAY_NAMES[day.dayOfWeek]}
          </p>
          <p className="text-xs text-muted-foreground">{formatDate(day.date)}</p>
        </div>

        {/* Status indicators */}
        <div className="flex items-center gap-6 flex-1">
          <div className="flex items-center gap-1.5">
            <Package className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-sm font-medium">{day.totalOrders}</span>
            <span className="text-xs text-muted-foreground">طلب</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Truck className="w-3.5 h-3.5 text-muted-foreground" />
            <span className="text-sm font-medium">{day.totalTrips}</span>
            <span className="text-xs text-muted-foreground">رحلة</span>
          </div>
          {day.estimatedOvertimeMinutes > 0 && (
            <div className="flex items-center gap-1.5 text-orange-600 dark:text-orange-400">
              <Clock className="w-3.5 h-3.5" />
              <span className="text-sm font-medium">{formatDuration(day.estimatedOvertimeMinutes)}</span>
              <span className="text-xs">وقت إضافي</span>
            </div>
          )}
          {hasOrders && (
            <div className="flex-1 max-w-32">
              <ProgressBar value={day.utilizationPct} size="sm" showPercent />
            </div>
          )}
        </div>

        {/* Warnings */}
        <div className="flex items-center gap-2">
          {day.warnings.filter((w) => w.startsWith('تحذير')).length > 0 && (
            <AlertTriangle className="w-4 h-4 text-amber-500" />
          )}
          {!isWorkingDay && (
            <Badge variant="neutral" size="sm">إجازة</Badge>
          )}
          {day.isOverloaded && (
            <Badge variant="danger" size="sm">مرهق</Badge>
          )}
          {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </button>

      {/* Expanded content */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.2 }}
            className="overflow-hidden border-t border-border"
          >
            {/* Warnings */}
            {day.warnings.length > 0 && (
              <div className="px-6 py-3 bg-amber-50 dark:bg-amber-950/20 border-b border-amber-100 dark:border-amber-900/30">
                {day.warnings.map((w, i) => (
                  <p key={i} className="text-xs text-amber-700 dark:text-amber-400 flex items-center gap-1.5">
                    <AlertTriangle className="w-3 h-3" /> {w}
                  </p>
                ))}
              </div>
            )}

            {/* Orders list */}
            {day.orders.length > 0 ? (
              <div className="px-6 py-4">
                <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  الطلبات ({day.orders.length})
                </p>
                <div className="space-y-2">
                  {day.orders.map((order) => (
                    <div key={order.id} className="flex items-center gap-3 py-2 border-b border-border/50 last:border-0">
                      <div className="flex-1">
                        <span className="text-sm font-medium">{order.orderNumber}</span>
                        <span className="text-muted-foreground mx-2">·</span>
                        <span className="text-sm text-muted-foreground">{order.customerName}</span>
                        <span className="text-muted-foreground mx-2">·</span>
                        <span className="text-xs text-muted-foreground">{order.customerCity}</span>
                      </div>
                      <div className="text-xs text-muted-foreground">
                        {formatWeight(order.totalWeightKg)} · {formatVolume(order.totalVolumeM3)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="px-6 py-8 text-center text-sm text-muted-foreground">
                {isWorkingDay ? 'لا توجد طلبات لهذا اليوم' : 'يوم إجازة'}
              </div>
            )}

            {/* Suggested trips */}
            {day.trips.length > 0 && (
              <div className="px-6 py-4 border-t border-border bg-muted/10">
                <p className="text-xs font-semibold text-muted-foreground mb-3 uppercase tracking-wide">
                  الرحلات المقترحة ({day.trips.length})
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {day.trips.map((trip, i) => (
                    <div key={trip.id} className="border border-border rounded-lg p-3 bg-background">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium">رحلة {i + 1}</span>
                        {trip.truckPlate && (
                          <span className="text-xs bg-muted px-2 py-0.5 rounded font-mono">{trip.truckPlate}</span>
                        )}
                      </div>
                      <div className="space-y-1.5">
                        <ProgressBar
                          value={Math.max(trip.weightUtilizationPct, trip.volumeUtilizationPct)}
                          label="الاستغلال"
                          showPercent
                          size="sm"
                        />
                        <div className="flex gap-4 text-xs text-muted-foreground">
                          <span>{trip.orderIds.length} طلب</span>
                          <span>{formatWeight(trip.totalWeightKg)}</span>
                          {trip.overtimeMinutes > 0 && (
                            <span className="text-orange-600 dark:text-orange-400">
                              +{formatDuration(trip.overtimeMinutes)} إضافي
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </Card>
  )
}
