import { useMemo, useState } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, StatCard, ProgressBar } from '@/components/ui'
import { formatPercent, formatDuration, formatDistance } from '@/utils'
import { TrendingUp, Truck, Users, Package, Clock, CheckCircle2 } from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell, Legend
} from 'recharts'

const CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']

export function KpiPage() {
  const { orders, trips, trucks, employees, overtimeRecords, maintenanceRecords } = useAppStore()
  const [period, setPeriod] = useState<'week' | 'month' | 'quarter'>('month')

  const today = new Date()
  const periodStart = useMemo(() => {
    const d = new Date()
    if (period === 'week') d.setDate(d.getDate() - 7)
    else if (period === 'month') d.setDate(d.getDate() - 30)
    else d.setDate(d.getDate() - 90)
    return d.toISOString().slice(0, 10)
  }, [period])

  const periodTrips = trips.filter((t) => t.date >= periodStart)
  const periodOrders = orders.filter((o) => o.requestedDeliveryDate.slice(0, 10) >= periodStart)

  // Delivery performance
  const delivered = periodOrders.filter((o) => o.status === 'delivered').length
  const delayed = periodOrders.filter((o) => o.status === 'delayed').length
  const cancelled = periodOrders.filter((o) => o.status === 'cancelled').length
  const onTimePct = periodOrders.length > 0 ? delivered / periodOrders.length : 0

  // Truck utilization (average over period)
  const avgUtilization = periodTrips.length > 0
    ? periodTrips.reduce((s, t) => s + Math.max(t.weightUtilizationPct, t.volumeUtilizationPct), 0) / periodTrips.length
    : 0

  // Overtime
  const periodOvertime = overtimeRecords
    .filter((r) => r.date >= periodStart)
    .reduce((s, r) => s + r.overtimeMinutes, 0)

  // Driver KPIs
  const driverKpis = useMemo(() => {
    const drivers = employees.filter((e) => e.role === 'driver')
    return drivers.map((driver) => {
      const driverTrips = periodTrips.filter((t) => t.driverId === driver.id)
      const driverOvertime = overtimeRecords
        .filter((r) => r.employeeId === driver.id && r.date >= periodStart)
        .reduce((s, r) => s + r.overtimeMinutes, 0)
      const totalOrders = driverTrips.reduce((s, t) => s + t.orderIds.length, 0)
      const avgUtil = driverTrips.length > 0
        ? driverTrips.reduce((s, t) => s + Math.max(t.weightUtilizationPct, t.volumeUtilizationPct), 0) / driverTrips.length
        : 0
      return {
        id: driver.id,
        name: driver.nameAr,
        trips: driverTrips.length,
        orders: totalOrders,
        distance: driverTrips.reduce((s, t) => s + t.totalDistanceKm, 0),
        overtime: driverOvertime,
        utilization: avgUtil,
      }
    }).sort((a, b) => b.trips - a.trips)
  }, [employees, periodTrips, overtimeRecords, periodStart])

  // Truck KPIs
  const truckKpis = useMemo(() => {
    return trucks.filter((t) => t.isActive).map((truck) => {
      const truckTrips = periodTrips.filter((t) => t.truckId === truck.id)
      const avgUtil = truckTrips.length > 0
        ? truckTrips.reduce((s, t) => s + Math.max(t.weightUtilizationPct, t.volumeUtilizationPct), 0) / truckTrips.length
        : 0
      const maintenanceCost = maintenanceRecords
        .filter((r) => r.truckId === truck.id && r.date >= periodStart)
        .reduce((s, r) => s + r.costSAR, 0)
      return {
        id: truck.id,
        plate: truck.plateNumber,
        name: truck.name,
        trips: truckTrips.length,
        utilization: avgUtil,
        maintenanceCost,
        distance: truckTrips.reduce((s, t) => s + t.totalDistanceKm, 0),
      }
    }).sort((a, b) => b.trips - a.trips)
  }, [trucks, periodTrips, maintenanceRecords, periodStart])

  // Order status pie
  const orderStatusData = [
    { name: 'مُسلَّمة', value: delivered },
    { name: 'متأخرة', value: delayed },
    { name: 'ملغية', value: cancelled },
    { name: 'أخرى', value: periodOrders.length - delivered - delayed - cancelled },
  ].filter((d) => d.value > 0)

  // Weekly trips chart (last 8 weeks)
  const weeklyData = useMemo(() => {
    return Array.from({ length: 8 }, (_, i) => {
      const weekStart = new Date()
      weekStart.setDate(weekStart.getDate() - (7 - i) * 7)
      const weekEnd = new Date(weekStart)
      weekEnd.setDate(weekEnd.getDate() + 6)
      const ws = weekStart.toISOString().slice(0, 10)
      const we = weekEnd.toISOString().slice(0, 10)
      const weekTrips = trips.filter((t) => t.date >= ws && t.date <= we)
      return {
        week: `أ${i + 1}`,
        رحلات: weekTrips.length,
        طلبات: weekTrips.reduce((s, t) => s + t.orderIds.length, 0),
      }
    })
  }, [trips])

  const PERIOD_LABEL = { week: 'الأسبوع الماضي', month: 'الشهر الماضي', quarter: 'الربع الماضي' }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="مركز مؤشرات الأداء"
        subtitle="تحليل شامل لأداء العمليات اللوجستية"
        actions={
          <div className="flex gap-1 p-1 bg-muted rounded-lg">
            {(['week', 'month', 'quarter'] as const).map((p) => (
              <button
                key={p}
                onClick={() => setPeriod(p)}
                className={`px-3 py-1.5 text-xs rounded-md transition-colors ${period === p ? 'bg-background text-foreground font-medium shadow-sm' : 'text-muted-foreground hover:text-foreground'}`}
              >
                {p === 'week' ? 'أسبوع' : p === 'month' ? 'شهر' : 'ربع سنة'}
              </button>
            ))}
          </div>
        }
      />

      {/* Top KPIs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard title="إجمالي الطلبات" value={periodOrders.length} subtitle={PERIOD_LABEL[period]} icon={<Package className="w-5 h-5" />} color="blue" />
        <StatCard title="مُسلَّمة" value={delivered} icon={<CheckCircle2 className="w-5 h-5" />} color="green" />
        <StatCard title="التسليم في الوقت" value={formatPercent(onTimePct)} icon={<TrendingUp className="w-5 h-5" />} color={onTimePct > 0.85 ? 'green' : onTimePct > 0.7 ? 'orange' : 'red'} />
        <StatCard title="إجمالي الرحلات" value={periodTrips.length} icon={<Truck className="w-5 h-5" />} color="purple" />
        <StatCard title="متوسط استغلال الأسطول" value={formatPercent(avgUtilization)} icon={<Truck className="w-5 h-5" />} color={avgUtilization > 0.7 ? 'green' : avgUtilization > 0.5 ? 'orange' : 'red'} />
        <StatCard title="الوقت الإضافي" value={periodOvertime > 0 ? formatDuration(periodOvertime) : 'لا يوجد'} icon={<Clock className="w-5 h-5" />} color={periodOvertime > 300 ? 'red' : 'green'} />
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-2">
          <CardHeader>
            <h3 className="text-sm font-semibold">الرحلات والطلبات الأسبوعية</h3>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={weeklyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis dataKey="week" tick={{ fontSize: 11 }} />
                <YAxis tick={{ fontSize: 11 }} />
                <Tooltip contentStyle={{ background: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                <Legend />
                <Bar dataKey="رحلات" fill="#8b5cf6" radius={[3, 3, 0, 0]} />
                <Bar dataKey="طلبات" fill="#3b82f6" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold">حالة الطلبات</h3>
          </CardHeader>
          <CardContent>
            {orderStatusData.length > 0 ? (
              <ResponsiveContainer width="100%" height={200}>
                <PieChart>
                  <Pie data={orderStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" paddingAngle={2}>
                    {orderStatusData.map((_, i) => <Cell key={i} fill={CHART_COLORS[i]} />)}
                  </Pie>
                  <Tooltip contentStyle={{ background: 'hsl(var(--popover))', border: '1px solid hsl(var(--border))', borderRadius: 8, fontSize: 12 }} />
                  <Legend />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">لا توجد بيانات</div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Driver KPIs */}
      {driverKpis.length > 0 && (
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold">أداء السائقين</h3>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/30 border-b border-border">
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">#</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">السائق</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الرحلات</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الطلبات</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">المسافة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الاستغلال</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الوقت الإضافي</th>
                </tr>
              </thead>
              <tbody>
                {driverKpis.map((driver, i) => (
                  <tr key={driver.id} className="border-b border-border/50 hover:bg-muted/20">
                    <td className="px-4 py-3 text-muted-foreground">{i + 1}</td>
                    <td className="px-4 py-3 font-medium">{driver.name}</td>
                    <td className="px-4 py-3">{driver.trips}</td>
                    <td className="px-4 py-3">{driver.orders}</td>
                    <td className="px-4 py-3">{driver.distance > 0 ? formatDistance(driver.distance) : '—'}</td>
                    <td className="px-4 py-3 w-40">
                      <ProgressBar value={driver.utilization} showPercent size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      {driver.overtime > 0 ? (
                        <span className="text-orange-600 dark:text-orange-400">{formatDuration(driver.overtime)}</span>
                      ) : <span className="text-green-600">لا يوجد</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}

      {/* Truck KPIs */}
      {truckKpis.length > 0 && (
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold">أداء الشاحنات</h3>
          </CardHeader>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/30 border-b border-border">
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الشاحنة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الرحلات</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">المسافة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الاستغلال</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">تكلفة الصيانة</th>
                </tr>
              </thead>
              <tbody>
                {truckKpis.map((truck) => (
                  <tr key={truck.id} className="border-b border-border/50 hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <p className="font-medium">{truck.name}</p>
                      <p className="text-xs text-muted-foreground font-mono">{truck.plate}</p>
                    </td>
                    <td className="px-4 py-3">{truck.trips}</td>
                    <td className="px-4 py-3">{truck.distance > 0 ? formatDistance(truck.distance) : '—'}</td>
                    <td className="px-4 py-3 w-40">
                      <ProgressBar value={truck.utilization} showPercent size="sm" />
                    </td>
                    <td className="px-4 py-3">
                      {truck.maintenanceCost > 0
                        ? <span className="text-orange-600">{truck.maintenanceCost.toLocaleString('ar-SA')} ر.س</span>
                        : <span className="text-muted-foreground">—</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
