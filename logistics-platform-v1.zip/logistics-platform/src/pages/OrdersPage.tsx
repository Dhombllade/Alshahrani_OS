import { useState, useMemo, useCallback } from 'react'
import { useAppStore } from '@/store'
import {
  Card, CardHeader, CardContent, Badge, PageHeader,
  Button, Input, Select, EmptyState
} from '@/components/ui'
import {
  ORDER_STATUS_LABELS, ORDER_STATUS_COLORS,
  formatDate, formatWeight, formatVolume, generateId
} from '@/utils'
import { Package, Search, Filter, Download, Plus, Eye, Edit2, Trash2, MoreHorizontal } from 'lucide-react'
import { motion } from 'framer-motion'
import type { Order, OrderStatus, Priority } from '@/types'
import { exportToExcel } from '@/utils/excel'

const PRIORITY_LABELS: Record<Priority, string> = {
  low: 'منخفض', medium: 'متوسط', high: 'عالي', urgent: 'عاجل'
}

const PRIORITY_COLORS: Record<Priority, string> = {
  low: 'bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400',
  medium: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  high: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  urgent: 'bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400',
}

const STATUS_OPTIONS = [
  { value: '', label: 'كل الحالات' },
  ...Object.entries(ORDER_STATUS_LABELS).map(([v, l]) => ({ value: v, label: l }))
]

const PRIORITY_OPTIONS = [
  { value: '', label: 'كل الأولويات' },
  ...Object.entries(PRIORITY_LABELS).map(([v, l]) => ({ value: v, label: l }))
]

export function OrdersPage() {
  const { orders, deleteOrder, bulkUpdateOrders } = useAppStore()
  const [search, setSearch] = useState('')
  const [statusFilter, setStatusFilter] = useState<string>('')
  const [priorityFilter, setPriorityFilter] = useState<string>('')
  const [dateFilter, setDateFilter] = useState('')
  const [selected, setSelected] = useState<Set<string>>(new Set())
  const [sortBy, setSortBy] = useState<keyof Order>('requestedDeliveryDate')
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc')
  const [page, setPage] = useState(0)
  const PAGE_SIZE = 20

  const filtered = useMemo(() => {
    let result = [...orders]

    if (search) {
      const q = search.toLowerCase()
      result = result.filter(
        (o) =>
          o.orderNumber.toLowerCase().includes(q) ||
          o.customerName.toLowerCase().includes(q) ||
          o.customerCity.toLowerCase().includes(q) ||
          o.externalRef.toLowerCase().includes(q)
      )
    }

    if (statusFilter) result = result.filter((o) => o.status === statusFilter)
    if (priorityFilter) result = result.filter((o) => o.priority === priorityFilter)
    if (dateFilter) result = result.filter((o) => o.requestedDeliveryDate.startsWith(dateFilter))

    result.sort((a, b) => {
      const av = String(a[sortBy] ?? '')
      const bv = String(b[sortBy] ?? '')
      return sortDir === 'asc' ? av.localeCompare(bv) : bv.localeCompare(av)
    })

    return result
  }, [orders, search, statusFilter, priorityFilter, dateFilter, sortBy, sortDir])

  const pageItems = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE)
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE)

  const toggleSelect = useCallback((id: string) => {
    setSelected((prev) => {
      const next = new Set(prev)
      next.has(id) ? next.delete(id) : next.add(id)
      return next
    })
  }, [])

  const toggleAll = useCallback(() => {
    if (selected.size === pageItems.length) {
      setSelected(new Set())
    } else {
      setSelected(new Set(pageItems.map((o) => o.id)))
    }
  }, [selected, pageItems])

  const handleExport = () => {
    const data = filtered.map((o) => ({
      'رقم الأمر': o.orderNumber,
      'المرجع الخارجي': o.externalRef,
      'العميل': o.customerName,
      'المدينة': o.customerCity,
      'الحالة': ORDER_STATUS_LABELS[o.status],
      'الأولوية': PRIORITY_LABELS[o.priority],
      'تاريخ التسليم': o.requestedDeliveryDate,
      'الوزن (كجم)': o.totalWeightKg,
      'الحجم (م³)': o.totalVolumeM3,
      'ملاحظات': o.notes,
    }))
    exportToExcel(data, `orders-${new Date().toISOString().slice(0, 10)}`, 'الطلبات')
  }

  const handleSort = (field: keyof Order) => {
    if (sortBy === field) {
      setSortDir((d) => (d === 'asc' ? 'desc' : 'asc'))
    } else {
      setSortBy(field)
      setSortDir('asc')
    }
  }

  const SortIcon = ({ field }: { field: keyof Order }) => (
    <span className="text-muted-foreground text-xs">
      {sortBy === field ? (sortDir === 'asc' ? ' ↑' : ' ↓') : ''}
    </span>
  )

  return (
    <div className="p-6 space-y-4">
      <PageHeader
        title="إدارة الطلبات"
        subtitle={`${orders.length} طلب إجمالي · ${filtered.length} في النتائج`}
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" icon={<Download className="w-3.5 h-3.5" />} onClick={handleExport}>
              تصدير
            </Button>
            <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />}>
              طلب جديد
            </Button>
          </div>
        }
      />

      {/* Filters */}
      <Card>
        <CardContent className="py-3">
          <div className="flex flex-wrap gap-3">
            <div className="flex-1 min-w-48">
              <Input
                placeholder="بحث برقم الأمر، العميل، المدينة..."
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(0) }}
                icon={<Search className="w-3.5 h-3.5" />}
              />
            </div>
            <Select
              options={STATUS_OPTIONS}
              value={statusFilter}
              onChange={(e) => { setStatusFilter(e.target.value); setPage(0) }}
              placeholder="الحالة"
              className="w-36"
            />
            <Select
              options={PRIORITY_OPTIONS}
              value={priorityFilter}
              onChange={(e) => { setPriorityFilter(e.target.value); setPage(0) }}
              placeholder="الأولوية"
              className="w-36"
            />
            <Input
              type="date"
              value={dateFilter}
              onChange={(e) => { setDateFilter(e.target.value); setPage(0) }}
              className="w-40"
            />
            {(search || statusFilter || priorityFilter || dateFilter) && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => { setSearch(''); setStatusFilter(''); setPriorityFilter(''); setDateFilter(''); setPage(0) }}
              >
                مسح الفلاتر
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Bulk actions */}
      {selected.size > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -8 }}
          animate={{ opacity: 1, y: 0 }}
          className="flex items-center gap-3 px-4 py-2 bg-primary/5 border border-primary/20 rounded-xl"
        >
          <span className="text-sm font-medium text-primary">{selected.size} محدد</span>
          <div className="flex gap-2 ms-auto">
            <Button size="sm" variant="outline" onClick={() => bulkUpdateOrders([...selected], { status: 'confirmed' })}>
              تأكيد المحدد
            </Button>
            <Button size="sm" variant="outline" onClick={() => bulkUpdateOrders([...selected], { status: 'cancelled' })}>
              إلغاء المحدد
            </Button>
            <Button size="sm" variant="ghost" onClick={() => setSelected(new Set())}>
              إلغاء التحديد
            </Button>
          </div>
        </motion.div>
      )}

      {/* Table */}
      <Card>
        {filtered.length === 0 ? (
          <EmptyState
            icon={<Package className="w-6 h-6" />}
            title="لا توجد طلبات"
            description="لم يتم العثور على طلبات تطابق معايير البحث"
          />
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border bg-muted/30">
                  <th className="w-10 px-4 py-3">
                    <input
                      type="checkbox"
                      checked={selected.size === pageItems.length && pageItems.length > 0}
                      onChange={toggleAll}
                      className="rounded"
                    />
                  </th>
                  <th
                    className="text-start px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground"
                    onClick={() => handleSort('orderNumber')}
                  >
                    رقم الأمر <SortIcon field="orderNumber" />
                  </th>
                  <th
                    className="text-start px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground"
                    onClick={() => handleSort('customerName')}
                  >
                    العميل <SortIcon field="customerName" />
                  </th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">المدينة</th>
                  <th
                    className="text-start px-4 py-3 font-medium text-muted-foreground cursor-pointer hover:text-foreground"
                    onClick={() => handleSort('requestedDeliveryDate')}
                  >
                    تاريخ التسليم <SortIcon field="requestedDeliveryDate" />
                  </th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الوزن / الحجم</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الأولوية</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الحالة</th>
                  <th className="w-16 px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {pageItems.map((order, i) => (
                  <motion.tr
                    key={order.id}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    transition={{ delay: i * 0.02 }}
                    className={`border-b border-border/50 hover:bg-muted/20 transition-colors ${selected.has(order.id) ? 'bg-primary/5' : ''}`}
                  >
                    <td className="px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selected.has(order.id)}
                        onChange={() => toggleSelect(order.id)}
                        className="rounded"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="font-medium text-foreground">{order.orderNumber}</p>
                        {order.externalRef && (
                          <p className="text-xs text-muted-foreground">{order.externalRef}</p>
                        )}
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <p className="font-medium">{order.customerName}</p>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{order.customerCity}</td>
                    <td className="px-4 py-3">
                      <p className="font-medium">{formatDate(order.requestedDeliveryDate)}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-xs">{formatWeight(order.totalWeightKg)}</p>
                      <p className="text-xs text-muted-foreground">{formatVolume(order.totalVolumeM3)}</p>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${PRIORITY_COLORS[order.priority]}`}>
                        {PRIORITY_LABELS[order.priority]}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${ORDER_STATUS_COLORS[order.status]}`}>
                        {ORDER_STATUS_LABELS[order.status]}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <button
                        onClick={() => deleteOrder(order.id)}
                        className="p-1.5 rounded hover:bg-destructive/10 hover:text-destructive transition-colors text-muted-foreground"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>

            {/* Pagination */}
            {totalPages > 1 && (
              <div className="flex items-center justify-between px-4 py-3 border-t border-border">
                <p className="text-xs text-muted-foreground">
                  عرض {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} من {filtered.length}
                </p>
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>
                    السابق
                  </Button>
                  {Array.from({ length: Math.min(totalPages, 5) }, (_, i) => (
                    <Button
                      key={i}
                      size="sm"
                      variant={page === i ? 'primary' : 'ghost'}
                      onClick={() => setPage(i)}
                    >
                      {i + 1}
                    </Button>
                  ))}
                  <Button size="sm" variant="ghost" disabled={page >= totalPages - 1} onClick={() => setPage((p) => p + 1)}>
                    التالي
                  </Button>
                </div>
              </div>
            )}
          </div>
        )}
      </Card>
    </div>
  )
}
