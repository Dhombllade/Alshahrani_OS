import { useMemo } from 'react'
import { useAppStore } from '@/store'
import { StatCard, Card, CardHeader, CardContent, Badge, ProgressBar, PageHeader } from '@/components/ui'
import { formatDate, formatDuration, ORDER_STATUS_LABELS, TRIP_STATUS_LABELS, ORDER_STATUS_COLORS, TRIP_STATUS_COLORS, formatWeight, formatVolume } from '@/utils'
import {
  Package, Truck, Route, Clock, AlertTriangle,
  CheckCircle2, Users, Wrench, TrendingUp, Plus, Upload
} from 'lucide-react'
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, LineChart, Line
} from 'recharts'
import { motion } from 'framer-motion'
import { Link } from 'react-router-dom'
import { isOverdue, isDueToday } from '@/utils'

const CHART_COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4']

export function DashboardPage() {
  const { orders, trips, trucks, employees, maintenanceRecords, overtimeRecords, settings } = useAppStore()

  const today = new Date().toISOString().slice(0, 10)

  const stats = useMemo(() => {
    const todayOrders = orders.filter((o) => isDueToday(o.requestedDeliveryDate))
    const pendingOrders = orders.filter((o) => ['pending', 'confirmed'].includes(o.status))
    const deliveredOrders = orders.filter((o) => o.status === 'delivered')
    const cancelledOrders = orders.filter((o) => o.status === 'cancelled')
    const delayedOrders = orders.filter((o) => o.status === 'delayed' || (isOverdue(o.requestedDeliveryDate) && !['delivered', 'cancelled'].includes(o.status)))

    const todayTrips = trips.filter((t) => t.date === today)
    const activeTrips = trips.filter((t) => t.status === 'in_transit')
    const activeTrucks = trucks.filter((t) => t.isActive)
    const availableTrucks = trucks.filter((t) => t.isActive && t.isAvailable)

    const activeDrivers = employees.filter((e) => e.role === 'driver' && e.isActive)

    const todayOvertime = overtimeRecords
      .filter((r) => r.date === today)
      .reduce((s, r) => s + r.overtimeMinutes, 0)

    const maintenanceDue = maintenanceRecords
      .filter((r) => r.nextServiceDate && r.nextServiceDate <= today)

    const avgUtilization = todayTrips.length > 0
      ? todayTrips.reduce((s, t) => s + Math.max(t.weightUtilizationPct, t.volumeUtilizationPct), 0) / todayTrips.length
      : 0

    return {
      totalOrders: orders.length,
      todayOrders: todayOrders.length,
      pendingOrders: pendingOrders.length,
      deliveredOrders: deliveredOrders.length,
      cancelledOrders: cancelledOrders.length,
      delayedOrders: delayedOrders.length,
      todayTrips: todayTrips.length,
      activeTrips: activeTrips.length,
      activeTrucks: activeTrucks.length,
      availableTrucks: availableTrucks.length,
      activeDrivers: activeDrivers.length,
      todayOvertime,
      maintenanceDue: maintenanceDue.length,
      avgUtilization,
    }
  }, [orders, trips, trucks, employees, maintenanceRecords, overtimeRecords, today])

  // Chart: orders by status
  const ordersByStatus = useMemo(() => {
    const counts: Record<string, number> = {}
    for (const o of orders) {
      counts[o.status] = (counts[o.status] || 0) + 1
    }
    return Object.entries(counts).map(([status, count]) => ({
      name: ORDER_STATUS_LABELS[status] || status,
      value: count,
    }))
  }, [orders])

  // Chart: trips last 7 days
  const tripsLast7Days = useMemo(() => {
    const days: { date: string; label: string; trips: number; orders: number }[] = []
    for (let i = 6; i >= 0; i--) {
      const d = new Date()
      d.setDate(d.getDate() - i)
      const dateStr = d.toISOString().slice(0, 10)
      days.push({
        date: dateStr,
        label: d.toLocaleDateString('ar-SA', { weekday: 'short' }),
        trips: trips.filter((t) => t.date === dateStr).length,
        orders: orders.filter((o) => o.requestedDeliveryDate.slice(0, 10) === dateStr).length,
      })
    }
    return days
  }, [trips, orders])

  // Recent trips
  const recentTrips = useMemo(() =>
    [...trips].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, 5),
    [trips]
  )

  // Upcoming orders (today + next 3 days)
  const upcomingOrders = useMemo(() => {
    const cutoff = new Date()
    cutoff.setDate(cutoff.getDate() + 3)
    const cutoffStr = cutoff.toISOString().slice(0, 10)
    return orders
      .filter((o) =>
        o.requestedDeliveryDate.slice(0, 10) >= today &&
        o.requestedDeliveryDate.slice(0, 10) <= cutoffStr &&
        !['delivered', 'cancelled'].includes(o.status)
      )
      .sort((a, b) => a.requestedDeliveryDate.localeCompare(b.requestedDeliveryDate))
      .slice(0, 8)
  }, [orders, today])

  const hasData = orders.length > 0 || trips.length > 0

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="لوحة التحكم"
        subtitle={new Date().toLocaleDateString('ar-SA', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
        actions={
          <div className="flex gap-2">
            <Link to="/import">
              <button className="inline-flex items-center gap-2 h-9 px-4 text-sm rounded-lg border border-border bg-background hover:bg-accent transition-colors">
                <Upload className="w-4 h-4" />
                استيراد
              </button>
            </Link>
            <Link to="/trips">
              <button className="inline-flex items-center gap-2 h-9 px-4 text-sm rounded-lg bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                <Plus className="w-4 h-4" />
                رحلة جديدة
              </button>
            </Link>
          </div>
        }
      />

      {/* ── KPI Grid ── */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-6 gap-4">
        <StatCard
          title="إجمالي الطلبات"
          value={stats.totalOrders}
          icon={<Package className="w-5 h-5" />}
          color="blue"
          delay={0}
        />
        <StatCard
          title="طلبات اليوم"
          value={stats.todayOrders}
          subtitle="مستحقة اليوم"
          icon={<Package className="w-5 h-5" />}
          color="blue"
          delay={0.05}
        />
        <StatCard
          title="رحلات اليوم"
          value={stats.todayTrips}
          subtitle={`${stats.activeTrips} نشطة`}
          icon={<Route className="w-5 h-5" />}
          color="purple"
          delay={0.1}
        />
        <StatCard
          title="استغلال الأسطول"
          value={`${(stats.avgUtilization * 100).toFixed(0)}%`}
          subtitle={`${stats.availableTrucks}/${stats.activeTrucks} متاحة`}
          icon={<Truck className="w-5 h-5" />}
          color={stats.avgUtilization < 0.6 ? 'orange' : 'green'}
          delay={0.15}
        />
        <StatCard
          title="وقت إضافي اليوم"
          value={stats.todayOvertime > 0 ? formatDuration(stats.todayOvertime) : 'لا يوجد'}
          icon={<Clock className="w-5 h-5" />}
          color={stats.todayOvertime > 120 ? 'red' : 'green'}
          delay={0.2}
        />
        <StatCard
          title="متأخرة / عاجلة"
          value={stats.delayedOrders}
          subtitle={`${stats.pendingOrders} قيد الانتظار`}
          icon={<AlertTriangle className="w-5 h-5" />}
          color={stats.delayedOrders > 0 ? 'red' : 'green'}
          delay={0.25}
        />
      </div>

      {/* Second row */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          title="مُسلَّمة"
          value={stats.deliveredOrders}
          icon={<CheckCircle2 className="w-5 h-5" />}
          color="green"
          delay={0.3}
        />
        <StatCard
          title="ملغية"
          value={stats.cancelledOrders}
          icon={<Package className="w-5 h-5" />}
          delay={0.35}
        />
        <StatCard
          title="السائقون النشطون"
          value={stats.activeDrivers}
          icon={<Users className="w-5 h-5" />}
          color="purple"
          delay={0.4}
        />
        <StatCard
          title="صيانة مستحقة"
          value={stats.maintenanceDue}
          icon={<Wrench className="w-5 h-5" />}
          color={stats.maintenanceDue > 0 ? 'orange' : 'green'}
          delay={0.45}
        />
      </div>

      {/* ── Charts ── */}
      {hasData ? (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Trips/Orders last 7 days */}
          <Card className="lg:col-span-2">
            <CardHeader>
              <h3 className="text-sm font-semibold">الرحلات والطلبات — آخر 7 أيام</h3>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={200}>
                <BarChart data={tripsLast7Days} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis dataKey="label" tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                  <YAxis tick={{ fontSize: 11 }} stroke="hsl(var(--muted-foreground))" />
                  <Tooltip
                    contentStyle={{
                      background: 'hsl(var(--popover))',
                      border: '1px solid hsl(var(--border))',
                      borderRadius: 8,
                      fontSize: 12,
                    }}
                  />
                  <Bar dataKey="orders" name="طلبات" fill="#3b82f6" radius={[3, 3, 0, 0]} />
                  <Bar dataKey="trips" name="رحلات" fill="#8b5cf6" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Orders by status pie */}
          <Card>
            <CardHeader>
              <h3 className="text-sm font-semibold">الطلبات حسب الحالة</h3>
            </CardHeader>
            <CardContent>
              {ordersByStatus.length > 0 ? (
                <>
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie
                        data={ordersByStatus}
                        cx="50%"
                        cy="50%"
                        innerRadius={45}
                        outerRadius={70}
                        dataKey="value"
                        paddingAngle={2}
                      >
                        {ordersByStatus.map((_, i) => (
                          <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} />
                        ))}
                      </Pie>
                      <Tooltip
                        contentStyle={{
                          background: 'hsl(var(--popover))',
                          border: '1px solid hsl(var(--border))',
                          borderRadius: 8,
                          fontSize: 12,
                        }}
                      />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="space-y-1.5 mt-2">
                    {ordersByStatus.map((item, i) => (
                      <div key={i} className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-1.5">
                          <div className="w-2 h-2 rounded-full" style={{ background: CHART_COLORS[i % CHART_COLORS.length] }} />
                          <span className="text-muted-foreground">{item.name}</span>
                        </div>
                        <span className="font-medium">{item.value}</span>
                      </div>
                    ))}
                  </div>
                </>
              ) : (
                <div className="h-48 flex items-center justify-center text-muted-foreground text-sm">
                  لا توجد بيانات
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      ) : (
        /* Empty state */
        <Card>
          <CardContent className="py-16">
            <div className="text-center">
              <div className="w-16 h-16 rounded-2xl bg-muted flex items-center justify-center mx-auto mb-4">
                <TrendingUp className="w-8 h-8 text-muted-foreground" />
              </div>
              <h3 className="text-lg font-semibold mb-2">ابدأ باستيراد البيانات</h3>
              <p className="text-sm text-muted-foreground mb-6 max-w-sm mx-auto">
                استورد ملفات Excel من Dynamics أو أضف بيانات يدوياً للبدء في استخدام المنصة
              </p>
              <Link to="/import">
                <button className="inline-flex items-center gap-2 h-10 px-6 text-sm rounded-xl bg-primary text-primary-foreground hover:bg-primary/90 transition-colors">
                  <Upload className="w-4 h-4" />
                  استيراد البيانات
                </button>
              </Link>
            </div>
          </CardContent>
        </Card>
      )}

      {/* ── Bottom Panels ── */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Trips */}
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold">آخر الرحلات</h3>
            <Link to="/trips" className="text-xs text-primary hover:underline">عرض الكل</Link>
          </CardHeader>
          <div className="divide-y divide-border">
            {recentTrips.length === 0 ? (
              <div className="px-6 py-8 text-center text-sm text-muted-foreground">لا توجد رحلات</div>
            ) : (
              recentTrips.map((trip) => (
                <div key={trip.id} className="px-6 py-3 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-muted flex items-center justify-center flex-shrink-0">
                    <Route className="w-4 h-4 text-muted-foreground" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{trip.tripNumber || 'رحلة جديدة'}</p>
                    <p className="text-xs text-muted-foreground">
                      {trip.driverName || 'بدون سائق'} · {formatDate(trip.date)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    <ProgressBar value={Math.max(trip.weightUtilizationPct, trip.volumeUtilizationPct)} size="sm" />
                    <span
                      className={`text-xs px-2 py-0.5 rounded-full font-medium ${TRIP_STATUS_COLORS[trip.status]}`}
                    >
                      {TRIP_STATUS_LABELS[trip.status]}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>

        {/* Upcoming Orders */}
        <Card>
          <CardHeader>
            <h3 className="text-sm font-semibold">الطلبات القادمة (3 أيام)</h3>
            <Link to="/orders" className="text-xs text-primary hover:underline">عرض الكل</Link>
          </CardHeader>
          <div className="divide-y divide-border">
            {upcomingOrders.length === 0 ? (
              <div className="px-6 py-8 text-center text-sm text-muted-foreground">لا توجد طلبات قادمة</div>
            ) : (
              upcomingOrders.map((order) => (
                <div key={order.id} className="px-6 py-3 flex items-center gap-3">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-0.5">
                      <p className="text-sm font-medium">{order.orderNumber}</p>
                      {order.priority === 'urgent' && (
                        <Badge variant="danger" size="sm">عاجل</Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {order.customerName} · {order.customerCity}
                    </p>
                  </div>
                  <div className="text-end flex-shrink-0">
                    <p className="text-xs font-medium text-foreground">
                      {formatDate(order.requestedDeliveryDate)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {formatWeight(order.totalWeightKg)}
                    </p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${ORDER_STATUS_COLORS[order.status]}`}>
                    {ORDER_STATUS_LABELS[order.status]}
                  </span>
                </div>
              ))
            )}
          </div>
        </Card>
      </div>
    </div>
  )
}
