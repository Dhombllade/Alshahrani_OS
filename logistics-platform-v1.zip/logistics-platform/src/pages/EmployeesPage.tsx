import { useState } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, EmptyState, StatCard } from '@/components/ui'
import { generateId } from '@/utils'
import { Users, Plus, Edit2, Trash2, Phone, Mail, CreditCard } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import type { Employee, EmployeeRole } from '@/types'

const ROLE_OPTIONS = [
  { value: 'driver', label: 'سائق' },
  { value: 'coordinator', label: 'منسق' },
  { value: 'warehouse', label: 'مستودع' },
  { value: 'manager', label: 'مدير' },
  { value: 'admin', label: 'إداري' },
]

const ROLE_LABELS: Record<EmployeeRole, string> = {
  driver: 'سائق', coordinator: 'منسق', warehouse: 'مستودع', manager: 'مدير', admin: 'إداري'
}

const ROLE_COLORS: Record<EmployeeRole, string> = {
  driver: 'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  coordinator: 'bg-purple-100 text-purple-700 dark:bg-purple-900/30 dark:text-purple-400',
  warehouse: 'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
  manager: 'bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400',
  admin: 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-400',
}

const defaultForm = {
  nameAr: '', nameEn: '', employeeNumber: '',
  role: 'driver' as EmployeeRole, department: '',
  phone: '', email: '',
  licenseNumber: '', licenseExpiry: '',
  hireDate: new Date().toISOString().slice(0, 10),
  notes: '',
}

export function EmployeesPage() {
  const { employees, addEmployee, updateEmployee, deleteEmployee } = useAppStore()
  const [showForm, setShowForm] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [form, setForm] = useState(defaultForm)
  const [roleFilter, setRoleFilter] = useState('')

  const filtered = employees.filter((e) => !roleFilter || e.role === roleFilter)
  const stats = {
    total: employees.length,
    drivers: employees.filter((e) => e.role === 'driver' && e.isActive).length,
    active: employees.filter((e) => e.isActive).length,
    inactive: employees.filter((e) => !e.isActive).length,
  }

  const handleSubmit = () => {
    if (!form.nameAr) return
    const now = new Date().toISOString()
    if (editingId) {
      updateEmployee(editingId, { ...form, updatedAt: now })
      setEditingId(null)
    } else {
      const emp: Employee = {
        id: generateId(),
        ...form,
        licenseNumber: form.licenseNumber || null,
        licenseExpiry: form.licenseExpiry || null,
        isActive: true,
        createdAt: now,
        updatedAt: now,
      }
      addEmployee(emp)
    }
    setShowForm(false)
    setForm(defaultForm)
  }

  const startEdit = (emp: Employee) => {
    setForm({
      nameAr: emp.nameAr, nameEn: emp.nameEn, employeeNumber: emp.employeeNumber,
      role: emp.role, department: emp.department,
      phone: emp.phone, email: emp.email,
      licenseNumber: emp.licenseNumber ?? '', licenseExpiry: emp.licenseExpiry ?? '',
      hireDate: emp.hireDate, notes: emp.notes,
    })
    setEditingId(emp.id)
    setShowForm(true)
  }

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="إدارة الموظفين"
        subtitle={`${employees.length} موظف · ${stats.drivers} سائق نشط`}
        actions={
          <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => { setShowForm(true); setEditingId(null); setForm(defaultForm) }}>
            إضافة موظف
          </Button>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="إجمالي الموظفين" value={stats.total} icon={<Users className="w-5 h-5" />} color="blue" />
        <StatCard title="السائقون النشطون" value={stats.drivers} icon={<Users className="w-5 h-5" />} color="green" />
        <StatCard title="نشط" value={stats.active} icon={<Users className="w-5 h-5" />} color="purple" />
        <StatCard title="موقوف" value={stats.inactive} icon={<Users className="w-5 h-5" />} color={stats.inactive > 0 ? 'orange' : 'green'} />
      </div>

      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">{editingId ? 'تعديل بيانات الموظف' : 'موظف جديد'}</h3>
                <Button size="sm" variant="ghost" onClick={() => { setShowForm(false); setEditingId(null) }}>إلغاء</Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Input label="الاسم بالعربية *" value={form.nameAr} onChange={(e) => setForm((p) => ({ ...p, nameAr: e.target.value }))} />
                  <Input label="الاسم بالإنجليزية" value={form.nameEn} onChange={(e) => setForm((p) => ({ ...p, nameEn: e.target.value }))} />
                  <Input label="رقم الموظف" value={form.employeeNumber} onChange={(e) => setForm((p) => ({ ...p, employeeNumber: e.target.value }))} />
                  <Select label="الدور الوظيفي" options={ROLE_OPTIONS} value={form.role} onChange={(e) => setForm((p) => ({ ...p, role: e.target.value as EmployeeRole }))} />
                  <Input label="القسم" value={form.department} onChange={(e) => setForm((p) => ({ ...p, department: e.target.value }))} />
                  <Input label="رقم الجوال" type="tel" value={form.phone} onChange={(e) => setForm((p) => ({ ...p, phone: e.target.value }))} />
                  <Input label="البريد الإلكتروني" type="email" value={form.email} onChange={(e) => setForm((p) => ({ ...p, email: e.target.value }))} />
                  <Input label="تاريخ التوظيف" type="date" value={form.hireDate} onChange={(e) => setForm((p) => ({ ...p, hireDate: e.target.value }))} />
                  {(form.role === 'driver') && (
                    <>
                      <Input label="رقم الرخصة" value={form.licenseNumber} onChange={(e) => setForm((p) => ({ ...p, licenseNumber: e.target.value }))} />
                      <Input label="انتهاء الرخصة" type="date" value={form.licenseExpiry} onChange={(e) => setForm((p) => ({ ...p, licenseExpiry: e.target.value }))} />
                    </>
                  )}
                  <div className="md:col-span-2">
                    <Input label="ملاحظات" value={form.notes} onChange={(e) => setForm((p) => ({ ...p, notes: e.target.value }))} />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => { setShowForm(false); setEditingId(null) }}>إلغاء</Button>
                  <Button onClick={handleSubmit}>{editingId ? 'حفظ' : 'إضافة'}</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter */}
      <div className="flex gap-2">
        {[{ value: '', label: 'الكل' }, ...ROLE_OPTIONS].map((opt) => (
          <button
            key={opt.value}
            onClick={() => setRoleFilter(opt.value)}
            className={`px-4 py-1.5 text-sm rounded-lg border transition-colors ${roleFilter === opt.value ? 'border-primary bg-primary/10 text-primary font-medium' : 'border-border hover:bg-muted text-muted-foreground'}`}
          >
            {opt.label}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <Card>
          <EmptyState icon={<Users className="w-6 h-6" />} title="لا يوجد موظفون" action={<Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowForm(true)}>إضافة موظف</Button>} />
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {filtered.map((emp, i) => {
            const licenseExpired = emp.licenseExpiry && emp.licenseExpiry < new Date().toISOString().slice(0, 10)
            return (
              <motion.div key={emp.id} initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: i * 0.04 }}>
                <Card>
                  <CardContent className="pt-5">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center font-semibold text-primary">
                          {emp.nameAr.charAt(0)}
                        </div>
                        <div>
                          <p className="font-semibold">{emp.nameAr}</p>
                          {emp.employeeNumber && <p className="text-xs text-muted-foreground">{emp.employeeNumber}</p>}
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${ROLE_COLORS[emp.role]}`}>
                          {ROLE_LABELS[emp.role]}
                        </span>
                      </div>
                    </div>

                    <div className="space-y-1.5 text-sm mb-3">
                      {emp.phone && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Phone className="w-3.5 h-3.5" />
                          <span>{emp.phone}</span>
                        </div>
                      )}
                      {emp.email && (
                        <div className="flex items-center gap-2 text-muted-foreground">
                          <Mail className="w-3.5 h-3.5" />
                          <span className="truncate">{emp.email}</span>
                        </div>
                      )}
                      {emp.licenseNumber && (
                        <div className={`flex items-center gap-2 ${licenseExpired ? 'text-red-600' : 'text-muted-foreground'}`}>
                          <CreditCard className="w-3.5 h-3.5" />
                          <span>{emp.licenseNumber} {licenseExpired ? '(منتهية!)' : ''}</span>
                        </div>
                      )}
                    </div>

                    <div className="flex items-center justify-between pt-3 border-t border-border">
                      <div className="flex gap-1">
                        <button onClick={() => startEdit(emp)} className="p-1.5 rounded hover:bg-accent transition-colors text-muted-foreground"><Edit2 className="w-3.5 h-3.5" /></button>
                        <button onClick={() => deleteEmployee(emp.id)} className="p-1.5 rounded hover:bg-destructive/10 transition-colors text-muted-foreground hover:text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                      </div>
                      <button
                        onClick={() => updateEmployee(emp.id, { isActive: !emp.isActive })}
                        className={`text-xs px-3 py-1 rounded-lg border transition-colors ${emp.isActive ? 'border-red-200 text-red-600 hover:bg-red-50' : 'border-green-200 text-green-600 hover:bg-green-50'}`}
                      >
                        {emp.isActive ? 'تعطيل' : 'تفعيل'}
                      </button>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            )
          })}
        </div>
      )}
    </div>
  )
}
