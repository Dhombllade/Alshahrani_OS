import { useState, useMemo } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select, EmptyState, StatCard } from '@/components/ui'
import { formatDate, formatSAR, generateId } from '@/utils'
import { Wrench, Plus, AlertTriangle, DollarSign, Calendar, Trash2 } from 'lucide-react'
import { motion, AnimatePresence } from 'framer-motion'
import type { MaintenanceRecord, MaintenanceType } from '@/types'

const MAINTENANCE_TYPE_OPTIONS = [
  { value: 'oil_change', label: 'تغيير زيت' },
  { value: 'tire_change', label: 'تغيير إطارات' },
  { value: 'brake_service', label: 'صيانة فرامل' },
  { value: 'engine_repair', label: 'إصلاح محرك' },
  { value: 'body_repair', label: 'إصلاح هيكل' },
  { value: 'electrical', label: 'كهرباء' },
  { value: 'scheduled_service', label: 'صيانة دورية' },
  { value: 'breakdown', label: 'عطل مفاجئ' },
  { value: 'other', label: 'أخرى' },
]

const MAINTENANCE_LABELS: Record<MaintenanceType, string> = {
  oil_change: 'تغيير زيت', tire_change: 'إطارات', brake_service: 'فرامل',
  engine_repair: 'محرك', body_repair: 'هيكل', electrical: 'كهرباء',
  scheduled_service: 'دورية', breakdown: 'عطل مفاجئ', other: 'أخرى'
}

const defaultForm = {
  truckId: '',
  type: 'scheduled_service' as MaintenanceType,
  date: new Date().toISOString().slice(0, 10),
  odometerKm: 0,
  description: '',
  repairShop: '',
  costSAR: 0,
  nextServiceDate: '',
  nextServiceKm: 0,
  isBreakdown: false,
  downtimeHours: 0,
  notes: '',
}

export function MaintenancePage() {
  const { maintenanceRecords, addMaintenanceRecord, deleteMaintenanceRecord, trucks, updateTruck } = useAppStore()
  const [showForm, setShowForm] = useState(false)
  const [form, setForm] = useState(defaultForm)
  const [filterTruckId, setFilterTruckId] = useState('')

  const today = new Date().toISOString().slice(0, 10)

  const stats = useMemo(() => {
    const totalCost = maintenanceRecords.reduce((s, r) => s + r.costSAR, 0)
    const breakdowns = maintenanceRecords.filter((r) => r.isBreakdown).length
    const overdueTrucks = trucks.filter((t) => t.nextMaintenanceDate && t.nextMaintenanceDate <= today).length
    const thisMonthCost = maintenanceRecords
      .filter((r) => r.date.startsWith(today.slice(0, 7)))
      .reduce((s, r) => s + r.costSAR, 0)
    return { totalCost, breakdowns, overdueTrucks, thisMonthCost }
  }, [maintenanceRecords, trucks, today])

  const filtered = useMemo(() => {
    let r = [...maintenanceRecords]
    if (filterTruckId) r = r.filter((rec) => rec.truckId === filterTruckId)
    return r.sort((a, b) => b.date.localeCompare(a.date))
  }, [maintenanceRecords, filterTruckId])

  const handleSubmit = () => {
    if (!form.truckId || !form.description) return
    const truck = trucks.find((t) => t.id === form.truckId)
    const record: MaintenanceRecord = {
      id: generateId(),
      truckId: form.truckId,
      truckPlate: truck?.plateNumber ?? '',
      type: form.type,
      date: form.date,
      odometerKm: form.odometerKm,
      description: form.description,
      repairShop: form.repairShop,
      costSAR: form.costSAR,
      nextServiceDate: form.nextServiceDate || null,
      nextServiceKm: form.nextServiceKm || null,
      isBreakdown: form.isBreakdown,
      downtimeHours: form.downtimeHours,
      notes: form.notes,
      createdAt: new Date().toISOString(),
    }
    addMaintenanceRecord(record)

    // Update truck maintenance dates
    if (form.nextServiceDate || form.nextServiceKm) {
      updateTruck(form.truckId, {
        lastMaintenanceDate: form.date,
        nextMaintenanceDate: form.nextServiceDate || null,
        nextMaintenanceKm: form.nextServiceKm || null,
        currentOdometerKm: form.odometerKm || truck?.currentOdometerKm || 0,
      })
    }

    setShowForm(false)
    setForm(defaultForm)
  }

  const activeTrucks = trucks.filter((t) => t.isActive)
  const truckOptions = activeTrucks.map((t) => ({ value: t.id, label: `${t.name} — ${t.plateNumber}` }))

  // Upcoming maintenance alerts
  const upcoming = trucks.filter((t) => t.nextMaintenanceDate && t.nextMaintenanceDate <= today)

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="إدارة الصيانة"
        subtitle="سجل الأعطال والصيانة الدورية للأسطول"
        actions={
          <Button size="sm" icon={<Plus className="w-3.5 h-3.5" />} onClick={() => setShowForm(true)}>
            تسجيل صيانة
          </Button>
        }
      />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="إجمالي التكاليف" value={formatSAR(stats.totalCost)} icon={<DollarSign className="w-5 h-5" />} color="blue" />
        <StatCard title="تكاليف هذا الشهر" value={formatSAR(stats.thisMonthCost)} icon={<DollarSign className="w-5 h-5" />} color="purple" />
        <StatCard title="عدد الأعطال" value={stats.breakdowns} icon={<AlertTriangle className="w-5 h-5" />} color={stats.breakdowns > 0 ? 'red' : 'green'} />
        <StatCard title="صيانة مستحقة" value={stats.overdueTrucks} icon={<Calendar className="w-5 h-5" />} color={stats.overdueTrucks > 0 ? 'orange' : 'green'} />
      </div>

      {/* Alerts */}
      {upcoming.length > 0 && (
        <div className="space-y-2">
          {upcoming.map((truck) => (
            <div key={truck.id} className="flex items-center gap-3 px-4 py-3 bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/30 rounded-xl">
              <AlertTriangle className="w-4 h-4 text-amber-600 flex-shrink-0" />
              <p className="text-sm text-amber-800 dark:text-amber-300 flex-1">
                <span className="font-semibold">{truck.name} ({truck.plateNumber})</span> — صيانة مستحقة في {formatDate(truck.nextMaintenanceDate!)}
              </p>
              <Button size="sm" variant="outline" onClick={() => { setForm((p) => ({ ...p, truckId: truck.id, type: 'scheduled_service' })); setShowForm(true) }}>
                تسجيل
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* Form */}
      <AnimatePresence>
        {showForm && (
          <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }} exit={{ opacity: 0, height: 0 }}>
            <Card>
              <CardHeader>
                <h3 className="text-sm font-semibold">تسجيل صيانة جديدة</h3>
                <Button size="sm" variant="ghost" onClick={() => setShowForm(false)}>إلغاء</Button>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Select label="الشاحنة *" options={truckOptions} value={form.truckId} onChange={(e) => setForm((p) => ({ ...p, truckId: e.target.value }))} placeholder="اختر شاحنة..." />
                  <Select label="نوع الصيانة" options={MAINTENANCE_TYPE_OPTIONS} value={form.type} onChange={(e) => setForm((p) => ({ ...p, type: e.target.value as MaintenanceType }))} />
                  <Input label="التاريخ" type="date" value={form.date} onChange={(e) => setForm((p) => ({ ...p, date: e.target.value }))} />
                  <Input label="عداد الكيلومتر" type="number" value={form.odometerKm} onChange={(e) => setForm((p) => ({ ...p, odometerKm: +e.target.value }))} />
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Input label="الوصف / المشكلة *" value={form.description} onChange={(e) => setForm((p) => ({ ...p, description: e.target.value }))} placeholder="وصف العمل المنجز..." />
                  <Input label="ورشة الإصلاح" value={form.repairShop} onChange={(e) => setForm((p) => ({ ...p, repairShop: e.target.value }))} />
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <Input label="التكلفة (ريال)" type="number" value={form.costSAR} onChange={(e) => setForm((p) => ({ ...p, costSAR: +e.target.value }))} />
                  <Input label="موعد الصيانة القادمة" type="date" value={form.nextServiceDate} onChange={(e) => setForm((p) => ({ ...p, nextServiceDate: e.target.value }))} />
                  <Input label="كيلومتر الصيانة القادمة" type="number" value={form.nextServiceKm || ''} onChange={(e) => setForm((p) => ({ ...p, nextServiceKm: +e.target.value }))} />
                  <Input label="ساعات التوقف" type="number" value={form.downtimeHours} onChange={(e) => setForm((p) => ({ ...p, downtimeHours: +e.target.value }))} />
                </div>
                <div className="flex items-center gap-3">
                  <label className="flex items-center gap-2 cursor-pointer text-sm">
                    <input type="checkbox" checked={form.isBreakdown} onChange={(e) => setForm((p) => ({ ...p, isBreakdown: e.target.checked }))} className="rounded" />
                    <span className="text-destructive font-medium">عطل مفاجئ (إيقاف الشاحنة)</span>
                  </label>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setShowForm(false)}>إلغاء</Button>
                  <Button onClick={handleSubmit} icon={<Plus className="w-4 h-4" />}>تسجيل الصيانة</Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Filter by truck */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setFilterTruckId('')} className={`px-3 py-1.5 text-sm rounded-lg border transition-colors ${!filterTruckId ? 'border-primary bg-primary/10 text-primary font-medium' : 'border-border hover:bg-muted text-muted-foreground'}`}>
          كل الشاحنات
        </button>
        {activeTrucks.map((t) => (
          <button key={t.id} onClick={() => setFilterTruckId(t.id)} className={`px-3 py-1.5 text-sm rounded-lg border transition-colors ${filterTruckId === t.id ? 'border-primary bg-primary/10 text-primary font-medium' : 'border-border hover:bg-muted text-muted-foreground'}`}>
            {t.plateNumber}
          </button>
        ))}
      </div>

      {/* Records */}
      {filtered.length === 0 ? (
        <Card>
          <EmptyState
            icon={<Wrench className="w-6 h-6" />}
            title="لا توجد سجلات صيانة"
            description="سجّل أول عملية صيانة لبدء متابعة الأسطول"
            action={<Button icon={<Plus className="w-4 h-4" />} onClick={() => setShowForm(true)}>تسجيل صيانة</Button>}
          />
        </Card>
      ) : (
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="bg-muted/30 border-b border-border">
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">التاريخ</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الشاحنة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">نوع الصيانة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الوصف</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">الورشة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">التكلفة</th>
                  <th className="text-start px-4 py-3 font-medium text-muted-foreground">التوقف</th>
                  <th className="w-12 px-4 py-3" />
                </tr>
              </thead>
              <tbody>
                {filtered.map((rec, i) => (
                  <motion.tr key={rec.id} initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: i * 0.02 }} className="border-b border-border/50 hover:bg-muted/20">
                    <td className="px-4 py-3">
                      <p className="font-medium">{formatDate(rec.date)}</p>
                      {rec.isBreakdown && <span className="text-xs text-red-600 font-medium">عطل مفاجئ</span>}
                    </td>
                    <td className="px-4 py-3 font-mono text-sm">{rec.truckPlate}</td>
                    <td className="px-4 py-3">
                      <span className="text-xs px-2 py-0.5 rounded-full bg-muted font-medium">
                        {MAINTENANCE_LABELS[rec.type]}
                      </span>
                    </td>
                    <td className="px-4 py-3 max-w-48">
                      <p className="truncate">{rec.description}</p>
                    </td>
                    <td className="px-4 py-3 text-muted-foreground">{rec.repairShop || '—'}</td>
                    <td className="px-4 py-3 font-semibold">{rec.costSAR > 0 ? formatSAR(rec.costSAR) : '—'}</td>
                    <td className="px-4 py-3 text-muted-foreground">{rec.downtimeHours > 0 ? `${rec.downtimeHours} س` : '—'}</td>
                    <td className="px-4 py-3">
                      <button onClick={() => deleteMaintenanceRecord(rec.id)} className="p-1.5 rounded hover:bg-destructive/10 hover:text-destructive transition-colors text-muted-foreground">
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </motion.tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  )
}
