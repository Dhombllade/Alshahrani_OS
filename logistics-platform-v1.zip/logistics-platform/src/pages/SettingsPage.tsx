import { useState } from 'react'
import { useAppStore } from '@/store'
import { Card, CardHeader, CardContent, PageHeader, Button, Input, Select } from '@/components/ui'
import { Settings, Save, RotateCcw, Sun, Moon, Monitor, Globe, Building2, Sliders } from 'lucide-react'
import { motion } from 'framer-motion'

const DAY_NAMES = ['الأحد', 'الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت']

export function SettingsPage() {
  const { settings, updateSettings } = useAppStore()
  const [form, setForm] = useState({ ...settings })
  const [saved, setSaved] = useState(false)
  const [activeSection, setActiveSection] = useState('company')

  const handleSave = () => {
    updateSettings(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  const handleReset = () => {
    setForm({ ...settings })
  }

  const toggleDay = (day: number) => {
    const days = form.workingDays.includes(day)
      ? form.workingDays.filter((d) => d !== day)
      : [...form.workingDays, day].sort()
    setForm((p) => ({ ...p, workingDays: days }))
  }

  const SECTIONS = [
    { id: 'company', label: 'معلومات الشركة', icon: Building2 },
    { id: 'operations', label: 'إعدادات العمليات', icon: Sliders },
    { id: 'planning', label: 'إعدادات التخطيط', icon: Settings },
    { id: 'display', label: 'العرض والواجهة', icon: Globe },
  ]

  return (
    <div className="p-6 space-y-6">
      <PageHeader
        title="الإعدادات"
        subtitle="كل القيم قابلة للتخصيص — لا قيم ثابتة في النظام"
        actions={
          <div className="flex gap-2">
            <Button variant="outline" size="sm" icon={<RotateCcw className="w-3.5 h-3.5" />} onClick={handleReset}>
              تراجع
            </Button>
            <Button size="sm" icon={<Save className="w-3.5 h-3.5" />} onClick={handleSave}>
              {saved ? '✓ تم الحفظ' : 'حفظ الإعدادات'}
            </Button>
          </div>
        }
      />

      <div className="flex gap-6">
        {/* Side nav */}
        <div className="w-48 flex-shrink-0">
          <nav className="space-y-1 sticky top-6">
            {SECTIONS.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveSection(id)}
                className={`w-full flex items-center gap-2.5 px-3 py-2.5 text-sm rounded-lg transition-colors text-start ${
                  activeSection === id
                    ? 'bg-primary/10 text-primary font-medium'
                    : 'text-muted-foreground hover:text-foreground hover:bg-muted'
                }`}
              >
                <Icon className="w-4 h-4" />
                {label}
              </button>
            ))}
          </nav>
        </div>

        {/* Content */}
        <div className="flex-1 space-y-6">
          {/* ── Company ── */}
          {activeSection === 'company' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <Card>
                <CardHeader><h3 className="text-sm font-semibold">معلومات الشركة</h3></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="اسم الشركة (عربي)"
                      value={form.companyNameAr}
                      onChange={(e) => setForm((p) => ({ ...p, companyNameAr: e.target.value }))}
                    />
                    <Input
                      label="اسم الشركة (إنجليزي)"
                      value={form.companyName}
                      onChange={(e) => setForm((p) => ({ ...p, companyName: e.target.value }))}
                    />
                    <Input
                      label="المنطقة / الفرع"
                      value={form.region}
                      onChange={(e) => setForm((p) => ({ ...p, region: e.target.value }))}
                    />
                    <Input
                      label="العملة"
                      value={form.currency}
                      onChange={(e) => setForm((p) => ({ ...p, currency: e.target.value }))}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><h3 className="text-sm font-semibold">موقع المستودع (GPS)</h3></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="خط العرض (Latitude)"
                      type="number"
                      step="0.0001"
                      value={form.warehouseLocation?.lat ?? ''}
                      placeholder="18.2164"
                      onChange={(e) => setForm((p) => ({
                        ...p,
                        warehouseLocation: {
                          lat: parseFloat(e.target.value) || 0,
                          lng: p.warehouseLocation?.lng ?? 0,
                          address: p.warehouseLocation?.address ?? '',
                        }
                      }))}
                    />
                    <Input
                      label="خط الطول (Longitude)"
                      type="number"
                      step="0.0001"
                      value={form.warehouseLocation?.lng ?? ''}
                      placeholder="42.5053"
                      onChange={(e) => setForm((p) => ({
                        ...p,
                        warehouseLocation: {
                          lat: p.warehouseLocation?.lat ?? 0,
                          lng: parseFloat(e.target.value) || 0,
                          address: p.warehouseLocation?.address ?? '',
                        }
                      }))}
                    />
                    <div className="col-span-2">
                      <Input
                        label="العنوان"
                        value={form.warehouseLocation?.address ?? ''}
                        placeholder="أبها الصناعية، المنطقة الجنوبية"
                        onChange={(e) => setForm((p) => ({
                          ...p,
                          warehouseLocation: {
                            lat: p.warehouseLocation?.lat ?? 0,
                            lng: p.warehouseLocation?.lng ?? 0,
                            address: e.target.value,
                          }
                        }))}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* ── Operations ── */}
          {activeSection === 'operations' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <Card>
                <CardHeader><h3 className="text-sm font-semibold">ساعات العمل</h3></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      label="بداية الدوام"
                      type="time"
                      value={form.workingHoursStart}
                      onChange={(e) => setForm((p) => ({ ...p, workingHoursStart: e.target.value }))}
                    />
                    <Input
                      label="نهاية الدوام"
                      type="time"
                      value={form.workingHoursEnd}
                      onChange={(e) => setForm((p) => ({ ...p, workingHoursEnd: e.target.value }))}
                    />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-foreground mb-2">أيام العمل</p>
                    <div className="flex gap-2 flex-wrap">
                      {DAY_NAMES.map((name, day) => (
                        <button
                          key={day}
                          onClick={() => toggleDay(day)}
                          className={`px-4 py-2 text-sm rounded-lg border transition-colors ${
                            form.workingDays.includes(day)
                              ? 'border-primary bg-primary/10 text-primary font-medium'
                              : 'border-border text-muted-foreground hover:bg-muted'
                          }`}
                        >
                          {name}
                        </button>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><h3 className="text-sm font-semibold">أوقات العمليات (تُستخدم في حساب الوقت الإضافي)</h3></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <Input
                        label="سرعة الشاحنة المتوسطة (كم/س)"
                        type="number"
                        value={form.averageTruckSpeedKmh}
                        onChange={(e) => setForm((p) => ({ ...p, averageTruckSpeedKmh: +e.target.value }))}
                      />
                      <p className="text-xs text-muted-foreground mt-1">يُستخدم في: (المسافة ÷ السرعة) للوقت الإضافي</p>
                    </div>
                    <div>
                      <Input
                        label="وقت التحميل (دقيقة)"
                        type="number"
                        value={form.loadingTimeMinutes}
                        onChange={(e) => setForm((p) => ({ ...p, loadingTimeMinutes: +e.target.value }))}
                      />
                    </div>
                    <div>
                      <Input
                        label="وقت التفريغ لكل نقطة (دقيقة)"
                        type="number"
                        value={form.unloadingTimeMinutes}
                        onChange={(e) => setForm((p) => ({ ...p, unloadingTimeMinutes: +e.target.value }))}
                      />
                    </div>
                    <div>
                      <Input
                        label="وقت الراحة (دقيقة)"
                        type="number"
                        value={form.breakTimeMinutes}
                        onChange={(e) => setForm((p) => ({ ...p, breakTimeMinutes: +e.target.value }))}
                      />
                    </div>
                    <div>
                      <Input
                        label="حد الوقت الإضافي (دقيقة)"
                        type="number"
                        value={form.overtimeThresholdMinutes}
                        onChange={(e) => setForm((p) => ({ ...p, overtimeThresholdMinutes: +e.target.value }))}
                      />
                      <p className="text-xs text-muted-foreground mt-1">الحد الأدنى لاحتساب الوقت الإضافي</p>
                    </div>
                  </div>

                  {/* Formula display */}
                  <div className="mt-4 p-4 bg-muted/30 rounded-xl">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">صيغة حساب الوقت الإضافي (بناءً على إعداداتك):</p>
                    <p className="text-sm font-mono text-foreground">
                      إجمالي الرحلة = (ذهاب + عودة) ÷ {form.averageTruckSpeedKmh} + {form.loadingTimeMinutes}د تحميل + ({form.unloadingTimeMinutes}د × عدد النقاط) + {form.breakTimeMinutes}د راحة
                    </p>
                    <p className="text-sm font-mono text-orange-600 dark:text-orange-400 mt-1">
                      الوقت الإضافي = إجمالي الرحلة − {form.workingHoursStart} إلى {form.workingHoursEnd}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* ── Planning ── */}
          {activeSection === 'planning' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
              <Card>
                <CardHeader><h3 className="text-sm font-semibold">إعدادات محرك التخطيط</h3></CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <div>
                      <Input
                        label="أقصى رحلات يومية للسائق"
                        type="number"
                        value={form.maxTripsPerDriverPerDay}
                        onChange={(e) => setForm((p) => ({ ...p, maxTripsPerDriverPerDay: +e.target.value }))}
                      />
                    </div>
                    <div>
                      <Input
                        label="أقصى طلبات في الرحلة"
                        type="number"
                        value={form.maxOrdersPerTrip}
                        onChange={(e) => setForm((p) => ({ ...p, maxOrdersPerTrip: +e.target.value }))}
                      />
                    </div>
                    <div>
                      <Input
                        label="نطاق التوصيل القريب (كم)"
                        type="number"
                        value={form.nearbyDeliveryRadiusKm}
                        onChange={(e) => setForm((p) => ({ ...p, nearbyDeliveryRadiusKm: +e.target.value }))}
                      />
                      <p className="text-xs text-muted-foreground mt-1">يُستخدم لدمج الطلبات القريبة</p>
                    </div>
                    <div>
                      <Input
                        label="حد تحذير الاستغلال المنخفض (%)"
                        type="number"
                        min={1}
                        max={100}
                        value={Math.round(form.utilizationWarningThreshold * 100)}
                        onChange={(e) => setForm((p) => ({ ...p, utilizationWarningThreshold: +e.target.value / 100 }))}
                      />
                      <p className="text-xs text-muted-foreground mt-1">تحذير إذا الاستغلال أقل من هذا</p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* ── Display ── */}
          {activeSection === 'display' && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-4">
              <Card>
                <CardHeader><h3 className="text-sm font-semibold">المظهر</h3></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-3 gap-3">
                    {[
                      { value: 'light', label: 'فاتح', icon: Sun },
                      { value: 'dark', label: 'داكن', icon: Moon },
                      { value: 'system', label: 'تلقائي', icon: Monitor },
                    ].map(({ value, label, icon: Icon }) => (
                      <button
                        key={value}
                        onClick={() => setForm((p) => ({ ...p, theme: value as 'light' | 'dark' | 'system' }))}
                        className={`flex flex-col items-center gap-2 py-4 rounded-xl border transition-colors ${
                          form.theme === value
                            ? 'border-primary bg-primary/10 text-primary'
                            : 'border-border hover:bg-muted text-muted-foreground'
                        }`}
                      >
                        <Icon className="w-5 h-5" />
                        <span className="text-sm font-medium">{label}</span>
                      </button>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><h3 className="text-sm font-semibold">اللغة والوحدات</h3></CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    <Select
                      label="اللغة"
                      options={[{ value: 'ar', label: 'العربية' }, { value: 'en', label: 'English' }]}
                      value={form.language}
                      onChange={(e) => setForm((p) => ({ ...p, language: e.target.value as 'ar' | 'en' }))}
                    />
                    <Select
                      label="وحدة المسافة"
                      options={[{ value: 'km', label: 'كيلومتر (كم)' }, { value: 'mi', label: 'ميل (mi)' }]}
                      value={form.distanceUnit}
                      onChange={(e) => setForm((p) => ({ ...p, distanceUnit: e.target.value as 'km' | 'mi' }))}
                    />
                    <Select
                      label="وحدة الوزن"
                      options={[{ value: 'kg', label: 'كيلوجرام (كجم)' }, { value: 'ton', label: 'طن' }]}
                      value={form.weightUnit}
                      onChange={(e) => setForm((p) => ({ ...p, weightUnit: e.target.value as 'kg' | 'ton' }))}
                    />
                    <Select
                      label="وحدة الحجم"
                      options={[{ value: 'm3', label: 'متر مكعب (م³)' }, { value: 'ft3', label: 'قدم مكعب' }]}
                      value={form.volumeUnit}
                      onChange={(e) => setForm((p) => ({ ...p, volumeUnit: e.target.value as 'm3' | 'ft3' }))}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader><h3 className="text-sm font-semibold">التكاملات المستقبلية</h3></CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    <Input
                      label="مفتاح Google Maps API"
                      value={form.googleMapsApiKey}
                      onChange={(e) => setForm((p) => ({ ...p, googleMapsApiKey: e.target.value }))}
                      placeholder="AIzaSy..."
                      type="password"
                    />
                    <div className="flex gap-4">
                      <label className="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="checkbox" checked={form.whatsappEnabled} onChange={(e) => setForm((p) => ({ ...p, whatsappEnabled: e.target.checked }))} className="rounded" />
                        تفعيل إشعارات WhatsApp (قريباً)
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer text-sm">
                        <input type="checkbox" checked={form.emailEnabled} onChange={(e) => setForm((p) => ({ ...p, emailEnabled: e.target.checked }))} className="rounded" />
                        تفعيل إشعارات البريد الإلكتروني (قريباً)
                      </label>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )}

          {/* Save button at bottom */}
          <div className="flex justify-end gap-2 pt-2">
            <Button variant="outline" onClick={handleReset} icon={<RotateCcw className="w-4 h-4" />}>تراجع</Button>
            <Button onClick={handleSave} icon={<Save className="w-4 h-4" />}>
              {saved ? '✓ تم الحفظ' : 'حفظ الإعدادات'}
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
